"use strict";
(() => {
  // src/core/settings.ts
  var DEFAULT_SETTINGS = Object.freeze({
    deadzone: 0.2,
    coneAngle: 30,
    triggerThreshold: 0.5,
    neutralBehavior: "retain",
    candidateStart: "first",
    inclusionMode: "center",
    distanceMode: "center",
    tieBreak: "dom"
  });

  // src/extension/background.ts
  var activeTabId;
  var ownershipRevision = 0;
  function sendTabOwnership(tabId, active) {
    void chrome.tabs.sendMessage(tabId, {
      type: "joy-nav:tab-ownership",
      active
    }).catch(() => void 0);
  }
  function updateActiveTab(tabId) {
    if (activeTabId === tabId) {
      if (tabId !== void 0) sendTabOwnership(tabId, true);
      return;
    }
    const previousTabId = activeTabId;
    activeTabId = tabId;
    if (previousTabId !== void 0) sendTabOwnership(previousTabId, false);
    if (tabId !== void 0) sendTabOwnership(tabId, true);
  }
  async function syncFocusedTab() {
    const revision = ++ownershipRevision;
    try {
      const focusedWindow = await chrome.windows.getLastFocused();
      if (revision !== ownershipRevision) return;
      if (!focusedWindow.focused || focusedWindow.id === void 0) {
        updateActiveTab(void 0);
        return;
      }
      const [tab] = await chrome.tabs.query({ active: true, windowId: focusedWindow.id });
      if (revision === ownershipRevision) updateActiveTab(tab?.id);
    } catch {
      if (revision === ownershipRevision) updateActiveTab(void 0);
    }
  }
  void syncFocusedTab();
  chrome.tabs.onActivated.addListener(({ tabId, windowId }) => {
    const revision = ++ownershipRevision;
    void chrome.windows.get(windowId).then((focusedWindow) => {
      if (revision === ownershipRevision && focusedWindow.focused) updateActiveTab(tabId);
    }).catch(() => void 0);
  });
  chrome.windows.onFocusChanged.addListener((windowId) => {
    const revision = ++ownershipRevision;
    if (windowId === chrome.windows.WINDOW_ID_NONE) {
      updateActiveTab(void 0);
      return;
    }
    void chrome.tabs.query({ active: true, windowId }).then(([tab]) => {
      if (revision === ownershipRevision) updateActiveTab(tab?.id);
    }).catch(() => {
      if (revision === ownershipRevision) updateActiveTab(void 0);
    });
  });
  chrome.tabs.onRemoved.addListener((tabId) => {
    if (activeTabId !== tabId) return;
    ++ownershipRevision;
    updateActiveTab(void 0);
    void syncFocusedTab();
  });
  chrome.runtime.onInstalled.addListener(() => {
    void chrome.storage.local.get("settings").then(({ settings }) => {
      if (!settings) return chrome.storage.local.set({ settings: DEFAULT_SETTINGS });
      return void 0;
    });
    void syncFocusedTab();
  });
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    const tabId = sender.tab?.id;
    if (message?.type === "joy-nav:claim-active-tab") {
      if (tabId === void 0) {
        sendResponse({ active: false });
        return false;
      }
      const previousTabId = activeTabId;
      ++ownershipRevision;
      activeTabId = tabId;
      if (previousTabId !== void 0 && previousTabId !== tabId) sendTabOwnership(previousTabId, false);
      sendResponse({ active: true });
      return false;
    }
    if (message?.type === "joy-nav:release-active-tab") {
      if (tabId !== void 0 && activeTabId === tabId) {
        ++ownershipRevision;
        updateActiveTab(void 0);
        void syncFocusedTab();
      }
      sendResponse({ active: false });
      return false;
    }
    return false;
  });
})();
