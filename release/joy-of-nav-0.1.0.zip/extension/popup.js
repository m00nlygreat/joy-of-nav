"use strict";
(() => {
  // src/extension/popup.ts
  var toggleButton = document.querySelector("#toggleButton");
  var statusTitle = document.querySelector("#statusTitle");
  var statusDescription = document.querySelector("#statusDescription");
  var statusIcon = document.querySelector("#statusIcon");
  var pageLabel = document.querySelector("#pageLabel");
  var activeTabId;
  var currentStatus = null;
  var unavailableReason = null;
  function showUnavailable(message) {
    unavailableReason = message;
    currentStatus = null;
    statusTitle.textContent = "\uC774 \uD398\uC774\uC9C0\uC5D0\uC11C \uC0AC\uC6A9\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4";
    statusDescription.textContent = message;
    statusIcon.dataset.tone = "error";
    toggleButton.textContent = "\uC0AC\uC6A9\uD560 \uC218 \uC5C6\uB294 \uD398\uC774\uC9C0";
    toggleButton.disabled = true;
  }
  function renderStatus(status) {
    currentStatus = status;
    toggleButton.disabled = false;
    if (!status) {
      statusTitle.textContent = "\uD604\uC7AC \uD398\uC774\uC9C0\uC5D0\uC11C \uC2DC\uC791\uD560 \uC218 \uC788\uC2B5\uB2C8\uB2E4";
      statusDescription.textContent = "\uD655\uC7A5 \uC544\uC774\uCF58\uC744 \uB204\uB974\uBA74 \uC774 \uD0ED\uC5D0\uC11C \uAC8C\uC784\uD328\uB4DC \uD0D0\uC0C9\uC744 \uCF2D\uB2C8\uB2E4.";
      statusIcon.dataset.tone = "ready";
      toggleButton.textContent = "\uC774 \uD398\uC774\uC9C0\uC5D0\uC11C \uCF1C\uAE30";
      return;
    }
    statusIcon.dataset.tone = status.enabled ? "active" : "ready";
    if (status.enabled) {
      statusTitle.textContent = status.gamepadConnected ? "\uD0D0\uC0C9\uC774 \uCF1C\uC838 \uC788\uC2B5\uB2C8\uB2E4" : "\uD0D0\uC0C9 \uB300\uAE30 \uC911";
      statusDescription.textContent = status.gamepadConnected ? "L\uC2A4\uD2F1\uC73C\uB85C \uBC29\uD5A5\uC744 \uC9C0\uC815\uD558\uACE0 X\uB85C \uD6C4\uBCF4\uB97C \uACE0\uB974\uC138\uC694." : status.supported ? "\uD398\uC774\uC9C0\uB97C \uB2E4\uC2DC \uD65C\uC131\uD654\uD55C \uB4A4 \uCEE8\uD2B8\uB864\uB7EC\uC758 \uBC84\uD2BC\uC774\uB098 \uC2A4\uD2F1\uC744 \uD55C \uBC88 \uC6C0\uC9C1\uC5EC \uBCF4\uC138\uC694." : "\uC774 \uBE0C\uB77C\uC6B0\uC800 \uD398\uC774\uC9C0\uC5D0\uC11C\uB294 Gamepad API\uB97C \uC0AC\uC6A9\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4.";
      toggleButton.textContent = "\uC774 \uD398\uC774\uC9C0\uC5D0\uC11C \uB044\uAE30";
    } else {
      statusTitle.textContent = "\uD604\uC7AC \uD398\uC774\uC9C0\uC5D0\uC11C \uBA48\uCDB0 \uC788\uC2B5\uB2C8\uB2E4";
      statusDescription.textContent = "\uAC8C\uC784\uD328\uB4DC \uC785\uB825\uC740 \uCF1C \uB454 \uD398\uC774\uC9C0\uAC00 \uD65C\uC131\uD654\uB41C \uB3D9\uC548\uC5D0\uB9CC \uCC98\uB9AC\uD569\uB2C8\uB2E4.";
      toggleButton.textContent = "\uC774 \uD398\uC774\uC9C0\uC5D0\uC11C \uCF1C\uAE30";
    }
  }
  async function queryPageStatus(tabId) {
    try {
      return await chrome.tabs.sendMessage(tabId, { type: "joy-nav:get-status" });
    } catch {
      return null;
    }
  }
  async function initialize() {
    try {
      const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      if (!tab?.id) {
        showUnavailable("\uD65C\uC131 \uD0ED\uC744 \uCC3E\uC744 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4.");
        return;
      }
      activeTabId = tab.id;
      pageLabel.textContent = tab.title ? tab.title.slice(0, 30) : "\uD65C\uC131 \uD0ED";
      renderStatus(await queryPageStatus(tab.id));
    } catch {
      showUnavailable("Chrome\uC5D0\uC11C \uC774 \uD0ED\uC744 \uC81C\uC5B4\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4.");
    }
  }
  toggleButton.addEventListener("click", async () => {
    if (activeTabId === void 0 || unavailableReason) return;
    toggleButton.disabled = true;
    toggleButton.textContent = "\uD398\uC774\uC9C0\uC5D0 \uC5F0\uACB0 \uC911\u2026";
    try {
      if (!currentStatus) {
        await chrome.scripting.executeScript({ target: { tabId: activeTabId }, files: ["extension/content.js"] });
      }
      const nextEnabled = !currentStatus?.enabled;
      currentStatus = await chrome.tabs.sendMessage(activeTabId, {
        type: "joy-nav:set-enabled",
        enabled: nextEnabled
      });
      renderStatus(currentStatus);
    } catch {
      showUnavailable("\uC774 \uD398\uC774\uC9C0\uC5D0 \uC2A4\uD06C\uB9BD\uD2B8\uB97C \uB123\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4. chrome:// \uD398\uC774\uC9C0\uC640 Chrome \uC6F9 \uC2A4\uD1A0\uC5B4\uB294 \uC9C0\uC6D0\uD558\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4.");
    }
  });
  document.querySelector("#settingsButton").addEventListener("click", () => {
    void chrome.runtime.openOptionsPage();
  });
  void initialize();
})();
