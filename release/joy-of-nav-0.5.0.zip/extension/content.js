"use strict";
(() => {
  // src/core/navigation.ts
  function readDirection(x, y, deadzone) {
    const magnitude = Math.hypot(x, y);
    if (!Number.isFinite(magnitude) || magnitude <= deadzone) return null;
    return { x, y, magnitude };
  }
  function pointInCone(point, origin, direction, fullAngle) {
    const dx = point.x - origin.x;
    const dy = point.y - origin.y;
    const pointLength = Math.hypot(dx, dy);
    const directionLength = Math.hypot(direction.x, direction.y);
    if (pointLength === 0 || directionLength === 0) return true;
    const cosine = Math.min(1, Math.max(-1, (dx * direction.x + dy * direction.y) / (pointLength * directionLength)));
    const angle = Math.acos(cosine) * 180 / Math.PI;
    return angle <= fullAngle / 2 + 1e-8;
  }
  function corners(rect) {
    return [
      { x: rect.left, y: rect.top },
      { x: rect.right, y: rect.top },
      { x: rect.right, y: rect.bottom },
      { x: rect.left, y: rect.bottom }
    ];
  }
  function segmentIntersectsRect(start, end, rect) {
    const dx = end.x - start.x;
    const dy = end.y - start.y;
    let t0 = 0;
    let t1 = 1;
    const tests = [
      [-dx, start.x - rect.left],
      [dx, rect.right - start.x],
      [-dy, start.y - rect.top],
      [dy, rect.bottom - start.y]
    ];
    for (const [p, q] of tests) {
      if (p === 0) {
        if (q < 0) return false;
        continue;
      }
      const t = q / p;
      if (p < 0) t0 = Math.max(t0, t);
      else t1 = Math.min(t1, t);
      if (t0 > t1) return false;
    }
    return true;
  }
  function rayIntersectsRect(origin, direction, rect) {
    const length = Math.max(...corners(rect).map((point) => Math.hypot(point.x - origin.x, point.y - origin.y))) + 1;
    const magnitude = Math.hypot(direction.x, direction.y);
    if (!magnitude) return false;
    const end = { x: origin.x + direction.x / magnitude * length, y: origin.y + direction.y / magnitude * length };
    return segmentIntersectsRect(origin, end, rect);
  }
  function rectIntersectsCone(rect, origin, direction, fullAngle) {
    if (corners(rect).some((corner) => pointInCone(corner, origin, direction, fullAngle))) return true;
    const nearest = {
      x: Math.min(rect.right, Math.max(rect.left, origin.x)),
      y: Math.min(rect.bottom, Math.max(rect.top, origin.y))
    };
    if (pointInCone(nearest, origin, direction, fullAngle)) return true;
    const axisAngle = Math.atan2(direction.y, direction.x);
    const halfAngle = fullAngle * Math.PI / 360;
    const start = { x: Math.cos(axisAngle - halfAngle), y: Math.sin(axisAngle - halfAngle) };
    const end = { x: Math.cos(axisAngle + halfAngle), y: Math.sin(axisAngle + halfAngle) };
    return rayIntersectsRect(origin, direction, rect) || rayIntersectsRect(origin, start, rect) || rayIntersectsRect(origin, end, rect);
  }
  function candidateInCone(candidate, origin, direction, fullAngle, mode) {
    if (mode === "intersects") return rectIntersectsCone(candidate.rect, origin, direction, fullAngle);
    return pointInCone({
      x: (candidate.rect.left + candidate.rect.right) / 2,
      y: (candidate.rect.top + candidate.rect.bottom) / 2
    }, origin, direction, fullAngle);
  }
  function candidateDistance(candidate, origin, mode) {
    const point = mode === "center" ? { x: (candidate.rect.left + candidate.rect.right) / 2, y: (candidate.rect.top + candidate.rect.bottom) / 2 } : {
      x: Math.min(candidate.rect.right, Math.max(candidate.rect.left, origin.x)),
      y: Math.min(candidate.rect.bottom, Math.max(candidate.rect.top, origin.y))
    };
    return Math.hypot(point.x - origin.x, point.y - origin.y);
  }
  function rankCandidates(candidates2, origin, direction, fullAngle, inclusionMode, distanceMode, tieBreak) {
    return candidates2.filter((candidate) => candidateInCone(candidate, origin, direction, fullAngle, inclusionMode)).slice().sort((left, right) => {
      const distanceDelta = candidateDistance(left, origin, distanceMode) - candidateDistance(right, origin, distanceMode);
      if (Math.abs(distanceDelta) > 0.01) return distanceDelta;
      if (tieBreak === "top-left") {
        const topDelta = left.rect.top - right.rect.top;
        if (Math.abs(topDelta) > 0.01) return topDelta;
        const leftDelta = left.rect.left - right.rect.left;
        if (Math.abs(leftDelta) > 0.01) return leftDelta;
      }
      return left.documentOrder - right.documentOrder;
    });
  }
  function nextCycleIndex(currentIndex, length) {
    if (length <= 0) return -1;
    return currentIndex < 0 || currentIndex >= length ? 0 : (currentIndex + 1) % length;
  }
  function resolveSelectionIndex(previouslySelected, candidates2, preserve) {
    if (preserve && previouslySelected !== void 0) {
      return candidates2.indexOf(previouslySelected);
    }
    return -1;
  }
  function hasRisen(currentlyDown, wasDown) {
    return currentlyDown && !wasDown;
  }

  // src/core/settings.ts
  var DEFAULT_SETTINGS = Object.freeze({
    deadzone: 0.2,
    coneAngle: 30,
    triggerThreshold: 0.5,
    neutralBehavior: "retain",
    candidateStart: "first",
    inclusionMode: "center",
    distanceMode: "center",
    tieBreak: "dom"
  });
  var LIMITS = {
    deadzone: { min: 0.05, max: 0.6 },
    coneAngle: { min: 5, max: 180 },
    triggerThreshold: { min: 0.1, max: 1 }
  };
  function numericValue(value, fallback, min, max) {
    const parsed = typeof value === "number" ? value : Number(value);
    if (!Number.isFinite(parsed)) return fallback;
    return Math.min(max, Math.max(min, parsed));
  }
  function normalizeSettings(value) {
    const source = value && typeof value === "object" ? value : {};
    return {
      deadzone: numericValue(source.deadzone, DEFAULT_SETTINGS.deadzone, LIMITS.deadzone.min, LIMITS.deadzone.max),
      coneAngle: numericValue(source.coneAngle, DEFAULT_SETTINGS.coneAngle, LIMITS.coneAngle.min, LIMITS.coneAngle.max),
      triggerThreshold: numericValue(source.triggerThreshold, DEFAULT_SETTINGS.triggerThreshold, LIMITS.triggerThreshold.min, LIMITS.triggerThreshold.max),
      neutralBehavior: source.neutralBehavior === "clear" ? "clear" : "retain",
      candidateStart: source.candidateStart === "preserve" ? "preserve" : "first",
      inclusionMode: source.inclusionMode === "intersects" ? "intersects" : "center",
      distanceMode: source.distanceMode === "nearest" ? "nearest" : "center",
      tieBreak: source.tieBreak === "top-left" ? "top-left" : "dom"
    };
  }

  // src/extension/content.ts
  var CLICKABLE_SELECTOR = [
    "a[href]",
    "area[href]",
    "button",
    "input:not([type='hidden'])",
    "select",
    "textarea",
    "summary",
    "[role='button']",
    "[role='link']",
    "[tabindex]:not([tabindex='-1'])",
    "[onclick]"
  ].join(",");
  var SVG_NS = "http://www.w3.org/2000/svg";
  var WEDGE_RADIUS = 4;
  var enabled = true;
  var activeTabOwned = false;
  var settings = { ...DEFAULT_SETTINGS };
  var frameId = null;
  var host = null;
  var shadow = null;
  var svg = null;
  var conePath = null;
  var spotlightCutout = null;
  var spotlightMask = null;
  var dimLayer = null;
  var marksLayer = null;
  var statusBadge = null;
  var observer = null;
  var candidates = [];
  var selectedIndex = -1;
  var activeDirection = null;
  var lastActiveDirection = null;
  var pinnedDirection = null;
  var pinned = false;
  var xWasDown = false;
  var triggerWasDown = false;
  var stickClickWasDown = false;
  var ignoreCurrentButtons = true;
  var refreshNeeded = true;
  var lastRefreshAt = 0;
  var lastDirectionAngle = null;
  var connectedGamepad = false;
  var supported = typeof navigator.getGamepads === "function";
  var temporaryTabIndexTargets = /* @__PURE__ */ new WeakSet();
  var focusChangeSequence = 0;
  function centerPoint() {
    return { x: window.innerWidth / 2, y: window.innerHeight / 2 };
  }
  function candidateIsVisible(element) {
    if (!element.isConnected || element.matches(":disabled, [aria-disabled='true'], [hidden], [inert]") || element.closest("[inert], [aria-hidden='true']")) return false;
    const style = getComputedStyle(element);
    if (style.display === "none" || style.visibility === "hidden" || style.visibility === "collapse" || style.pointerEvents === "none") return false;
    const rect = element.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0 && rect.right > 0 && rect.bottom > 0 && rect.left < window.innerWidth && rect.top < window.innerHeight;
  }
  function collectCandidates(direction) {
    const raw = [...document.querySelectorAll(CLICKABLE_SELECTOR)];
    const possible = [];
    raw.forEach((element, documentOrder) => {
      if (host?.contains(element) || !candidateIsVisible(element)) return;
      const rect = element.getBoundingClientRect();
      possible.push({
        id: element,
        rect: { left: rect.left, top: rect.top, right: rect.right, bottom: rect.bottom },
        documentOrder
      });
    });
    return rankCandidates(
      possible,
      centerPoint(),
      direction,
      settings.coneAngle,
      settings.inclusionMode,
      settings.distanceMode,
      settings.tieBreak
    );
  }
  function createSvg(tag) {
    return document.createElementNS(SVG_NS, tag);
  }
  function setStatus(text, tone) {
    if (!statusBadge) return;
    statusBadge.textContent = text;
    statusBadge.dataset.tone = tone;
  }
  function setOverlayVisibility(visible) {
    host?.style.setProperty("display", visible ? "block" : "none", "important");
  }
  function ensureOverlay() {
    if (host && shadow) return;
    host = document.createElement("div");
    host.setAttribute("data-joy-of-nav", "overlay");
    host.setAttribute("aria-hidden", "true");
    host.style.cssText = "all:initial!important;position:fixed!important;inset:0!important;width:100vw!important;height:100vh!important;z-index:2147483647!important;pointer-events:none!important;display:block!important;";
    shadow = host.attachShadow({ mode: "closed" });
    shadow.innerHTML = `
    <style>
      :host { all: initial; }
      svg { position: fixed; inset: 0; width: 100vw; height: 100vh; overflow: hidden; pointer-events: none; }
      #dim { fill: rgba(5, 10, 9, .68); }
      #cone { fill: rgba(93, 190, 131, .13); stroke: rgba(113, 215, 151, .72); stroke-width: 1.5; }
      #axis { stroke: rgba(201, 240, 113, .92); stroke-width: 2; stroke-dasharray: 3 5; }
      .candidate { fill: rgba(199, 236, 115, .08); stroke: rgba(194, 229, 121, .58); stroke-width: 1.5; }
      .candidate.selected { fill: rgba(199, 236, 115, .18); stroke: #d6ff83; stroke-width: 2.5; }
      .index-label { fill: #f3ffd9; stroke: rgba(21, 49, 35, .9); stroke-width: 3px; paint-order: stroke; font: 700 13px/1 system-ui, sans-serif; text-anchor: middle; }
      #status { position: fixed; left: 16px; top: 16px; padding: 8px 11px; border: 1px solid rgba(255,255,255,.13); border-radius: 10px; background: rgba(22, 38, 31, .86); color: #f0f5ef; box-shadow: 0 7px 26px rgba(0,0,0,.12); font: 600 11px/1 system-ui, sans-serif; letter-spacing: .015em; backdrop-filter: blur(8px); }
      #status[data-tone="active"] { color: #dcff9b; }
      #status[data-tone="unsupported"] { color: #ffd1b9; }
    </style>
    <svg aria-hidden="true" viewBox="0 0 1 1">
      <defs><mask id="spotlightMask" style="mask-type:luminance" maskUnits="userSpaceOnUse" maskContentUnits="userSpaceOnUse" x="0" y="0" width="0" height="0"><rect id="maskBase" x="0" y="0" width="0" height="0" fill="white"></rect><path id="spotlightCutout" d="" fill="black"></path></mask></defs>
      <rect id="dim" x="0" y="0" width="0" height="0" mask="url(#spotlightMask)" visibility="hidden"></rect>
      <path id="cone" d="" visibility="hidden"></path>
      <line id="axis" x1="0" y1="0" x2="0" y2="0" visibility="hidden"></line>
      <g id="marks"></g>
    </svg>
    <div id="status" role="presentation" data-tone="idle">Joy of Nav \xB7 \uC5F0\uACB0 \uB300\uAE30</div>
  `;
    svg = shadow.querySelector("svg");
    conePath = shadow.querySelector("#cone");
    spotlightCutout = shadow.querySelector("#spotlightCutout");
    spotlightMask = shadow.querySelector("#spotlightMask");
    dimLayer = shadow.querySelector("#dim");
    marksLayer = shadow.querySelector("#marks");
    statusBadge = shadow.querySelector("#status");
    document.documentElement.append(host);
  }
  function createFanPath(origin, direction) {
    const angle = Math.atan2(direction.y, direction.x);
    const half = settings.coneAngle * Math.PI / 360;
    const radius = Math.hypot(window.innerWidth, window.innerHeight) * WEDGE_RADIUS;
    const start = { x: origin.x + Math.cos(angle - half) * radius, y: origin.y + Math.sin(angle - half) * radius };
    const end = { x: origin.x + Math.cos(angle + half) * radius, y: origin.y + Math.sin(angle + half) * radius };
    return `M ${origin.x} ${origin.y} L ${start.x} ${start.y} A ${radius} ${radius} 0 0 1 ${end.x} ${end.y} Z`;
  }
  function render() {
    if (!enabled || !host || !svg || !conePath || !spotlightCutout || !spotlightMask || !dimLayer || !marksLayer) return;
    const overlayDirection = activeDirection ?? (pinned ? pinnedDirection : null);
    if (!overlayDirection) {
      setOverlayVisibility(false);
      return;
    }
    setOverlayVisibility(true);
    svg.setAttribute("viewBox", `0 0 ${window.innerWidth} ${window.innerHeight}`);
    spotlightMask.setAttribute("width", String(window.innerWidth));
    spotlightMask.setAttribute("height", String(window.innerHeight));
    const maskBase = shadow.querySelector("#maskBase");
    maskBase.setAttribute("width", String(window.innerWidth));
    maskBase.setAttribute("height", String(window.innerHeight));
    dimLayer.setAttribute("width", String(window.innerWidth));
    dimLayer.setAttribute("height", String(window.innerHeight));
    const origin = centerPoint();
    const fanPath = createFanPath(origin, overlayDirection);
    spotlightCutout.setAttribute("d", fanPath);
    dimLayer.setAttribute("visibility", "visible");
    conePath.setAttribute("d", fanPath);
    conePath.setAttribute("visibility", "visible");
    const axis = shadow.querySelector("#axis");
    const length = Math.hypot(window.innerWidth, window.innerHeight) * 2;
    axis.setAttribute("x1", String(origin.x));
    axis.setAttribute("y1", String(origin.y));
    axis.setAttribute("x2", String(origin.x + overlayDirection.x / overlayDirection.magnitude * length));
    axis.setAttribute("y2", String(origin.y + overlayDirection.y / overlayDirection.magnitude * length));
    axis.setAttribute("visibility", "visible");
    marksLayer.replaceChildren();
    candidates.forEach((candidate, index) => {
      const rect = candidate.rect;
      const mark = createSvg("rect");
      mark.setAttribute("x", String(rect.left));
      mark.setAttribute("y", String(rect.top));
      mark.setAttribute("width", String(Math.max(1, rect.right - rect.left)));
      mark.setAttribute("height", String(Math.max(1, rect.bottom - rect.top)));
      mark.setAttribute("rx", "5");
      mark.setAttribute("class", index === selectedIndex ? "candidate selected" : "candidate");
      marksLayer.append(mark);
      if (index < 24) {
        const label = createSvg("text");
        label.setAttribute("x", String((rect.left + rect.right) / 2));
        label.setAttribute("y", String(Math.max(14, rect.top - 5)));
        label.setAttribute("class", "index-label");
        label.textContent = String(index + 1);
        marksLayer.append(label);
      }
    });
    if (!supported) setStatus("\uC774 \uD398\uC774\uC9C0\uB294 Gamepad API\uB97C \uC9C0\uC6D0\uD558\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4", "unsupported");
    else if (!connectedGamepad) setStatus("\uAC8C\uC784\uD328\uB4DC \uC5F0\uACB0 \uB300\uAE30 \xB7 \uD45C\uC900 \uB9E4\uD551 \uD544\uC694", "idle");
    else if (pinned && !activeDirection) setStatus(`\uACE0\uC815 \xB7 \uD6C4\uBCF4 ${candidates.length}\uAC1C`, "active");
    else if (pinned) setStatus(`\uACE0\uC815 \xB7 \uD0D0\uC0C9 \uC911 \xB7 \uD6C4\uBCF4 ${candidates.length}\uAC1C`, "active");
    else setStatus(`\uD0D0\uC0C9 \uC911 \xB7 \uD6C4\uBCF4 ${candidates.length}\uAC1C`, "active");
  }
  function sameCandidates(left, right) {
    return left.length === right.length && left.every((candidate, index) => candidate.id === right[index]?.id);
  }
  function refreshCandidates(direction) {
    const nextCandidates = collectCandidates(direction);
    if (!sameCandidates(candidates, nextCandidates)) {
      const previouslySelected = candidates[selectedIndex]?.id;
      candidates = nextCandidates;
      selectedIndex = resolveSelectionIndex(
        previouslySelected,
        candidates.map((candidate) => candidate.id),
        settings.candidateStart === "preserve"
      );
    } else {
      candidates = nextCandidates;
    }
    refreshNeeded = false;
    lastRefreshAt = performance.now();
    lastDirectionAngle = Math.atan2(direction.y, direction.x);
  }
  function resetInputEdges() {
    xWasDown = false;
    triggerWasDown = false;
    stickClickWasDown = false;
    ignoreCurrentButtons = true;
    connectedGamepad = false;
  }
  function gamepadFrame() {
    frameId = null;
    if (!enabled || !activeTabOwned || document.visibilityState !== "visible" || document.hasFocus?.() === false) return;
    let gamepads = [];
    try {
      gamepads = [...navigator.getGamepads()];
    } catch {
      gamepads = [];
    }
    const gamepad = gamepads.find((item) => item?.connected && item.mapping === "standard" && item.axes.length >= 2 && item.buttons.length >= 11) ?? null;
    connectedGamepad = Boolean(gamepad);
    if (!gamepad) {
      if (activeDirection && !pinned && settings.neutralBehavior === "clear") {
        candidates = [];
        selectedIndex = -1;
      }
      activeDirection = null;
      lastDirectionAngle = null;
      resetInputEdges();
      render();
      frameId = requestAnimationFrame(gamepadFrame);
      return;
    }
    const direction = readDirection(gamepad.axes[0], gamepad.axes[1], settings.deadzone);
    const hadActiveDirection = activeDirection !== null;
    if (direction) {
      const angle = Math.atan2(direction.y, direction.x);
      const angleChanged = lastDirectionAngle === null || Math.abs(Math.atan2(Math.sin(angle - lastDirectionAngle), Math.cos(angle - lastDirectionAngle))) > Math.PI / 90;
      if (refreshNeeded || angleChanged || performance.now() - lastRefreshAt >= 180) refreshCandidates(direction);
      activeDirection = direction;
      lastActiveDirection = direction;
      if (pinned) pinnedDirection = direction;
    } else {
      activeDirection = null;
      if (!pinned) lastDirectionAngle = null;
    }
    const xDown = gamepad.buttons[2].pressed;
    const triggerValue = Number.isFinite(gamepad.buttons[7].value) ? gamepad.buttons[7].value : Number(gamepad.buttons[7].pressed);
    const triggerDown = triggerValue >= settings.triggerThreshold;
    const stickClickDown = gamepad.buttons[10].pressed;
    if (ignoreCurrentButtons) {
      xWasDown = xDown;
      triggerWasDown = triggerDown;
      stickClickWasDown = stickClickDown;
      ignoreCurrentButtons = false;
    } else {
      if (hasRisen(stickClickDown, stickClickWasDown)) {
        if (pinned) {
          pinned = false;
          pinnedDirection = null;
        } else {
          const directionToPin = activeDirection ?? lastActiveDirection;
          if (directionToPin) {
            pinned = true;
            pinnedDirection = directionToPin;
            refreshNeeded = true;
          }
        }
      }
      const canAct = activeDirection !== null || pinned;
      if (canAct && hasRisen(xDown, xWasDown) && candidates.length) {
        selectedIndex = nextCycleIndex(selectedIndex, candidates.length);
        focusSelected();
        render();
      }
      if (canAct && hasRisen(triggerDown, triggerWasDown) && clickSelected() && pinned) {
        pinned = false;
        pinnedDirection = null;
        if (!activeDirection && settings.neutralBehavior === "clear") {
          candidates = [];
          selectedIndex = -1;
        }
      }
      xWasDown = xDown;
      triggerWasDown = triggerDown;
      stickClickWasDown = stickClickDown;
    }
    if (!activeDirection && pinned && pinnedDirection && (refreshNeeded || performance.now() - lastRefreshAt >= 180)) {
      refreshCandidates(pinnedDirection);
    }
    if (!activeDirection && !pinned && hadActiveDirection && settings.neutralBehavior === "clear") {
      candidates = [];
      selectedIndex = -1;
    }
    render();
    frameId = requestAnimationFrame(gamepadFrame);
  }
  function clickSelected() {
    const element = candidates[selectedIndex]?.id;
    if (!element || !candidateIsVisible(element)) {
      refreshNeeded = true;
      return false;
    }
    try {
      element.click();
      return true;
    } catch {
      refreshNeeded = true;
      return false;
    }
  }
  function focusSelected() {
    const element = candidates[selectedIndex]?.id;
    if (!element || !candidateIsVisible(element)) {
      refreshNeeded = true;
      return false;
    }
    const focusWithoutScroll = () => {
      try {
        element.focus({ preventScroll: true });
      } catch {
        element.focus();
      }
    };
    focusWithoutScroll();
    if (document.activeElement === element) return true;
    if (element.hasAttribute("tabindex")) return false;
    element.setAttribute("tabindex", "-1");
    temporaryTabIndexTargets.add(element);
    element.addEventListener("blur", () => {
      if (!temporaryTabIndexTargets.delete(element)) return;
      if (element.getAttribute("tabindex") === "-1") element.removeAttribute("tabindex");
    }, { once: true });
    focusWithoutScroll();
    if (document.activeElement === element) return true;
    if (temporaryTabIndexTargets.delete(element)) element.removeAttribute("tabindex");
    refreshNeeded = true;
    return false;
  }
  function startLoop() {
    if (!enabled || !activeTabOwned || frameId !== null) return;
    supported = typeof navigator.getGamepads === "function";
    ensureOverlay();
    if (!supported) {
      render();
      return;
    }
    render();
    frameId = requestAnimationFrame(gamepadFrame);
  }
  function stopLoop() {
    if (frameId !== null) cancelAnimationFrame(frameId);
    frameId = null;
    activeDirection = null;
    if (settings.neutralBehavior === "clear" && !pinned) {
      candidates = [];
      selectedIndex = -1;
    }
    refreshNeeded = true;
    resetInputEdges();
    setOverlayVisibility(false);
  }
  function status() {
    return { enabled, supported, gamepadConnected: connectedGamepad };
  }
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === "joy-nav:tab-ownership" && typeof message.active === "boolean") {
      const pageIsFocused = document.visibilityState === "visible" && document.hasFocus?.() !== false;
      activeTabOwned = message.active && pageIsFocused;
      if (activeTabOwned) {
        resetInputEdges();
        startLoop();
      } else {
        stopLoop();
      }
      sendResponse({ active: activeTabOwned });
      return false;
    }
    if (message?.type === "joy-nav:get-status") {
      sendResponse(status());
      return false;
    }
    if (message?.type === "joy-nav:set-enabled" && typeof message.enabled === "boolean") {
      enabled = message.enabled;
      if (enabled) startLoop();
      else {
        pinned = false;
        pinnedDirection = null;
        lastActiveDirection = null;
        stopLoop();
      }
      sendResponse(status());
      return false;
    }
    return false;
  });
  chrome.storage.local.get("settings").then(({ settings: savedSettings }) => {
    settings = normalizeSettings(savedSettings);
    refreshNeeded = true;
    if (enabled) onVisibilityChange();
  }).catch(() => {
    settings = { ...DEFAULT_SETTINGS };
    if (enabled) onVisibilityChange();
  });
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== "local" || !changes.settings?.newValue) return;
    const previous = settings;
    settings = normalizeSettings(changes.settings.newValue);
    if (previous.neutralBehavior !== settings.neutralBehavior && !activeDirection && !pinned && settings.neutralBehavior === "clear") {
      candidates = [];
      selectedIndex = -1;
    }
    refreshNeeded = true;
    render();
  });
  function onVisibilityChange() {
    const sequence = ++focusChangeSequence;
    const pageIsFocused = document.visibilityState === "visible" && document.hasFocus?.() !== false;
    if (!pageIsFocused) {
      relinquishTabOwnership();
      return;
    }
    void chrome.runtime.sendMessage({ type: "joy-nav:claim-active-tab" }).then((response) => {
      if (sequence !== focusChangeSequence) {
        if (response?.active) void chrome.runtime.sendMessage({ type: "joy-nav:release-active-tab" }).catch(() => void 0);
        return;
      }
      activeTabOwned = response?.active === true;
      if (activeTabOwned && document.visibilityState === "visible" && document.hasFocus?.() !== false) {
        resetInputEdges();
        startLoop();
      } else {
        activeTabOwned = false;
        stopLoop();
      }
    }).catch(() => {
      if (sequence !== focusChangeSequence) return;
      if (document.visibilityState === "visible" && document.hasFocus?.() !== false) {
        activeTabOwned = true;
        resetInputEdges();
        startLoop();
      } else {
        relinquishTabOwnership();
      }
    });
  }
  function relinquishTabOwnership() {
    ++focusChangeSequence;
    activeTabOwned = false;
    stopLoop();
    void chrome.runtime.sendMessage({ type: "joy-nav:release-active-tab" }).catch(() => void 0);
  }
  document.addEventListener("visibilitychange", onVisibilityChange);
  window.addEventListener("focus", onVisibilityChange);
  window.addEventListener("blur", relinquishTabOwnership);
  window.addEventListener("resize", () => {
    refreshNeeded = true;
    render();
  }, { passive: true });
  window.addEventListener("scroll", () => {
    refreshNeeded = true;
  }, { capture: true, passive: true });
  window.addEventListener("gamepadconnected", () => {
    refreshNeeded = true;
    startLoop();
  });
  window.addEventListener("gamepaddisconnected", () => {
    connectedGamepad = false;
    resetInputEdges();
    refreshNeeded = true;
  });
  observer = new MutationObserver((records) => {
    if (records.some((record) => !host?.contains(record.target))) refreshNeeded = true;
  });
  observer.observe(document.documentElement, {
    subtree: true,
    childList: true,
    attributes: true,
    attributeFilter: ["class", "style", "hidden", "disabled", "aria-disabled", "aria-hidden", "href", "tabindex"]
  });
})();
