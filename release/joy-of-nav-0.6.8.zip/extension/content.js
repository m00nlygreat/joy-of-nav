"use strict";
(() => {
  // src/core/navigation.ts
  function readDirection(x, y, deadzone) {
    const magnitude = Math.hypot(x, y);
    if (!Number.isFinite(magnitude) || magnitude <= deadzone) return null;
    return { x, y, magnitude };
  }
  function pointInCone(point, origin, direction, fullAngle) {
    const dx = point.x - origin.x;
    const dy = point.y - origin.y;
    const pointLength = Math.hypot(dx, dy);
    const directionLength = Math.hypot(direction.x, direction.y);
    if (pointLength === 0 || directionLength === 0) return true;
    const cosine = Math.min(1, Math.max(-1, (dx * direction.x + dy * direction.y) / (pointLength * directionLength)));
    const angle = Math.acos(cosine) * 180 / Math.PI;
    return angle <= fullAngle / 2 + 1e-8;
  }
  function corners(rect) {
    return [
      { x: rect.left, y: rect.top },
      { x: rect.right, y: rect.top },
      { x: rect.right, y: rect.bottom },
      { x: rect.left, y: rect.bottom }
    ];
  }
  function segmentIntersectsRect(start, end, rect) {
    const dx = end.x - start.x;
    const dy = end.y - start.y;
    let t0 = 0;
    let t1 = 1;
    const tests = [
      [-dx, start.x - rect.left],
      [dx, rect.right - start.x],
      [-dy, start.y - rect.top],
      [dy, rect.bottom - start.y]
    ];
    for (const [p, q] of tests) {
      if (p === 0) {
        if (q < 0) return false;
        continue;
      }
      const t = q / p;
      if (p < 0) t0 = Math.max(t0, t);
      else t1 = Math.min(t1, t);
      if (t0 > t1) return false;
    }
    return true;
  }
  function rayIntersectsRect(origin, direction, rect) {
    const length = Math.max(...corners(rect).map((point) => Math.hypot(point.x - origin.x, point.y - origin.y))) + 1;
    const magnitude = Math.hypot(direction.x, direction.y);
    if (!magnitude) return false;
    const end = { x: origin.x + direction.x / magnitude * length, y: origin.y + direction.y / magnitude * length };
    return segmentIntersectsRect(origin, end, rect);
  }
  function rectIntersectsCone(rect, origin, direction, fullAngle) {
    if (corners(rect).some((corner) => pointInCone(corner, origin, direction, fullAngle))) return true;
    const nearest = {
      x: Math.min(rect.right, Math.max(rect.left, origin.x)),
      y: Math.min(rect.bottom, Math.max(rect.top, origin.y))
    };
    if (pointInCone(nearest, origin, direction, fullAngle)) return true;
    const axisAngle = Math.atan2(direction.y, direction.x);
    const halfAngle = fullAngle * Math.PI / 360;
    const start = { x: Math.cos(axisAngle - halfAngle), y: Math.sin(axisAngle - halfAngle) };
    const end = { x: Math.cos(axisAngle + halfAngle), y: Math.sin(axisAngle + halfAngle) };
    return rayIntersectsRect(origin, direction, rect) || rayIntersectsRect(origin, start, rect) || rayIntersectsRect(origin, end, rect);
  }
  function cylinderCoordinates(point, origin, unitDirection) {
    const dx = point.x - origin.x;
    const dy = point.y - origin.y;
    return {
      x: dx * unitDirection.x + dy * unitDirection.y,
      y: dx * -unitDirection.y + dy * unitDirection.x
    };
  }
  function pointInCylinder(point, origin, direction, thickness) {
    const directionLength = Math.hypot(direction.x, direction.y);
    if (!directionLength) return false;
    const coordinates = cylinderCoordinates(point, origin, { x: direction.x / directionLength, y: direction.y / directionLength });
    const halfThickness = Math.max(0, thickness) / 2;
    return coordinates.x >= -1e-8 && Math.abs(coordinates.y) <= halfThickness + 1e-8 || Math.hypot(coordinates.x, coordinates.y) <= halfThickness + 1e-8;
  }
  function clipPolygon(polygon, signedDistance) {
    if (!polygon.length) return [];
    const clipped = [];
    let previous = polygon[polygon.length - 1];
    let previousDistance = signedDistance(previous);
    let previousInside = previousDistance >= -1e-8;
    for (const current of polygon) {
      const currentDistance = signedDistance(current);
      const currentInside = currentDistance >= -1e-8;
      if (currentInside !== previousInside) {
        const denominator = previousDistance - currentDistance;
        const amount = Math.abs(denominator) < 1e-12 ? 0 : previousDistance / denominator;
        clipped.push({
          x: previous.x + (current.x - previous.x) * amount,
          y: previous.y + (current.y - previous.y) * amount
        });
      }
      if (currentInside) clipped.push(current);
      previous = current;
      previousDistance = currentDistance;
      previousInside = currentInside;
    }
    return clipped;
  }
  function rectIntersectsCylinder(rect, origin, direction, thickness) {
    const directionLength = Math.hypot(direction.x, direction.y);
    if (!directionLength) return false;
    const unitDirection = { x: direction.x / directionLength, y: direction.y / directionLength };
    const halfThickness = Math.max(0, thickness) / 2;
    const nearest = {
      x: Math.min(rect.right, Math.max(rect.left, origin.x)),
      y: Math.min(rect.bottom, Math.max(rect.top, origin.y))
    };
    if (Math.hypot(nearest.x - origin.x, nearest.y - origin.y) <= halfThickness + 1e-8) return true;
    const along = (point) => cylinderCoordinates(point, origin, unitDirection).x;
    const across = (point) => cylinderCoordinates(point, origin, unitDirection).y;
    let polygon = corners(rect);
    polygon = clipPolygon(polygon, along);
    polygon = clipPolygon(polygon, (point) => halfThickness - across(point));
    polygon = clipPolygon(polygon, (point) => halfThickness + across(point));
    return polygon.length > 0;
  }
  function candidateInCone(candidate, origin, direction, fullAngle, mode) {
    if (mode === "intersects") return rectIntersectsCone(candidate.rect, origin, direction, fullAngle);
    return pointInCone({
      x: (candidate.rect.left + candidate.rect.right) / 2,
      y: (candidate.rect.top + candidate.rect.bottom) / 2
    }, origin, direction, fullAngle);
  }
  function candidateInSpotlight(candidate, origin, direction, shape, size, viewportShortSide, mode) {
    if (shape === "cone") return candidateInCone(candidate, origin, direction, size, mode);
    const thickness = Math.max(0, viewportShortSide) * size / 100;
    if (mode === "intersects") return rectIntersectsCylinder(candidate.rect, origin, direction, thickness);
    return pointInCylinder({
      x: (candidate.rect.left + candidate.rect.right) / 2,
      y: (candidate.rect.top + candidate.rect.bottom) / 2
    }, origin, direction, thickness);
  }
  function candidateDistance(candidate, origin, mode) {
    const point = mode === "center" ? { x: (candidate.rect.left + candidate.rect.right) / 2, y: (candidate.rect.top + candidate.rect.bottom) / 2 } : {
      x: Math.min(candidate.rect.right, Math.max(candidate.rect.left, origin.x)),
      y: Math.min(candidate.rect.bottom, Math.max(candidate.rect.top, origin.y))
    };
    return Math.hypot(point.x - origin.x, point.y - origin.y);
  }
  function rankSpotlightCandidates(candidates, origin, direction, shape, size, viewportShortSide, inclusionMode, distanceMode, tieBreak) {
    return candidates.filter((candidate) => candidateInSpotlight(candidate, origin, direction, shape, size, viewportShortSide, inclusionMode)).slice().sort((left, right) => {
      const distanceDelta = candidateDistance(left, origin, distanceMode) - candidateDistance(right, origin, distanceMode);
      if (Math.abs(distanceDelta) > 0.01) return distanceDelta;
      if (tieBreak === "top-left") {
        const topDelta = left.rect.top - right.rect.top;
        if (Math.abs(topDelta) > 0.01) return topDelta;
        const leftDelta = left.rect.left - right.rect.left;
        if (Math.abs(leftDelta) > 0.01) return leftDelta;
      }
      return left.documentOrder - right.documentOrder;
    });
  }
  function nextCycleIndex(currentIndex, length) {
    if (length <= 0) return -1;
    return currentIndex < 0 || currentIndex >= length ? 0 : (currentIndex + 1) % length;
  }
  function resolveSelectionIndex(previouslySelected, candidates, preserve) {
    if (preserve && previouslySelected !== void 0) {
      return candidates.indexOf(previouslySelected);
    }
    return -1;
  }
  function hasRisen(currentlyDown, wasDown) {
    return currentlyDown && !wasDown;
  }

  // src/core/settings.ts
  var DEFAULT_SCROLL_SPEED_CURVE = [0, 0.58, 0.82, 0.95, 1];
  var DEFAULT_POINTER_SPEED_CURVE = [0, 0.5, 0.76, 0.92, 1];
  var DEFAULT_SETTINGS = Object.freeze({
    deadzone: 0.2,
    spotlightShape: "cone",
    spotlightSize: 30,
    triggerThreshold: 0.5,
    neutralBehavior: "retain",
    candidateStart: "first",
    inclusionMode: "center",
    distanceMode: "center",
    tieBreak: "dom",
    scrollSpeedCurve: DEFAULT_SCROLL_SPEED_CURVE,
    pointerSpeedCurve: DEFAULT_POINTER_SPEED_CURVE
  });
  var LIMITS = {
    deadzone: { min: 0.05, max: 0.6 },
    triggerThreshold: { min: 0.1, max: 1 }
  };
  var SPOTLIGHT_SIZE_LIMITS = {
    cone: { min: 5, max: 180 },
    cylinder: { min: 5, max: 100 }
  };
  function numericValue(value, fallback, min, max) {
    const parsed = typeof value === "number" ? value : Number(value);
    if (!Number.isFinite(parsed)) return fallback;
    return Math.min(max, Math.max(min, parsed));
  }
  function normalizeSpeedCurve(value, fallback) {
    if (!Array.isArray(value) || value.length < 5) return [...fallback];
    const curve = [
      0,
      numericValue(value[1], fallback[1], 0, 1),
      numericValue(value[2], fallback[2], 0, 1),
      numericValue(value[3], fallback[3], 0, 1),
      1
    ];
    for (let index = 2; index <= 3; index += 1) {
      curve[index] = Math.max(curve[index - 1], curve[index]);
    }
    return curve;
  }
  function mapSpeedCurve(value, curve) {
    const input = Math.min(1, Math.max(0, Number.isFinite(value) ? value : 0));
    const segment = Math.min(3, Math.floor(input * 4));
    const amount = input * 4 - segment;
    return curve[segment] + (curve[segment + 1] - curve[segment]) * amount;
  }
  function normalizeSettings(value) {
    const source = value && typeof value === "object" ? value : {};
    const legacyConeAngle = value && typeof value === "object" ? value.coneAngle : void 0;
    const spotlightShape = source.spotlightShape === "cylinder" ? "cylinder" : "cone";
    const spotlightLimits = SPOTLIGHT_SIZE_LIMITS[spotlightShape];
    return {
      deadzone: numericValue(source.deadzone, DEFAULT_SETTINGS.deadzone, LIMITS.deadzone.min, LIMITS.deadzone.max),
      spotlightShape,
      // Migrate the earlier coneAngle preference to the shared spotlight-size setting.
      spotlightSize: numericValue(source.spotlightSize ?? legacyConeAngle, DEFAULT_SETTINGS.spotlightSize, spotlightLimits.min, spotlightLimits.max),
      triggerThreshold: numericValue(source.triggerThreshold, DEFAULT_SETTINGS.triggerThreshold, LIMITS.triggerThreshold.min, LIMITS.triggerThreshold.max),
      neutralBehavior: source.neutralBehavior === "clear" ? "clear" : "retain",
      candidateStart: source.candidateStart === "preserve" ? "preserve" : "first",
      inclusionMode: source.inclusionMode === "intersects" ? "intersects" : "center",
      distanceMode: source.distanceMode === "nearest" ? "nearest" : "center",
      tieBreak: source.tieBreak === "top-left" ? "top-left" : "dom",
      scrollSpeedCurve: normalizeSpeedCurve(source.scrollSpeedCurve, DEFAULT_SCROLL_SPEED_CURVE),
      pointerSpeedCurve: normalizeSpeedCurve(source.pointerSpeedCurve, DEFAULT_POINTER_SPEED_CURVE)
    };
  }

  // src/extension/content.ts
  function installContentScript() {
    const extensionWindow = window;
    if (extensionWindow.__joyOfNavContentInitialized) return;
    extensionWindow.__joyOfNavContentInitialized = true;
    const CLICKABLE_SELECTOR = [
      "a[href]",
      "area[href]",
      "button",
      "input:not([type='hidden'])",
      "select",
      "textarea",
      "summary",
      "[role='button']",
      "[role='link']",
      "[tabindex]:not([tabindex='-1'])",
      "[onclick]"
    ].join(",");
    const SVG_NS = "http://www.w3.org/2000/svg";
    const WEDGE_RADIUS = 4;
    let enabled = true;
    let activeTabOwned = false;
    let settings = { ...DEFAULT_SETTINGS };
    let frameId = null;
    let host = null;
    let shadow = null;
    let svg = null;
    let spotlightCutout = null;
    let spotlightMask = null;
    let dimLayer = null;
    let selectedMarkLayer = null;
    let candidateNumbersLayer = null;
    let cursorLayer = null;
    let statusBadge = null;
    let observer = null;
    let candidates = [];
    let selectedIndex = -1;
    let candidateMarksDirty = true;
    let activeDirection = null;
    let lastActiveDirection = null;
    let pinnedDirection = null;
    let pinned = false;
    let xWasDown = false;
    let rightTriggerWasDown = false;
    let leftTriggerWasDown = false;
    let leftStickClickWasDown = false;
    let rightStickClickWasDown = false;
    let leftBumperWasDown = false;
    let rightBumperWasDown = false;
    let aWasDown = false;
    let bWasDown = false;
    let arrowKeyRepeatAt = /* @__PURE__ */ new Map();
    let ignoreCurrentButtons = true;
    let refreshNeeded = true;
    let lastRefreshAt = 0;
    let lastDirectionAngle = null;
    let smoothedLeftStick = { x: 0, y: 0 };
    let connectedGamepad = false;
    let supported = typeof navigator.getGamepads === "function";
    let overlayDismissedUntilNeutral = false;
    let virtualPointer = { x: 0, y: 0 };
    let virtualPointerVisible = false;
    let virtualPointerVisibleUntil = 0;
    let yModeActive = false;
    let lastLeftStickScrollAngle = null;
    let lastRightStickCycleAngle = null;
    let rightStickCycleRemainder = 0;
    let pointerInitialized = false;
    let lastFrameAt = 0;
    const temporaryTabIndexTargets = /* @__PURE__ */ new WeakSet();
    let focusChangeSequence = 0;
    const ARROW_BUTTONS = [
      { button: 12, key: "ArrowUp", code: "ArrowUp" },
      { button: 13, key: "ArrowDown", code: "ArrowDown" },
      { button: 14, key: "ArrowLeft", code: "ArrowLeft" },
      { button: 15, key: "ArrowRight", code: "ArrowRight" }
    ];
    const ARROW_REPEAT_DELAY = 420;
    const ARROW_REPEAT_INTERVAL = 75;
    const POINTER_SPEED = 760;
    const POINTER_DISPLAY_DURATION = 1e3;
    const WHEEL_SPEED = 780;
    const RIGHT_STICK_CANDIDATE_STEPS_PER_TURN = 12;
    const SPOTLIGHT_SMOOTHING_SECONDS = 0.06;
    function centerPoint() {
      return { x: window.innerWidth / 2, y: window.innerHeight / 2 };
    }
    function candidateIsVisible(element) {
      if (!element.isConnected || element.matches(":disabled, [aria-disabled='true'], [hidden], [inert]") || element.closest("[inert], [aria-hidden='true']")) return false;
      const style = getComputedStyle(element);
      if (style.display === "none" || style.visibility === "hidden" || style.visibility === "collapse" || style.pointerEvents === "none") return false;
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0 && rect.right > 0 && rect.bottom > 0 && rect.left < window.innerWidth && rect.top < window.innerHeight;
    }
    function collectCandidates(direction) {
      const raw = [...document.querySelectorAll(CLICKABLE_SELECTOR)];
      const possible = [];
      raw.forEach((element, documentOrder) => {
        if (host?.contains(element) || !candidateIsVisible(element)) return;
        const rect = element.getBoundingClientRect();
        possible.push({
          id: element,
          rect: { left: rect.left, top: rect.top, right: rect.right, bottom: rect.bottom },
          documentOrder
        });
      });
      return rankSpotlightCandidates(
        possible,
        centerPoint(),
        direction,
        settings.spotlightShape,
        settings.spotlightSize,
        Math.min(window.innerWidth, window.innerHeight),
        settings.inclusionMode,
        settings.distanceMode,
        settings.tieBreak
      );
    }
    function createSvg(tag) {
      return document.createElementNS(SVG_NS, tag);
    }
    function setStatus(text, tone) {
      if (!statusBadge) return;
      statusBadge.textContent = text;
      statusBadge.dataset.tone = tone;
    }
    function setOverlayVisibility(visible) {
      host?.style.setProperty("display", visible ? "block" : "none", "important");
    }
    function ensureOverlay() {
      if (host && shadow) return;
      host = document.createElement("div");
      host.setAttribute("data-joy-of-nav", "overlay");
      host.setAttribute("aria-hidden", "true");
      host.style.cssText = "all:initial!important;position:fixed!important;inset:0!important;width:100vw!important;height:100vh!important;z-index:2147483647!important;pointer-events:none!important;display:block!important;";
      shadow = host.attachShadow({ mode: "closed" });
      shadow.innerHTML = `
      <style>
        :host { all: initial; }
        svg { position: fixed; inset: 0; width: 100vw; height: 100vh; overflow: hidden; pointer-events: none; }
        #dim { fill: rgba(5, 10, 9, .68); }
        #selectedElement { fill: rgba(199, 236, 115, .18); }
        .candidateNumberBackground { fill: rgba(22, 38, 31, .96); stroke: rgba(214, 255, 131, .8); stroke-width: 1; }
        .candidateNumber { fill: #d6ff83; font: 700 14px/1 system-ui, sans-serif; text-anchor: middle; dominant-baseline: central; }
        .selectedCandidateNumber { fill: #d6ff83; stroke: rgba(5, 10, 9, .92); stroke-width: 3; stroke-linejoin: round; paint-order: stroke fill; font: 800 14px/1 system-ui, sans-serif; text-anchor: middle; dominant-baseline: central; }
        #virtualCursorOuter { fill: rgba(5, 10, 9, .7); stroke: #f6ffe8; stroke-width: 2; }
        #virtualCursorInner { fill: #d6ff83; stroke: #1c2814; stroke-width: 1; }
        #status { position: fixed; left: 16px; top: 16px; padding: 8px 11px; border: 1px solid rgba(255,255,255,.13); border-radius: 10px; background: rgba(22, 38, 31, .86); color: #f0f5ef; box-shadow: 0 7px 26px rgba(0,0,0,.12); font: 600 11px/1 system-ui, sans-serif; letter-spacing: .015em; backdrop-filter: blur(8px); }
        #status[data-tone="active"] { color: #dcff9b; }
        #status[data-tone="unsupported"] { color: #ffd1b9; }
      </style>
      <svg aria-hidden="true" viewBox="0 0 1 1">
        <defs><mask id="spotlightMask" style="mask-type:luminance" maskUnits="userSpaceOnUse" maskContentUnits="userSpaceOnUse" x="0" y="0" width="0" height="0"><rect id="maskBase" x="0" y="0" width="0" height="0" fill="white"></rect><path id="spotlightCutout" d="" fill="black"></path></mask></defs>
        <rect id="dim" x="0" y="0" width="0" height="0" mask="url(#spotlightMask)" visibility="hidden"></rect>
        <g id="selectedMark"></g>
        <g id="candidateNumbers"></g>
        <g id="virtualCursor" visibility="hidden"><circle id="virtualCursorOuter" r="10"></circle><circle id="virtualCursorInner" r="3.5"></circle></g>
      </svg>
      <div id="status" role="presentation" data-tone="idle">Joy of Nav \xB7 \uC5F0\uACB0 \uB300\uAE30</div>
    `;
      svg = shadow.querySelector("svg");
      spotlightCutout = shadow.querySelector("#spotlightCutout");
      spotlightMask = shadow.querySelector("#spotlightMask");
      dimLayer = shadow.querySelector("#dim");
      selectedMarkLayer = shadow.querySelector("#selectedMark");
      candidateNumbersLayer = shadow.querySelector("#candidateNumbers");
      cursorLayer = shadow.querySelector("#virtualCursor");
      statusBadge = shadow.querySelector("#status");
      document.documentElement.append(host);
    }
    function createSpotlightPath(origin, direction) {
      if (settings.spotlightShape === "cylinder") {
        const directionLength = Math.hypot(direction.x, direction.y);
        if (!directionLength) return "";
        const unitDirection = { x: direction.x / directionLength, y: direction.y / directionLength };
        const perpendicular = { x: -unitDirection.y, y: unitDirection.x };
        const halfThickness = Math.min(window.innerWidth, window.innerHeight) * settings.spotlightSize / 200;
        const radius2 = Math.hypot(window.innerWidth, window.innerHeight) * WEDGE_RADIUS;
        const end2 = { x: origin.x + unitDirection.x * radius2, y: origin.y + unitDirection.y * radius2 };
        const startA = { x: origin.x + perpendicular.x * halfThickness, y: origin.y + perpendicular.y * halfThickness };
        const startB = { x: origin.x - perpendicular.x * halfThickness, y: origin.y - perpendicular.y * halfThickness };
        const endA = { x: end2.x + perpendicular.x * halfThickness, y: end2.y + perpendicular.y * halfThickness };
        const endB = { x: end2.x - perpendicular.x * halfThickness, y: end2.y - perpendicular.y * halfThickness };
        const capSegments = 16;
        let path = `M ${startA.x} ${startA.y} L ${endA.x} ${endA.y} L ${endB.x} ${endB.y} L ${startB.x} ${startB.y}`;
        for (let index = 1; index <= capSegments; index += 1) {
          const angle2 = -Math.PI / 2 - Math.PI * index / capSegments;
          const along = Math.cos(angle2) * halfThickness;
          const across = Math.sin(angle2) * halfThickness;
          const point = {
            x: origin.x + unitDirection.x * along + perpendicular.x * across,
            y: origin.y + unitDirection.y * along + perpendicular.y * across
          };
          path += ` L ${point.x} ${point.y}`;
        }
        return `${path} Z`;
      }
      const angle = Math.atan2(direction.y, direction.x);
      const half = settings.spotlightSize * Math.PI / 360;
      const radius = Math.hypot(window.innerWidth, window.innerHeight) * WEDGE_RADIUS;
      const start = { x: origin.x + Math.cos(angle - half) * radius, y: origin.y + Math.sin(angle - half) * radius };
      const end = { x: origin.x + Math.cos(angle + half) * radius, y: origin.y + Math.sin(angle + half) * radius };
      return `M ${origin.x} ${origin.y} L ${start.x} ${start.y} A ${radius} ${radius} 0 0 1 ${end.x} ${end.y} Z`;
    }
    function render() {
      const selectedLayer = selectedMarkLayer;
      const numbersLayer = candidateNumbersLayer;
      const virtualCursorLayer = cursorLayer;
      if (!enabled || !host || !svg || !spotlightCutout || !spotlightMask || !dimLayer || !selectedLayer || !numbersLayer || !virtualCursorLayer) return;
      const overlayDirection = activeDirection ?? (pinned ? pinnedDirection : null);
      const showSpotlight = overlayDirection !== null;
      if (!showSpotlight && !virtualPointerVisible) {
        setOverlayVisibility(false);
        return;
      }
      setOverlayVisibility(true);
      svg.setAttribute("viewBox", `0 0 ${window.innerWidth} ${window.innerHeight}`);
      spotlightMask.setAttribute("width", String(window.innerWidth));
      spotlightMask.setAttribute("height", String(window.innerHeight));
      const maskBase = shadow.querySelector("#maskBase");
      maskBase.setAttribute("width", String(window.innerWidth));
      maskBase.setAttribute("height", String(window.innerHeight));
      dimLayer.setAttribute("width", String(window.innerWidth));
      dimLayer.setAttribute("height", String(window.innerHeight));
      if (overlayDirection) {
        spotlightCutout.setAttribute("d", createSpotlightPath(centerPoint(), overlayDirection));
        dimLayer.setAttribute("visibility", "visible");
      } else {
        spotlightCutout.setAttribute("d", "");
        dimLayer.setAttribute("visibility", "hidden");
      }
      selectedLayer.replaceChildren();
      if (!showSpotlight) {
        numbersLayer.replaceChildren();
        candidateMarksDirty = true;
      } else if (candidateMarksDirty) {
        numbersLayer.replaceChildren();
        candidates.forEach((candidate, index) => {
          const { left, top } = candidate.rect;
          const label = String(index + 1);
          const badgeWidth = Math.max(22, label.length * 9 + 10);
          if (index !== selectedIndex) {
            const background = createSvg("rect");
            background.setAttribute("x", String(left + 2));
            background.setAttribute("y", String(top + 2));
            background.setAttribute("width", String(badgeWidth));
            background.setAttribute("height", "22");
            background.setAttribute("rx", "5");
            background.setAttribute("class", "candidateNumberBackground");
            numbersLayer.append(background);
          }
          const number = createSvg("text");
          number.textContent = label;
          number.setAttribute("x", String(left + 2 + badgeWidth / 2));
          number.setAttribute("y", String(top + 13));
          number.setAttribute("class", index === selectedIndex ? "selectedCandidateNumber" : "candidateNumber");
          numbersLayer.append(number);
        });
        candidateMarksDirty = false;
      }
      const selectedCandidate = showSpotlight ? candidates[selectedIndex] : void 0;
      if (selectedCandidate) {
        const rect = selectedCandidate.rect;
        const mark = createSvg("rect");
        mark.setAttribute("x", String(rect.left));
        mark.setAttribute("y", String(rect.top));
        mark.setAttribute("width", String(Math.max(1, rect.right - rect.left)));
        mark.setAttribute("height", String(Math.max(1, rect.bottom - rect.top)));
        mark.setAttribute("rx", "5");
        mark.setAttribute("id", "selectedElement");
        selectedLayer.append(mark);
      }
      virtualCursorLayer.setAttribute("visibility", virtualPointerVisible ? "visible" : "hidden");
      virtualCursorLayer.setAttribute("transform", `translate(${virtualPointer.x} ${virtualPointer.y})`);
      if (!supported) setStatus("\uC774 \uD398\uC774\uC9C0\uB294 Gamepad API\uB97C \uC9C0\uC6D0\uD558\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4", "unsupported");
      else if (!connectedGamepad) setStatus("\uAC8C\uC784\uD328\uB4DC \uC5F0\uACB0 \uB300\uAE30 \xB7 \uD45C\uC900 \uB9E4\uD551 \uD544\uC694", "idle");
      else if (showSpotlight && pinned && !activeDirection) setStatus(`\uACE0\uC815 \xB7 \uD0D0\uC0C9 \uD6C4\uBCF4 ${candidates.length}\uAC1C`, "active");
      else if (showSpotlight && pinned) setStatus(`\uACE0\uC815 \xB7 \uD0D0\uC0C9 \uC911 \xB7 \uD0D0\uC0C9 \uD6C4\uBCF4 ${candidates.length}\uAC1C`, "active");
      else if (showSpotlight) setStatus(`\uD0D0\uC0C9 \uC911 \xB7 \uD0D0\uC0C9 \uD6C4\uBCF4 ${candidates.length}\uAC1C`, "active");
      else if (yModeActive) setStatus("\uC2A4\uD06C\uB864 \uBAA8\uB4DC", "active");
      else if (virtualPointerVisible) setStatus("\uAC00\uC0C1 \uCEE4\uC11C", "active");
      else setStatus("Joy of Nav \xB7 \uC5F0\uACB0 \uB300\uAE30", "idle");
    }
    function sameCandidates(left, right) {
      return left.length === right.length && left.every((candidate, index) => candidate.id === right[index]?.id);
    }
    function refreshCandidates(direction) {
      const nextCandidates = collectCandidates(direction);
      candidateMarksDirty = true;
      if (!sameCandidates(candidates, nextCandidates)) {
        const previouslySelected = candidates[selectedIndex]?.id;
        candidates = nextCandidates;
        selectedIndex = resolveSelectionIndex(
          previouslySelected,
          candidates.map((candidate) => candidate.id),
          settings.candidateStart === "preserve"
        );
      } else {
        candidates = nextCandidates;
      }
      refreshNeeded = false;
      lastRefreshAt = performance.now();
      lastDirectionAngle = Math.atan2(direction.y, direction.x);
    }
    function resetInputEdges() {
      xWasDown = false;
      rightTriggerWasDown = false;
      leftTriggerWasDown = false;
      leftStickClickWasDown = false;
      rightStickClickWasDown = false;
      leftBumperWasDown = false;
      rightBumperWasDown = false;
      aWasDown = false;
      bWasDown = false;
      yModeActive = false;
      lastLeftStickScrollAngle = null;
      lastRightStickCycleAngle = null;
      rightStickCycleRemainder = 0;
      releaseArrowKeys();
      ignoreCurrentButtons = true;
      connectedGamepad = false;
      virtualPointerVisible = false;
      virtualPointerVisibleUntil = 0;
      lastFrameAt = 0;
    }
    function gamepadFrame(timestamp) {
      frameId = null;
      if (!enabled || !activeTabOwned || document.visibilityState !== "visible" || document.hasFocus?.() === false) return;
      const elapsedSeconds = lastFrameAt ? Math.min((timestamp - lastFrameAt) / 1e3, 0.05) : 0;
      lastFrameAt = timestamp;
      if (virtualPointerVisible && timestamp >= virtualPointerVisibleUntil) virtualPointerVisible = false;
      let gamepads = [];
      try {
        gamepads = [...navigator.getGamepads()];
      } catch {
        gamepads = [];
      }
      const gamepad = gamepads.find((item) => item?.connected && item.mapping === "standard" && item.axes.length >= 4 && item.buttons.length >= 16) ?? null;
      connectedGamepad = Boolean(gamepad);
      if (!gamepad) {
        if (activeDirection && !pinned && settings.neutralBehavior === "clear") {
          candidates = [];
          selectedIndex = -1;
        }
        activeDirection = null;
        smoothedLeftStick = { x: 0, y: 0 };
        lastDirectionAngle = null;
        overlayDismissedUntilNeutral = false;
        yModeActive = false;
        resetInputEdges();
        render();
        frameId = requestAnimationFrame(gamepadFrame);
        return;
      }
      if (!pointerInitialized) {
        virtualPointer = centerPoint();
        pointerInitialized = true;
      }
      const yDown = gamepad.buttons[3].pressed;
      if (yDown && !yModeActive) {
        cancelCone();
        lastActiveDirection = null;
      }
      const smoothing = elapsedSeconds > 0 ? elapsedSeconds / (SPOTLIGHT_SMOOTHING_SECONDS + elapsedSeconds) : 1;
      smoothedLeftStick = {
        x: smoothedLeftStick.x + (gamepad.axes[0] - smoothedLeftStick.x) * smoothing,
        y: smoothedLeftStick.y + (gamepad.axes[1] - smoothedLeftStick.y) * smoothing
      };
      const direction = readDirection(smoothedLeftStick.x, smoothedLeftStick.y, settings.deadzone);
      const hadActiveDirection = activeDirection !== null;
      if (yDown) {
        if (activeDirection && (refreshNeeded || performance.now() - lastRefreshAt >= 180)) refreshCandidates(activeDirection);
      } else {
        if (!direction) {
          overlayDismissedUntilNeutral = false;
          activeDirection = null;
          if (!pinned) lastDirectionAngle = null;
        } else if (!overlayDismissedUntilNeutral) {
          const angle = Math.atan2(direction.y, direction.x);
          const angleChanged = lastDirectionAngle === null || Math.abs(Math.atan2(Math.sin(angle - lastDirectionAngle), Math.cos(angle - lastDirectionAngle))) > Math.PI / 90;
          if (refreshNeeded || angleChanged || performance.now() - lastRefreshAt >= 180) refreshCandidates(direction);
          activeDirection = direction;
          lastActiveDirection = direction;
          if (pinned) pinnedDirection = direction;
        } else {
          activeDirection = null;
        }
      }
      const xDown = gamepad.buttons[2].pressed;
      const leftBumperDown = gamepad.buttons[4].pressed;
      const rightBumperDown = gamepad.buttons[5].pressed;
      const leftTriggerDown = readTrigger(gamepad, 6);
      const rightTriggerDown = readTrigger(gamepad, 7);
      const aDown = gamepad.buttons[0].pressed;
      const bDown = gamepad.buttons[1].pressed;
      const leftStickClickDown = gamepad.buttons[10].pressed;
      const rightStickClickDown = gamepad.buttons[11].pressed;
      if (ignoreCurrentButtons) {
        xWasDown = xDown;
        rightTriggerWasDown = rightTriggerDown;
        leftTriggerWasDown = leftTriggerDown;
        leftStickClickWasDown = leftStickClickDown;
        rightStickClickWasDown = rightStickClickDown;
        leftBumperWasDown = leftBumperDown;
        rightBumperWasDown = rightBumperDown;
        aWasDown = aDown;
        bWasDown = bDown;
        yModeActive = yDown;
        if (activeDirection !== null || pinned && pinnedDirection !== null) {
          cycleCandidatesWithRightStick(gamepad.axes[2], gamepad.axes[3]);
        } else {
          resetRightStickCandidateCycle();
          moveVirtualPointer(gamepad.axes[2], gamepad.axes[3], elapsedSeconds);
        }
        ignoreCurrentButtons = false;
      } else {
        if (yDown !== yModeActive) {
          yModeActive = yDown;
          releaseArrowKeys();
        }
        if (hasRisen(leftStickClickDown, leftStickClickWasDown)) {
          if (pinned) {
            pinned = false;
            pinnedDirection = null;
          } else {
            const directionToPin = activeDirection ?? lastActiveDirection;
            if (directionToPin) {
              pinned = true;
              pinnedDirection = directionToPin;
              refreshNeeded = true;
            }
          }
        }
        const spotlightActive = activeDirection !== null || pinned && pinnedDirection !== null;
        if (spotlightActive) {
          cycleCandidatesWithRightStick(gamepad.axes[2], gamepad.axes[3]);
        } else {
          resetRightStickCandidateCycle();
          moveVirtualPointer(gamepad.axes[2], gamepad.axes[3], elapsedSeconds);
        }
        const l1Rose = hasRisen(leftBumperDown, leftBumperWasDown);
        const l2Rose = hasRisen(leftTriggerDown, leftTriggerWasDown);
        const xRose = hasRisen(xDown, xWasDown);
        if (spotlightActive) {
          if (l1Rose) cycleSelectedCandidate("previous");
          else if (l2Rose || xRose) cycleSelectedCandidate("next");
        } else if (xRose && !yDown) {
          pressKeyboardKey(" ");
        }
        if (yDown) {
          releaseArrowKeys();
          if (!spotlightActive && l1Rose) void sendBrowserCommand("previous-tab");
          if (!spotlightActive && l2Rose) void sendBrowserCommand("next-tab");
          scrollWithDpad(gamepad, elapsedSeconds);
          scrollWithLeftStick(direction, elapsedSeconds);
        } else {
          lastLeftStickScrollAngle = null;
          updateArrowKeys(gamepad, timestamp);
          if (!spotlightActive && l1Rose) void sendBrowserCommand("back");
          if (!spotlightActive && l2Rose) void sendBrowserCommand("forward");
        }
        if (hasRisen(rightBumperDown, rightBumperWasDown)) clickAtVirtualPointer("right");
        if (hasRisen(rightTriggerDown, rightTriggerWasDown)) clickAtVirtualPointer("left");
        if (hasRisen(rightStickClickDown, rightStickClickWasDown)) clickAtVirtualPointer("middle");
        const bRose = hasRisen(bDown, bWasDown);
        const aRose = hasRisen(aDown, aWasDown);
        if (bRose && spotlightActive) {
          cancelCone();
        } else if (bRose) {
          pressKeyboardKey("Escape");
        } else if (aRose && spotlightActive) {
          const selected = candidates[selectedIndex]?.id;
          if (selected && candidateIsVisible(selected)) {
            focusSelected();
            pressEnter(selected);
            if (pinned) {
              pinned = false;
              pinnedDirection = null;
            }
          }
        } else if (aRose) {
          pressEnter();
        }
        xWasDown = xDown;
        rightTriggerWasDown = rightTriggerDown;
        leftTriggerWasDown = leftTriggerDown;
        leftStickClickWasDown = leftStickClickDown;
        rightStickClickWasDown = rightStickClickDown;
        leftBumperWasDown = leftBumperDown;
        rightBumperWasDown = rightBumperDown;
        aWasDown = aDown;
        bWasDown = bDown;
      }
      if (!activeDirection && pinned && pinnedDirection && (refreshNeeded || performance.now() - lastRefreshAt >= 180)) {
        refreshCandidates(pinnedDirection);
      }
      if (!activeDirection && !pinned && hadActiveDirection && settings.neutralBehavior === "clear") {
        candidates = [];
        selectedIndex = -1;
      }
      render();
      frameId = requestAnimationFrame(gamepadFrame);
    }
    function readTrigger(gamepad, index) {
      const trigger = gamepad.buttons[index];
      if (!trigger) return false;
      const value = Number.isFinite(trigger.value) ? trigger.value : Number(trigger.pressed);
      return value >= settings.triggerThreshold;
    }
    function moveVirtualPointer(axisX, axisY, elapsedSeconds) {
      const direction = readDirection(axisX, axisY, settings.deadzone);
      if (!direction || elapsedSeconds <= 0) return;
      const effectiveMagnitude = Math.min(1, (direction.magnitude - settings.deadzone) / (1 - settings.deadzone));
      const speed = POINTER_SPEED * mapSpeedCurve(effectiveMagnitude, settings.pointerSpeedCurve);
      const distance = speed * elapsedSeconds;
      const nextX = Math.min(Math.max(0, window.innerWidth - 1), Math.max(0, virtualPointer.x + direction.x / direction.magnitude * distance));
      const nextY = Math.min(Math.max(0, window.innerHeight - 1), Math.max(0, virtualPointer.y + direction.y / direction.magnitude * distance));
      if (nextX === virtualPointer.x && nextY === virtualPointer.y) return;
      virtualPointer = { x: nextX, y: nextY };
      showVirtualPointer();
      dispatchMouseMove(nextX, nextY);
    }
    function moveVirtualPointerTo(element) {
      const rect = element.getBoundingClientRect();
      virtualPointer = {
        x: Math.min(Math.max(0, rect.left + rect.width / 2), Math.max(0, window.innerWidth - 1)),
        y: Math.min(Math.max(0, rect.top + rect.height / 2), Math.max(0, window.innerHeight - 1))
      };
      virtualPointerVisible = false;
      virtualPointerVisibleUntil = 0;
    }
    function showVirtualPointer() {
      virtualPointerVisible = true;
      virtualPointerVisibleUntil = performance.now() + POINTER_DISPLAY_DURATION;
    }
    function dispatchMouseMove(x, y) {
      const target = document.elementFromPoint(x, y) ?? document.documentElement;
      target.dispatchEvent(new PointerEvent("pointermove", { bubbles: true, composed: true, pointerType: "mouse", clientX: x, clientY: y, isPrimary: true }));
      target.dispatchEvent(new MouseEvent("mousemove", { bubbles: true, composed: true, view: window, clientX: x, clientY: y }));
    }
    function keyboardTarget() {
      return document.activeElement instanceof HTMLElement ? document.activeElement : document.body ?? document.documentElement;
    }
    function dispatchKeyboard(target, type, key, repeat = false) {
      const code = key === " " ? "Space" : key;
      const event = new KeyboardEvent(type, { key, code, bubbles: true, cancelable: true, composed: true, repeat });
      target.dispatchEvent(event);
      return event;
    }
    function pressKeyboardKey(key) {
      const target = keyboardTarget();
      const down = dispatchKeyboard(target, "keydown", key);
      const up = dispatchKeyboard(target, "keyup", key);
      if (key === "Escape" && !down.defaultPrevented && !up.defaultPrevented) {
        const dialog = target.closest("dialog[open]");
        if (dialog?.open) dialog.close();
      }
    }
    function pressEnter(target = keyboardTarget()) {
      const keyDown = dispatchKeyboard(target, "keydown", "Enter");
      const keyUp = dispatchKeyboard(target, "keyup", "Enter");
      if (keyDown.defaultPrevented || keyUp.defaultPrevented) return;
      if (target instanceof HTMLInputElement && target.form && ["email", "number", "password", "search", "tel", "text", "url"].includes(target.type)) {
        target.form.requestSubmit();
        return;
      }
      target.closest(CLICKABLE_SELECTOR)?.click();
    }
    function updateArrowKeys(gamepad, timestamp) {
      for (const item of ARROW_BUTTONS) {
        const isDown = Boolean(gamepad.buttons[item.button]?.pressed);
        const repeatAt = arrowKeyRepeatAt.get(item.key);
        if (isDown && repeatAt === void 0) {
          const target = keyboardTarget();
          const event = dispatchKeyboard(target, "keydown", item.key);
          if (!event.defaultPrevented) applyArrowDefault(target, item.key);
          arrowKeyRepeatAt.set(item.key, timestamp + ARROW_REPEAT_DELAY);
        } else if (isDown && repeatAt !== void 0 && timestamp >= repeatAt) {
          const target = keyboardTarget();
          const event = dispatchKeyboard(target, "keydown", item.key, true);
          if (!event.defaultPrevented) applyArrowDefault(target, item.key);
          arrowKeyRepeatAt.set(item.key, timestamp + ARROW_REPEAT_INTERVAL);
        } else if (!isDown && repeatAt !== void 0) {
          dispatchKeyboard(keyboardTarget(), "keyup", item.key);
          arrowKeyRepeatAt.delete(item.key);
        }
      }
    }
    function applyArrowDefault(target, key) {
      if (target instanceof HTMLInputElement && ["number", "range"].includes(target.type)) {
        const step = target.step === "any" ? 1 : Number(target.step || 1);
        const direction = key === "ArrowUp" || key === "ArrowRight" ? 1 : -1;
        const min = target.min === "" ? -Infinity : Number(target.min);
        const max = target.max === "" ? Infinity : Number(target.max);
        const current = Number(target.value);
        if (!Number.isFinite(current) || !Number.isFinite(step)) return;
        target.value = String(Math.min(max, Math.max(min, current + direction * step)));
        target.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
        target.dispatchEvent(new Event("change", { bubbles: true }));
        return;
      }
      if (target instanceof HTMLInputElement && ["email", "password", "search", "tel", "text", "url"].includes(target.type)) {
        if (key === "ArrowLeft" || key === "ArrowRight") {
          const start = target.selectionStart;
          const end = target.selectionEnd;
          if (start === null || end === null) return;
          const position = start !== end ? key === "ArrowLeft" ? start : end : start + (key === "ArrowRight" ? 1 : -1);
          target.setSelectionRange(Math.min(target.value.length, Math.max(0, position)), Math.min(target.value.length, Math.max(0, position)));
          target.dispatchEvent(new Event("select", { bubbles: true }));
        }
        return;
      }
      if (target instanceof HTMLTextAreaElement) {
        const start = target.selectionStart;
        const end = target.selectionEnd;
        if (start !== end && (key === "ArrowLeft" || key === "ArrowRight")) {
          const position = key === "ArrowLeft" ? start : end;
          target.setSelectionRange(position, position);
          target.dispatchEvent(new Event("select", { bubbles: true }));
          return;
        }
        const value = target.value;
        const lineStart = value.lastIndexOf("\n", Math.max(0, start - 1)) + 1;
        const column = start - lineStart;
        let nextPosition = start;
        if (key === "ArrowLeft") nextPosition = Math.max(0, start - 1);
        else if (key === "ArrowRight") nextPosition = Math.min(value.length, start + 1);
        else if (key === "ArrowUp" && lineStart > 0) {
          const previousLineEnd = lineStart - 1;
          const previousLineStart = value.lastIndexOf("\n", Math.max(0, previousLineEnd - 1)) + 1;
          nextPosition = Math.min(previousLineStart + column, previousLineEnd);
        } else if (key === "ArrowDown") {
          const nextLineStart = value.indexOf("\n", start);
          if (nextLineStart >= 0) {
            const nextLineEndIndex = value.indexOf("\n", nextLineStart + 1);
            const nextLineEnd = nextLineEndIndex < 0 ? value.length : nextLineEndIndex;
            nextPosition = Math.min(nextLineStart + 1 + column, nextLineEnd);
          }
        }
        target.setSelectionRange(nextPosition, nextPosition);
        target.dispatchEvent(new Event("select", { bubbles: true }));
        return;
      }
      if (target.isContentEditable) return;
      if (target instanceof HTMLSelectElement) {
        const direction = key === "ArrowUp" || key === "ArrowLeft" ? -1 : 1;
        target.selectedIndex = Math.min(target.options.length - 1, Math.max(0, target.selectedIndex + direction));
        target.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
        target.dispatchEvent(new Event("change", { bubbles: true }));
        return;
      }
      window.scrollBy({
        left: key === "ArrowLeft" ? -40 : key === "ArrowRight" ? 40 : 0,
        top: key === "ArrowUp" ? -40 : key === "ArrowDown" ? 40 : 0,
        behavior: "auto"
      });
    }
    function releaseArrowKeys() {
      for (const key of arrowKeyRepeatAt.keys()) dispatchKeyboard(keyboardTarget(), "keyup", key);
      arrowKeyRepeatAt.clear();
    }
    function scrollWithDpad(gamepad, elapsedSeconds) {
      const vertical = Number(Boolean(gamepad.buttons[13]?.pressed)) - Number(Boolean(gamepad.buttons[12]?.pressed));
      const horizontal = Number(Boolean(gamepad.buttons[15]?.pressed)) - Number(Boolean(gamepad.buttons[14]?.pressed));
      if (!vertical && !horizontal || elapsedSeconds <= 0) return;
      const deltaX = horizontal * WHEEL_SPEED * elapsedSeconds;
      const deltaY = vertical * WHEEL_SPEED * elapsedSeconds;
      scrollAtVirtualPointer(deltaX, deltaY);
    }
    function scrollWithLeftStick(direction, elapsedSeconds) {
      if (!direction) {
        lastLeftStickScrollAngle = null;
        return;
      }
      const angle = Math.atan2(direction.y, direction.x);
      const previousAngle = lastLeftStickScrollAngle;
      lastLeftStickScrollAngle = angle;
      if (previousAngle === null || elapsedSeconds <= 0) return;
      const angleDelta = clockwiseAngleDelta(previousAngle, angle);
      const magnitude = Math.min(1, (direction.magnitude - settings.deadzone) / (1 - settings.deadzone));
      const speedFactor = mapSpeedCurve(magnitude, settings.scrollSpeedCurve);
      const deltaY = angleDelta * WHEEL_SPEED / (2 * Math.PI) * speedFactor;
      if (deltaY) scrollAtVirtualPointer(0, deltaY);
    }
    function cycleCandidatesWithRightStick(axisX, axisY) {
      const direction = readDirection(axisX, axisY, settings.deadzone);
      if (!direction) {
        lastRightStickCycleAngle = null;
        rightStickCycleRemainder = 0;
        return;
      }
      const angle = Math.atan2(direction.y, direction.x);
      const previousAngle = lastRightStickCycleAngle;
      lastRightStickCycleAngle = angle;
      if (previousAngle === null) return;
      if (candidates.length < 2) {
        rightStickCycleRemainder = 0;
        return;
      }
      const angleDelta = clockwiseAngleDelta(previousAngle, angle);
      const magnitude = Math.min(1, (direction.magnitude - settings.deadzone) / (1 - settings.deadzone));
      rightStickCycleRemainder += angleDelta * magnitude;
      const stepAngle = 2 * Math.PI / RIGHT_STICK_CANDIDATE_STEPS_PER_TURN;
      const steps = Math.trunc(rightStickCycleRemainder / stepAngle);
      if (!steps) return;
      rightStickCycleRemainder -= steps * stepAngle;
      const cycleDirection = steps > 0 ? "next" : "previous";
      for (let index = 0; index < Math.abs(steps); index += 1) cycleSelectedCandidate(cycleDirection);
    }
    function resetRightStickCandidateCycle() {
      lastRightStickCycleAngle = null;
      rightStickCycleRemainder = 0;
    }
    function clockwiseAngleDelta(previousAngle, angle) {
      let delta = angle - previousAngle;
      if (delta > Math.PI) delta -= 2 * Math.PI;
      else if (delta < -Math.PI) delta += 2 * Math.PI;
      return delta;
    }
    function scrollAtVirtualPointer(deltaX, deltaY) {
      if (!deltaX && !deltaY) return;
      showVirtualPointer();
      const target = document.elementFromPoint(virtualPointer.x, virtualPointer.y) ?? document.documentElement;
      const allowed = target.dispatchEvent(new WheelEvent("wheel", { bubbles: true, cancelable: true, composed: true, view: window, clientX: virtualPointer.x, clientY: virtualPointer.y, deltaX, deltaY, deltaMode: WheelEvent.DOM_DELTA_PIXEL }));
      if (allowed) scrollAtTarget(target, deltaX, deltaY);
    }
    function scrollAtTarget(target, deltaX, deltaY) {
      const horizontalTarget = scrollableAncestor(target, "x", deltaX);
      const verticalTarget = scrollableAncestor(target, "y", deltaY);
      if (horizontalTarget) horizontalTarget.scrollBy({ left: deltaX, behavior: "auto" });
      else if (deltaX) window.scrollBy({ left: deltaX, behavior: "auto" });
      if (verticalTarget) verticalTarget.scrollBy({ top: deltaY, behavior: "auto" });
      else if (deltaY) window.scrollBy({ top: deltaY, behavior: "auto" });
    }
    function scrollableAncestor(target, axis, delta) {
      let ancestor = target instanceof HTMLElement ? target : target.parentElement;
      while (ancestor && ancestor !== document.documentElement) {
        if (canScroll(ancestor, axis, delta)) return ancestor;
        ancestor = ancestor.parentElement;
      }
      return null;
    }
    function canScroll(element, axis, delta) {
      if (!delta) return false;
      const style = getComputedStyle(element);
      const overflow = axis === "x" ? style.overflowX : style.overflowY;
      if (!/(auto|scroll|overlay)/.test(overflow)) return false;
      const current = axis === "x" ? element.scrollLeft : element.scrollTop;
      const extent = axis === "x" ? element.scrollWidth - element.clientWidth : element.scrollHeight - element.clientHeight;
      return extent > 0 && (delta > 0 ? current < extent : current > 0);
    }
    function clickAtVirtualPointer(button) {
      const target = document.elementFromPoint(virtualPointer.x, virtualPointer.y);
      if (!target || host?.contains(target)) return;
      showVirtualPointer();
      const mouseButton = button === "left" ? 0 : button === "middle" ? 1 : 2;
      const buttons = button === "left" ? 1 : button === "middle" ? 4 : 2;
      const base = { bubbles: true, cancelable: true, composed: true, view: window, clientX: virtualPointer.x, clientY: virtualPointer.y, button: mouseButton };
      target.dispatchEvent(new PointerEvent("pointerdown", { ...base, pointerId: 1, pointerType: "mouse", isPrimary: true, buttons }));
      target.dispatchEvent(new MouseEvent("mousedown", { ...base, buttons }));
      if (button === "right") {
        target.dispatchEvent(new MouseEvent("contextmenu", { ...base, buttons }));
      }
      target.dispatchEvent(new PointerEvent("pointerup", { ...base, pointerId: 1, pointerType: "mouse", isPrimary: true, buttons: 0 }));
      target.dispatchEvent(new MouseEvent("mouseup", { ...base, buttons: 0 }));
      if (button === "left") {
        const clickable = target.closest(CLICKABLE_SELECTOR) ?? (target instanceof HTMLElement ? target : null);
        clickable?.click();
        return;
      }
      const auxiliaryClick = new MouseEvent("auxclick", { ...base, buttons: 0 });
      if (button === "middle") target.dispatchEvent(auxiliaryClick);
      if (button === "middle" && !auxiliaryClick.defaultPrevented) {
        const anchor = target.closest("a[href]");
        if (anchor && /^https?:$/i.test(new URL(anchor.href, document.baseURI).protocol)) {
          void chrome.runtime.sendMessage({ type: "joy-nav:open-background-tab", url: anchor.href }).catch(() => void 0);
        }
      }
    }
    function cancelCone() {
      overlayDismissedUntilNeutral = true;
      activeDirection = null;
      pinned = false;
      pinnedDirection = null;
      candidates = [];
      selectedIndex = -1;
      lastDirectionAngle = null;
      refreshNeeded = true;
    }
    function cycleSelectedCandidate(direction) {
      if (!candidates.length) return;
      if (direction === "next") {
        selectedIndex = nextCycleIndex(selectedIndex, candidates.length);
      } else {
        selectedIndex = selectedIndex < 0 || selectedIndex >= candidates.length ? candidates.length - 1 : (selectedIndex - 1 + candidates.length) % candidates.length;
      }
      candidateMarksDirty = true;
      focusSelected();
      render();
    }
    function sendBrowserCommand(command) {
      return chrome.runtime.sendMessage({ type: "joy-nav:browser-command", command }).then(() => void 0).catch(() => void 0);
    }
    function focusSelected() {
      const element = candidates[selectedIndex]?.id;
      if (!element || !candidateIsVisible(element)) {
        refreshNeeded = true;
        return false;
      }
      moveVirtualPointerTo(element);
      const focusWithoutScroll = () => {
        try {
          element.focus({ preventScroll: true });
        } catch {
          element.focus();
        }
      };
      focusWithoutScroll();
      if (document.activeElement === element) return true;
      if (element.hasAttribute("tabindex")) return false;
      element.setAttribute("tabindex", "-1");
      temporaryTabIndexTargets.add(element);
      element.addEventListener("blur", () => {
        if (!temporaryTabIndexTargets.delete(element)) return;
        if (element.getAttribute("tabindex") === "-1") element.removeAttribute("tabindex");
      }, { once: true });
      focusWithoutScroll();
      if (document.activeElement === element) return true;
      if (temporaryTabIndexTargets.delete(element)) element.removeAttribute("tabindex");
      refreshNeeded = true;
      return false;
    }
    function startLoop() {
      if (!enabled || !activeTabOwned || frameId !== null) return;
      supported = typeof navigator.getGamepads === "function";
      ensureOverlay();
      if (!supported) {
        render();
        return;
      }
      render();
      frameId = requestAnimationFrame(gamepadFrame);
    }
    function stopLoop() {
      if (frameId !== null) cancelAnimationFrame(frameId);
      frameId = null;
      activeDirection = null;
      smoothedLeftStick = { x: 0, y: 0 };
      if (settings.neutralBehavior === "clear" && !pinned) {
        candidates = [];
        selectedIndex = -1;
      }
      refreshNeeded = true;
      resetInputEdges();
      setOverlayVisibility(false);
    }
    function status() {
      return { enabled, supported, gamepadConnected: connectedGamepad };
    }
    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
      if (message?.type === "joy-nav:tab-ownership" && typeof message.active === "boolean") {
        const pageIsFocused = document.visibilityState === "visible" && document.hasFocus?.() !== false;
        activeTabOwned = message.active && pageIsFocused;
        if (activeTabOwned) {
          resetInputEdges();
          startLoop();
        } else {
          stopLoop();
        }
        sendResponse({ active: activeTabOwned });
        return false;
      }
      if (message?.type === "joy-nav:get-status") {
        sendResponse(status());
        return false;
      }
      if (message?.type === "joy-nav:set-enabled" && typeof message.enabled === "boolean") {
        enabled = message.enabled;
        if (enabled) startLoop();
        else {
          pinned = false;
          pinnedDirection = null;
          lastActiveDirection = null;
          stopLoop();
        }
        sendResponse(status());
        return false;
      }
      return false;
    });
    chrome.storage.local.get("settings").then(({ settings: savedSettings }) => {
      settings = normalizeSettings(savedSettings);
      refreshNeeded = true;
      if (enabled) onVisibilityChange();
    }).catch(() => {
      settings = { ...DEFAULT_SETTINGS };
      if (enabled) onVisibilityChange();
    });
    chrome.storage.onChanged.addListener((changes, areaName) => {
      if (areaName !== "local" || !changes.settings?.newValue) return;
      const previous = settings;
      settings = normalizeSettings(changes.settings.newValue);
      if (previous.neutralBehavior !== settings.neutralBehavior && !activeDirection && !pinned && settings.neutralBehavior === "clear") {
        candidates = [];
        selectedIndex = -1;
      }
      refreshNeeded = true;
      render();
    });
    function onVisibilityChange() {
      const sequence = ++focusChangeSequence;
      const pageIsFocused = document.visibilityState === "visible" && document.hasFocus?.() !== false;
      if (!pageIsFocused) {
        relinquishTabOwnership();
        return;
      }
      void chrome.runtime.sendMessage({ type: "joy-nav:sync-active-tab" }).then((response) => {
        if (sequence !== focusChangeSequence) return;
        activeTabOwned = response?.active === true;
        if (activeTabOwned && document.visibilityState === "visible" && document.hasFocus?.() !== false) {
          resetInputEdges();
          startLoop();
        } else {
          activeTabOwned = false;
          stopLoop();
        }
      }).catch(() => {
        if (sequence !== focusChangeSequence) return;
        activeTabOwned = false;
        stopLoop();
      });
    }
    function relinquishTabOwnership() {
      ++focusChangeSequence;
      activeTabOwned = false;
      stopLoop();
      void chrome.runtime.sendMessage({ type: "joy-nav:sync-active-tab" }).catch(() => void 0);
    }
    document.addEventListener("visibilitychange", onVisibilityChange);
    window.addEventListener("focus", onVisibilityChange);
    window.addEventListener("blur", relinquishTabOwnership);
    window.addEventListener("resize", () => {
      if (pointerInitialized) {
        virtualPointer.x = Math.min(Math.max(0, window.innerWidth - 1), Math.max(0, virtualPointer.x));
        virtualPointer.y = Math.min(Math.max(0, window.innerHeight - 1), Math.max(0, virtualPointer.y));
      }
      refreshNeeded = true;
      render();
    }, { passive: true });
    window.addEventListener("scroll", () => {
      refreshNeeded = true;
    }, { capture: true, passive: true });
    window.addEventListener("gamepadconnected", () => {
      refreshNeeded = true;
      startLoop();
    });
    window.addEventListener("gamepaddisconnected", () => {
      connectedGamepad = false;
      resetInputEdges();
      refreshNeeded = true;
    });
    observer = new MutationObserver((records) => {
      if (records.some((record) => !host?.contains(record.target))) refreshNeeded = true;
    });
    observer.observe(document.documentElement, {
      subtree: true,
      childList: true,
      attributes: true,
      attributeFilter: ["class", "style", "hidden", "disabled", "aria-disabled", "aria-hidden", "href", "tabindex"]
    });
  }
  installContentScript();
})();
