"use strict";
(() => {
  // src/core/settings.ts
  var DEFAULT_SCROLL_SPEED_CURVE = [0, 0.58, 0.82, 0.95, 1];
  var DEFAULT_POINTER_SPEED_CURVE = [0, 0.5, 0.76, 0.92, 1];
  var DEFAULT_SETTINGS = Object.freeze({
    deadzone: 0.2,
    spotlightShape: "cone",
    spotlightSize: 30,
    triggerThreshold: 0.5,
    neutralBehavior: "retain",
    candidateStart: "first",
    inclusionMode: "center",
    distanceMode: "center",
    tieBreak: "dom",
    scrollSpeedCurve: DEFAULT_SCROLL_SPEED_CURVE,
    pointerSpeedCurve: DEFAULT_POINTER_SPEED_CURVE
  });

  // src/extension/background.ts
  var activeTabId;
  var ownershipRevision = 0;
  function sendTabOwnership(tabId, active) {
    const message = {
      type: "joy-nav:tab-ownership",
      active
    };
    void chrome.tabs.sendMessage(tabId, message).catch(async () => {
      if (!active) return;
      try {
        const tab = await chrome.tabs.get(tabId);
        if (!tab.active || tab.status !== "complete" || tab.windowId === void 0) return;
        const window = await chrome.windows.get(tab.windowId);
        if (!window.focused) return;
        await chrome.scripting.executeScript({ target: { tabId }, files: ["extension/content.js"] });
        await chrome.tabs.sendMessage(tabId, message);
      } catch {
      }
    });
  }
  function updateActiveTab(tabId) {
    if (activeTabId === tabId) {
      if (tabId !== void 0) sendTabOwnership(tabId, true);
      return;
    }
    const previousTabId = activeTabId;
    activeTabId = tabId;
    if (previousTabId !== void 0) sendTabOwnership(previousTabId, false);
    if (tabId !== void 0) sendTabOwnership(tabId, true);
  }
  async function syncFocusedTab() {
    const revision = ++ownershipRevision;
    try {
      const focusedWindow = await chrome.windows.getLastFocused();
      if (revision !== ownershipRevision) return;
      if (!focusedWindow.focused || focusedWindow.id === void 0) {
        updateActiveTab(void 0);
        return;
      }
      const [tab] = await chrome.tabs.query({ active: true, windowId: focusedWindow.id });
      if (revision === ownershipRevision) updateActiveTab(tab?.id);
    } catch {
      if (revision === ownershipRevision) updateActiveTab(void 0);
    }
  }
  void syncFocusedTab();
  chrome.tabs.onActivated.addListener(({ tabId, windowId }) => {
    const revision = ++ownershipRevision;
    void chrome.windows.get(windowId).then((focusedWindow) => {
      if (revision === ownershipRevision && focusedWindow.focused) updateActiveTab(tabId);
    }).catch(() => void 0);
  });
  chrome.tabs.onUpdated.addListener((_tabId, changeInfo, tab) => {
    if (changeInfo.status === "complete" && tab.active) void syncFocusedTab();
  });
  chrome.windows.onFocusChanged.addListener((windowId) => {
    const revision = ++ownershipRevision;
    if (windowId === chrome.windows.WINDOW_ID_NONE) {
      updateActiveTab(void 0);
      return;
    }
    void chrome.tabs.query({ active: true, windowId }).then(([tab]) => {
      if (revision === ownershipRevision) updateActiveTab(tab?.id);
    }).catch(() => {
      if (revision === ownershipRevision) updateActiveTab(void 0);
    });
  });
  chrome.tabs.onRemoved.addListener((tabId) => {
    if (activeTabId !== tabId) return;
    ++ownershipRevision;
    updateActiveTab(void 0);
    void syncFocusedTab();
  });
  chrome.runtime.onInstalled.addListener(() => {
    void chrome.storage.local.get("settings").then(({ settings }) => {
      if (!settings) return chrome.storage.local.set({ settings: DEFAULT_SETTINGS });
      return void 0;
    });
    void syncFocusedTab();
  });
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    const tabId = sender.tab?.id;
    if (message?.type === "joy-nav:browser-command") {
      const command = message.command;
      if (tabId === void 0) return false;
      if (command === "back" || command === "forward") {
        const navigation = command === "back" ? chrome.tabs.goBack(tabId) : chrome.tabs.goForward(tabId);
        void navigation.then(() => sendResponse({ ok: true })).catch(() => sendResponse({ ok: false }));
        return true;
      }
      if ((command === "previous-tab" || command === "next-tab") && sender.tab?.windowId !== void 0) {
        const windowId = sender.tab.windowId;
        void chrome.tabs.query({ windowId }).then((tabs) => {
          const ordered = tabs.sort((left, right) => left.index - right.index);
          const currentIndex = ordered.findIndex((tab) => tab.id === tabId);
          if (currentIndex < 0 || ordered.length < 2) {
            sendResponse({ ok: false });
            return;
          }
          const delta = command === "previous-tab" ? -1 : 1;
          const nextIndex = (currentIndex + delta + ordered.length) % ordered.length;
          return chrome.tabs.update(ordered[nextIndex].id, { active: true }).then(() => sendResponse({ ok: true }));
        }).catch(() => sendResponse({ ok: false }));
        return true;
      }
      return false;
    }
    if (message?.type === "joy-nav:open-background-tab" && typeof message.url === "string") {
      if (sender.tab?.windowId === void 0) {
        sendResponse({ ok: false });
        return false;
      }
      try {
        const url = new URL(message.url);
        if (!/^https?:$/.test(url.protocol)) {
          sendResponse({ ok: false });
          return false;
        }
        void chrome.tabs.create({ url: url.href, active: false, windowId: sender.tab.windowId }).then(() => sendResponse({ ok: true })).catch(() => sendResponse({ ok: false }));
        return true;
      } catch {
        sendResponse({ ok: false });
        return false;
      }
    }
    if (message?.type === "joy-nav:sync-active-tab") {
      if (tabId === void 0) {
        sendResponse({ active: false });
        return false;
      }
      void syncFocusedTab().then(() => sendResponse({ active: activeTabId === tabId }));
      return true;
    }
    return false;
  });
})();
