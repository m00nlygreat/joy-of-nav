"use strict";
(() => {
  // src/core/navigation.ts
  function readDirection(x, y, deadzone) {
    const magnitude = Math.hypot(x, y);
    if (!Number.isFinite(magnitude) || magnitude <= deadzone) return null;
    return { x, y, magnitude };
  }
  function corners(rect) {
    return [
      { x: rect.left, y: rect.top },
      { x: rect.right, y: rect.top },
      { x: rect.right, y: rect.bottom },
      { x: rect.left, y: rect.bottom }
    ];
  }
  function clipPolygon(polygon, signedDistance) {
    if (!polygon.length) return [];
    const clipped = [];
    let previous = polygon[polygon.length - 1];
    let previousDistance = signedDistance(previous);
    let previousInside = previousDistance >= -1e-8;
    for (const current of polygon) {
      const currentDistance = signedDistance(current);
      const currentInside = currentDistance >= -1e-8;
      if (currentInside !== previousInside) {
        const denominator = previousDistance - currentDistance;
        const amount = Math.abs(denominator) < 1e-12 ? 0 : previousDistance / denominator;
        clipped.push({
          x: previous.x + (current.x - previous.x) * amount,
          y: previous.y + (current.y - previous.y) * amount
        });
      }
      if (currentInside) clipped.push(current);
      previous = current;
      previousDistance = currentDistance;
      previousInside = currentInside;
    }
    return clipped;
  }
  var SPOTLIGHT_CAP_SEGMENTS = 24;
  function createSpotlightPolygon(origin, direction, arrivalWidth, startWidth, viewportWidth, viewportHeight) {
    const directionLength = Math.hypot(direction.x, direction.y);
    if (!directionLength || arrivalWidth <= 0 && startWidth <= 0) return [];
    const unitDirection = { x: direction.x / directionLength, y: direction.y / directionLength };
    const perpendicular = { x: -unitDirection.y, y: unitDirection.x };
    const viewportCorners = corners({ left: 0, top: 0, right: viewportWidth, bottom: viewportHeight });
    const endDistance = Math.max(...viewportCorners.map((point) => (point.x - origin.x) * unitDirection.x + (point.y - origin.y) * unitDirection.y));
    if (endDistance <= 0) return [];
    const startRadius = Math.max(0, startWidth) / 2;
    const arrivalRadius = Math.max(0, arrivalWidth) / 2;
    const end = {
      x: origin.x + unitDirection.x * endDistance,
      y: origin.y + unitDirection.y * endDistance
    };
    const pointAt = (along, across) => ({
      x: origin.x + unitDirection.x * along + perpendicular.x * across,
      y: origin.y + unitDirection.y * along + perpendicular.y * across
    });
    const polygon = [
      pointAt(0, startRadius),
      { x: end.x + perpendicular.x * arrivalRadius, y: end.y + perpendicular.y * arrivalRadius },
      { x: end.x - perpendicular.x * arrivalRadius, y: end.y - perpendicular.y * arrivalRadius }
    ];
    if (startRadius > 0) {
      polygon.push(pointAt(0, -startRadius));
      for (let index = 1; index < SPOTLIGHT_CAP_SEGMENTS; index += 1) {
        const angle = -Math.PI / 2 - Math.PI * index / SPOTLIGHT_CAP_SEGMENTS;
        polygon.push(pointAt(Math.cos(angle) * startRadius, Math.sin(angle) * startRadius));
      }
    }
    return polygon;
  }
  function pointOnSegment(point, start, end) {
    const dx = end.x - start.x;
    const dy = end.y - start.y;
    const lengthSquared = dx * dx + dy * dy;
    if (lengthSquared < 1e-14) return Math.hypot(point.x - start.x, point.y - start.y) <= 1e-7;
    const amount = Math.min(1, Math.max(0, ((point.x - start.x) * dx + (point.y - start.y) * dy) / lengthSquared));
    return Math.hypot(point.x - (start.x + amount * dx), point.y - (start.y + amount * dy)) <= 1e-7;
  }
  function polygonContainsPoint(polygon, point) {
    let inside = false;
    for (let index = 0, previousIndex = polygon.length - 1; index < polygon.length; previousIndex = index, index += 1) {
      const current = polygon[index];
      const previous = polygon[previousIndex];
      if (pointOnSegment(point, previous, current)) return true;
      if (current.y > point.y !== previous.y > point.y && point.x < (previous.x - current.x) * (point.y - current.y) / (previous.y - current.y) + current.x) {
        inside = !inside;
      }
    }
    return inside;
  }
  function polygonIntersectsRect(polygon, rect) {
    let clipped = polygon;
    clipped = clipPolygon(clipped, (point) => point.x - rect.left);
    clipped = clipPolygon(clipped, (point) => rect.right - point.x);
    clipped = clipPolygon(clipped, (point) => point.y - rect.top);
    clipped = clipPolygon(clipped, (point) => rect.bottom - point.y);
    return clipped.length > 0;
  }
  function candidateInSpotlightPolygon(candidate, polygon, mode) {
    if (mode === "intersects") return polygonIntersectsRect(polygon, candidate.rect);
    return polygonContainsPoint(polygon, {
      x: (candidate.rect.left + candidate.rect.right) / 2,
      y: (candidate.rect.top + candidate.rect.bottom) / 2
    });
  }
  function candidateDistance(candidate, origin, mode) {
    const point = mode === "center" ? { x: (candidate.rect.left + candidate.rect.right) / 2, y: (candidate.rect.top + candidate.rect.bottom) / 2 } : {
      x: Math.min(candidate.rect.right, Math.max(candidate.rect.left, origin.x)),
      y: Math.min(candidate.rect.bottom, Math.max(candidate.rect.top, origin.y))
    };
    return Math.hypot(point.x - origin.x, point.y - origin.y);
  }
  function rankSpotlightCandidates(candidates, origin, direction, arrivalWidth, startWidth, viewportWidth, viewportHeight, inclusionMode, distanceMode, tieBreak) {
    const polygon = createSpotlightPolygon(origin, direction, arrivalWidth, startWidth, viewportWidth, viewportHeight);
    if (polygon.length === 0) return [];
    return candidates.filter((candidate) => candidateInSpotlightPolygon(candidate, polygon, inclusionMode)).slice().sort((left, right) => {
      const distanceDelta = candidateDistance(left, origin, distanceMode) - candidateDistance(right, origin, distanceMode);
      if (Math.abs(distanceDelta) > 0.01) return distanceDelta;
      if (tieBreak === "top-left") {
        const topDelta = left.rect.top - right.rect.top;
        if (Math.abs(topDelta) > 0.01) return topDelta;
        const leftDelta = left.rect.left - right.rect.left;
        if (Math.abs(leftDelta) > 0.01) return leftDelta;
      }
      return left.documentOrder - right.documentOrder;
    });
  }
  function nextCycleIndex(currentIndex, length) {
    if (length <= 0) return -1;
    return currentIndex < 0 || currentIndex >= length ? 0 : (currentIndex + 1) % length;
  }
  function resolveSelectionIndex(previouslySelected, candidates, preserve) {
    if (preserve && previouslySelected !== void 0) {
      return candidates.indexOf(previouslySelected);
    }
    return -1;
  }
  function hasRisen(currentlyDown, wasDown) {
    return currentlyDown && !wasDown;
  }

  // src/core/settings.ts
  var DEFAULT_SCROLL_SPEED_CURVE = [0, 0.1, 0.3, 0.62, 1];
  var DEFAULT_POINTER_SPEED_CURVE = [0, 0.08, 0.28, 0.62, 1];
  var PREVIOUS_SCROLL_SPEED_CURVE = [0, 0.58, 0.82, 0.95, 1];
  var PREVIOUS_POINTER_SPEED_CURVE = [0, 0.5, 0.76, 0.92, 1];
  var DEFAULT_SETTINGS = Object.freeze({
    deadzone: 0.2,
    spotlightArrivalSize: 30,
    spotlightStartSize: 0,
    triggerThreshold: 0.5,
    neutralBehavior: "retain",
    candidateStart: "first",
    inclusionMode: "center",
    distanceMode: "center",
    tieBreak: "dom",
    candidateNumberVisibility: "show",
    controlGuideVisibility: "show",
    scrollSpeedCurve: DEFAULT_SCROLL_SPEED_CURVE,
    pointerSpeedCurve: DEFAULT_POINTER_SPEED_CURVE,
    scrollMaxSpeed: 2200,
    pointerMaxSpeed: 1800,
    rightStickCandidateStepDegrees: 70
  });
  var LIMITS = {
    deadzone: { min: 0.05, max: 0.6 },
    triggerThreshold: { min: 0.1, max: 1 },
    scrollMaxSpeed: { min: 100, max: 4e3 },
    pointerMaxSpeed: { min: 100, max: 3e3 },
    rightStickCandidateStepDegrees: { min: 15, max: 180 },
    spotlightArrivalSize: { min: 0, max: 100 },
    spotlightStartSize: { min: 0, max: 100 }
  };
  function numericValue(value, fallback, min, max) {
    const parsed = typeof value === "number" ? value : Number(value);
    if (!Number.isFinite(parsed)) return fallback;
    return Math.min(max, Math.max(min, parsed));
  }
  function speedCurveBezierSegments(curve) {
    const spacing = 1 / 4;
    const slopes = curve.slice(0, 4).map((value, index) => (curve[index + 1] - value) / spacing);
    const tangents = [slopes[0]];
    for (let index = 1; index < 4; index += 1) {
      const previous = slopes[index - 1];
      const next = slopes[index];
      tangents.push(previous <= 0 || next <= 0 ? 0 : 2 * previous * next / (previous + next));
    }
    tangents.push(slopes[3]);
    return Array.from({ length: 4 }, (_, index) => {
      const startX = index * spacing;
      const endX = startX + spacing;
      return {
        startX,
        startY: curve[index],
        control1X: startX + spacing / 3,
        control1Y: curve[index] + tangents[index] * spacing / 3,
        control2X: endX - spacing / 3,
        control2Y: curve[index + 1] - tangents[index + 1] * spacing / 3,
        endX,
        endY: curve[index + 1]
      };
    });
  }
  function normalizeSpeedCurve(value, fallback) {
    if (!Array.isArray(value) || value.length < 5) return [...fallback];
    const previousDefaults = fallback === DEFAULT_SCROLL_SPEED_CURVE ? PREVIOUS_SCROLL_SPEED_CURVE : PREVIOUS_POINTER_SPEED_CURVE;
    if (previousDefaults.every((point, index) => Number(value[index]) === point)) return [...fallback];
    const curve = [
      0,
      numericValue(value[1], fallback[1], 0, 1),
      numericValue(value[2], fallback[2], 0, 1),
      numericValue(value[3], fallback[3], 0, 1),
      1
    ];
    for (let index = 2; index <= 3; index += 1) {
      curve[index] = Math.max(curve[index - 1], curve[index]);
    }
    return curve;
  }
  function mapSpeedCurve(value, curve) {
    const input = Math.min(1, Math.max(0, Number.isFinite(value) ? value : 0));
    const segment = Math.min(3, Math.floor(input * 4));
    const amount = input * 4 - segment;
    const { startY, control1Y, control2Y, endY } = speedCurveBezierSegments(curve)[segment];
    const inverse = 1 - amount;
    return inverse ** 3 * startY + 3 * inverse ** 2 * amount * control1Y + 3 * inverse * amount ** 2 * control2Y + amount ** 3 * endY;
  }
  function normalizeSettings(value) {
    const record = value && typeof value === "object" ? value : {};
    const source = record;
    const legacySize = record.spotlightSize ?? record.coneAngle;
    const hasNewSpotlightSizes = source.spotlightArrivalSize !== void 0 || source.spotlightStartSize !== void 0;
    const migrateLegacySpotlightSize = !hasNewSpotlightSizes && legacySize !== void 0;
    const legacySizePercent = migrateLegacySpotlightSize ? numericValue(legacySize, DEFAULT_SETTINGS.spotlightArrivalSize, LIMITS.spotlightArrivalSize.min, LIMITS.spotlightArrivalSize.max) : void 0;
    const legacyWasCylinder = record.spotlightShape === "cylinder";
    return {
      deadzone: numericValue(source.deadzone, DEFAULT_SETTINGS.deadzone, LIMITS.deadzone.min, LIMITS.deadzone.max),
      spotlightArrivalSize: numericValue(source.spotlightArrivalSize, legacySizePercent ?? DEFAULT_SETTINGS.spotlightArrivalSize, LIMITS.spotlightArrivalSize.min, LIMITS.spotlightArrivalSize.max),
      spotlightStartSize: numericValue(source.spotlightStartSize, legacyWasCylinder ? legacySizePercent ?? DEFAULT_SETTINGS.spotlightStartSize : DEFAULT_SETTINGS.spotlightStartSize, LIMITS.spotlightStartSize.min, LIMITS.spotlightStartSize.max),
      triggerThreshold: numericValue(source.triggerThreshold, DEFAULT_SETTINGS.triggerThreshold, LIMITS.triggerThreshold.min, LIMITS.triggerThreshold.max),
      neutralBehavior: source.neutralBehavior === "clear" ? "clear" : "retain",
      candidateStart: source.candidateStart === "preserve" ? "preserve" : "first",
      inclusionMode: source.inclusionMode === "intersects" ? "intersects" : "center",
      distanceMode: source.distanceMode === "nearest" ? "nearest" : "center",
      tieBreak: source.tieBreak === "top-left" ? "top-left" : "dom",
      candidateNumberVisibility: source.candidateNumberVisibility === "hide" ? "hide" : "show",
      controlGuideVisibility: source.controlGuideVisibility === "hide" ? "hide" : "show",
      scrollSpeedCurve: normalizeSpeedCurve(source.scrollSpeedCurve, DEFAULT_SCROLL_SPEED_CURVE),
      pointerSpeedCurve: normalizeSpeedCurve(source.pointerSpeedCurve, DEFAULT_POINTER_SPEED_CURVE),
      scrollMaxSpeed: numericValue(source.scrollMaxSpeed, DEFAULT_SETTINGS.scrollMaxSpeed, LIMITS.scrollMaxSpeed.min, LIMITS.scrollMaxSpeed.max),
      pointerMaxSpeed: numericValue(source.pointerMaxSpeed, DEFAULT_SETTINGS.pointerMaxSpeed, LIMITS.pointerMaxSpeed.min, LIMITS.pointerMaxSpeed.max),
      rightStickCandidateStepDegrees: numericValue(source.rightStickCandidateStepDegrees, DEFAULT_SETTINGS.rightStickCandidateStepDegrees, LIMITS.rightStickCandidateStepDegrees.min, LIMITS.rightStickCandidateStepDegrees.max)
    };
  }

  // src/extension/content.ts
  function installContentScript() {
    const extensionWindow = window;
    if (extensionWindow.__joyOfNavContentInitialized) return;
    extensionWindow.__joyOfNavContentInitialized = true;
    const CLICKABLE_SELECTOR = [
      "a[href]",
      "area[href]",
      "button",
      "input:not([type='hidden'])",
      "select",
      "textarea",
      "summary",
      "[role='button']",
      "[role='link']",
      "[tabindex]:not([tabindex='-1'])",
      "[onclick]",
      "iframe"
    ].join(",");
    const SVG_NS = "http://www.w3.org/2000/svg";
    let enabled = true;
    let activeTabOwned = false;
    let settings = { ...DEFAULT_SETTINGS };
    let frameId = null;
    let host = null;
    let shadow = null;
    let svg = null;
    let spotlightCutout = null;
    let spotlightMask = null;
    let dimLayer = null;
    let selectedMarkLayer = null;
    let candidateNumbersLayer = null;
    let cursorLayer = null;
    let controlGuide = null;
    let observer = null;
    let candidates = [];
    let selectedIndex = -1;
    let candidateMarksDirty = true;
    let activeDirection = null;
    let lastActiveDirection = null;
    let pinnedDirection = null;
    let pinned = false;
    let xWasDown = false;
    let rightTriggerWasDown = false;
    let leftTriggerWasDown = false;
    let leftStickClickWasDown = false;
    let rightStickClickWasDown = false;
    let leftBumperWasDown = false;
    let rightBumperWasDown = false;
    let aWasDown = false;
    let bWasDown = false;
    let arrowKeyRepeatAt = /* @__PURE__ */ new Map();
    let ignoreCurrentButtons = true;
    let refreshNeeded = true;
    let lastRefreshAt = 0;
    let lastDirectionAngle = null;
    let smoothedLeftStick = { x: 0, y: 0 };
    let connectedGamepad = false;
    let supported = typeof navigator.getGamepads === "function";
    const isTopFrame = window === window.top;
    const frameToken = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
    let framePath = isTopFrame ? [frameToken] : [];
    let framePathRegistered = false;
    let activeFramePath = [];
    let pendingFramePath = null;
    let pendingFrameWaitForNeutral = false;
    let pendingFrameRouteAttempts = 0;
    let frameRouteRetryTimer = null;
    const frameTokenByElement = /* @__PURE__ */ new WeakMap();
    const frameElementByToken = /* @__PURE__ */ new Map();
    let frameInputSequence = 0;
    let overlayDismissedUntilNeutral = false;
    let virtualPointer = { x: 0, y: 0 };
    let virtualPointerVisible = false;
    let virtualPointerVisibleUntil = 0;
    let yModeActive = false;
    let lastLeftStickScrollAngle = null;
    let lastRightStickCycleAngle = null;
    let rightStickCycleRemainder = 0;
    let pointerInitialized = false;
    let lastFrameAt = 0;
    const temporaryTabIndexTargets = /* @__PURE__ */ new WeakSet();
    let focusChangeSequence = 0;
    const ARROW_BUTTONS = [
      { button: 12, key: "ArrowUp", code: "ArrowUp" },
      { button: 13, key: "ArrowDown", code: "ArrowDown" },
      { button: 14, key: "ArrowLeft", code: "ArrowLeft" },
      { button: 15, key: "ArrowRight", code: "ArrowRight" }
    ];
    const ARROW_REPEAT_DELAY = 420;
    const ARROW_REPEAT_INTERVAL = 75;
    const POINTER_DISPLAY_DURATION = 1e3;
    const SPOTLIGHT_SMOOTHING_SECONDS = 0.06;
    function centerPoint() {
      return { x: window.innerWidth / 2, y: window.innerHeight / 2 };
    }
    function candidateIsVisible(element) {
      if (!element.isConnected || element.matches(":disabled, [aria-disabled='true'], [hidden], [inert]") || element.closest("[inert], [aria-hidden='true']")) return false;
      const style = getComputedStyle(element);
      if (style.display === "none" || style.visibility === "hidden" || style.visibility === "collapse" || style.pointerEvents === "none") return false;
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0 && rect.right > 0 && rect.bottom > 0 && rect.left < window.innerWidth && rect.top < window.innerHeight;
    }
    function collectCandidates(direction) {
      const raw = [...document.querySelectorAll(CLICKABLE_SELECTOR)];
      const possible = [];
      raw.forEach((element, documentOrder) => {
        if (host?.contains(element) || !candidateIsVisible(element)) return;
        const rect = element.getBoundingClientRect();
        possible.push({
          id: element,
          rect: { left: rect.left, top: rect.top, right: rect.right, bottom: rect.bottom },
          documentOrder
        });
      });
      return rankSpotlightCandidates(
        possible,
        centerPoint(),
        direction,
        Math.min(window.innerWidth, window.innerHeight) * settings.spotlightArrivalSize / 100,
        Math.min(window.innerWidth, window.innerHeight) * settings.spotlightStartSize / 100,
        window.innerWidth,
        window.innerHeight,
        settings.inclusionMode,
        settings.distanceMode,
        settings.tieBreak
      );
    }
    function createSvg(tag) {
      return document.createElementNS(SVG_NS, tag);
    }
    function setOverlayVisibility(visible) {
      host?.style.setProperty("display", visible ? "block" : "none", "important");
    }
    function ensureOverlay() {
      if (host && shadow) return;
      host = document.createElement("div");
      host.setAttribute("data-joy-of-nav", "overlay");
      host.setAttribute("aria-hidden", "true");
      host.style.cssText = "all:initial!important;position:fixed!important;inset:0!important;width:100vw!important;height:100vh!important;z-index:2147483647!important;pointer-events:none!important;display:block!important;";
      shadow = host.attachShadow({ mode: "closed" });
      shadow.innerHTML = `
      <style>
        :host { all: initial; }
        #overlaySvg { position: fixed; inset: 0; width: 100vw; height: 100vh; overflow: hidden; pointer-events: none; }
        #dim { fill: rgba(5, 10, 9, .68); }
        #selectedElement { fill: none; stroke: #c7ec73; stroke-width: 2; vector-effect: non-scaling-stroke; }
        #selectedElement[data-kind="iframe"] { stroke: #73dfff; }
        .candidateNumberBackground { fill: rgba(22, 38, 31, .82); stroke: none; }
        .candidateNumber { fill: #d6ff83; font: 700 10px/1 system-ui, sans-serif; text-anchor: middle; dominant-baseline: central; }
        .selectedCandidateNumber { fill: #d6ff83; stroke: rgba(5, 10, 9, .88); stroke-width: 1.5; stroke-linejoin: round; paint-order: stroke fill; font: 800 10px/1 system-ui, sans-serif; text-anchor: middle; dominant-baseline: central; }
        #virtualCursorOuter { fill: rgba(5, 10, 9, .7); stroke: #f6ffe8; stroke-width: 2; }
        #virtualCursorInner { fill: #d6ff83; stroke: #1c2814; stroke-width: 1; }
        #controlGuide { all: initial; position: fixed; inset: auto 0 0; z-index: 1; isolation: isolate; display: flex; justify-content: center; box-sizing: border-box; width: 100%; padding: 14px 18px 8px; color: #fff; font: 500 11px/1.2 system-ui, sans-serif; pointer-events: none; opacity: 0; visibility: hidden; transform: translateY(13px); transition: opacity 220ms ease, transform 280ms cubic-bezier(.2,.75,.25,1), visibility 0s linear 280ms; }
        #controlGuide::before, #controlGuide::after { content: ""; position: absolute; left: -8vw; right: -8vw; bottom: -34px; height: 276px; pointer-events: none; }
        #controlGuide::before { z-index: -2; background: linear-gradient(to top, rgba(0,0,0,.84) 0%, rgba(0,0,0,.72) 15%, rgba(0,0,0,.5) 37%, rgba(0,0,0,.25) 62%, rgba(0,0,0,.08) 82%, transparent 100%); }
        #controlGuide::after { z-index: -1; background: rgba(0,0,0,.01); -webkit-backdrop-filter: blur(13px); backdrop-filter: blur(13px); -webkit-mask-image: linear-gradient(to top, #000 0%, rgba(0,0,0,.92) 22%, rgba(0,0,0,.68) 47%, rgba(0,0,0,.3) 73%, transparent 100%); mask-image: linear-gradient(to top, #000 0%, rgba(0,0,0,.92) 22%, rgba(0,0,0,.68) 47%, rgba(0,0,0,.3) 73%, transparent 100%); }
        #controlGuide[data-visible="true"] { opacity: 1; visibility: visible; transform: translateY(0); transition-delay: 0s; }
        #controlGuide[data-mode="spotlight"] #yGuide, #controlGuide[data-mode="y"] #spotlightGuide { display: none; }
        .guide-layout { display: flex; align-items: center; justify-content: center; gap: 17px; width: 100%; max-width: 1200px; }
        .guide-mode-title { display: inline-flex; align-items: center; gap: 5px; flex: 0 0 auto; color: rgba(255,255,255,.62); font-size: 8px; font-weight: 800; letter-spacing: .12em; white-space: nowrap; }
        .guide-items { display: flex; flex: 0 1 auto; flex-wrap: wrap; align-items: center; justify-content: center; min-width: 0; gap: 8px 19px; }
        .guide-item { all: initial; display: inline-flex; flex: 0 0 auto; align-items: center; gap: 5px; color: rgba(255,255,255,.96); font: 650 11px/1.2 system-ui, sans-serif; white-space: nowrap; }
        .guide-key { all: initial; box-sizing: border-box; display: inline-flex; min-width: 23px; height: 23px; align-items: center; justify-content: center; padding: 0 4px; border: 2px solid rgba(255,255,255,.58); border-radius: 6px; background: rgba(5,8,8,.72); color: #fff; font: 900 10px/1 system-ui, sans-serif; text-shadow: 0 1px 2px rgba(0,0,0,.75); box-shadow: inset 0 0 0 1px rgba(255,255,255,.08); }
        .guide-key-a, .guide-key-b, .guide-key-x, .guide-key-y { width: 23px; padding: 0; border-color: currentColor; border-radius: 50%; box-shadow: 0 0 0 1px rgba(0,0,0,.4), inset 0 0 0 1px rgba(255,255,255,.08); }
        .guide-key-a { color: #68e68b; }
        .guide-key-b { color: #ff6f72; }
        .guide-key-x { color: #70a9ff; }
        .guide-key-y { color: #ffdc62; }
        .guide-key-stick { min-width: 25px; height: 25px; border-width: 2px; border-radius: 50%; box-shadow: inset 0 0 0 2px rgba(255,255,255,.12), inset 0 0 0 5px rgba(0,0,0,.42); }
        .guide-key-dpad { flex: 0 0 23px; min-width: 23px; width: 23px; height: 23px; padding: 3px; border-radius: 5px; }
        .guide-dpad-icon { display: block; width: 100%; height: 100%; fill: none; stroke: currentColor; stroke-width: 2.8; stroke-linecap: round; stroke-linejoin: round; }
        .guide-pair { display: inline-flex; align-items: center; gap: 3px; }
        .guide-pair-separator { color: rgba(255,255,255,.5); font: 600 10px/1 system-ui, sans-serif; }
        @media (max-width: 680px) { #controlGuide { padding: 12px 10px 7px; } #controlGuide::before, #controlGuide::after { left: -12vw; right: -12vw; height: 238px; } .guide-layout { flex-wrap: wrap; gap: 5px 12px; } .guide-items { gap: 6px 13px; } }
        @media (prefers-reduced-motion: reduce) { #controlGuide { transition: none; } }
      </style>
      <svg id="overlaySvg" aria-hidden="true" viewBox="0 0 1 1">
        <defs><mask id="spotlightMask" style="mask-type:luminance" maskUnits="userSpaceOnUse" maskContentUnits="userSpaceOnUse" x="0" y="0" width="0" height="0"><rect id="maskBase" x="0" y="0" width="0" height="0" fill="white"></rect><path id="spotlightCutout" d="" fill="black"></path></mask></defs>
        <rect id="dim" x="0" y="0" width="0" height="0" mask="url(#spotlightMask)" visibility="hidden"></rect>
        <g id="selectedMark"></g>
        <g id="candidateNumbers"></g>
        <g id="virtualCursor" visibility="hidden"><circle id="virtualCursorOuter" r="10"></circle><circle id="virtualCursorInner" r="3.5"></circle></g>
      </svg>
      <div id="controlGuide" data-visible="false" data-mode="spotlight" aria-hidden="true">
        <div class="guide-layout" id="spotlightGuide">
          <span class="guide-mode-title">SPOTLIGHT</span>
          <div class="guide-items">
            <span class="guide-item"><span class="guide-key guide-key-a">A</span>\uC2E4\uD589</span>
            <span class="guide-item"><span class="guide-key guide-key-b">B</span>\uCDE8\uC18C</span>
            <span class="guide-item"><span class="guide-pair"><span class="guide-key guide-key-x">X</span><span class="guide-pair-separator">/</span><span class="guide-key">LT</span></span>\uB2E4\uC74C \uD6C4\uBCF4</span>
            <span class="guide-item"><span class="guide-key">LB</span>\uC774\uC804 \uD6C4\uBCF4</span>
            <span class="guide-item"><span class="guide-key guide-key-stick">LS</span>\uACE0\uC815</span>
            <span class="guide-item"><span class="guide-key guide-key-stick">RS</span>\uD6C4\uBCF4 \uC21C\uD658</span>
          </div>
        </div>
        <div class="guide-layout" id="yGuide">
          <span class="guide-mode-title"><span class="guide-key guide-key-y">Y</span> \uC720\uC9C0 \uC911</span>
          <div class="guide-items">
            <span class="guide-item"><span class="guide-key guide-key-dpad"><svg class="guide-dpad-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M9 3h6v6h6v6h-6v6H9v-6H3V9h6z" /></svg></span>\uD720 \uC774\uB3D9</span>
            <span class="guide-item"><span class="guide-key guide-key-stick">LS</span>\uB3CC\uB824 \uC2A4\uD06C\uB864</span>
            <span class="guide-item"><span class="guide-key">LB</span>\uC774\uC804 \uD0ED</span>
            <span class="guide-item"><span class="guide-key">LT</span>\uB2E4\uC74C \uD0ED</span>
            <span class="guide-item"><span class="guide-key guide-key-a">A</span>Enter</span>
            <span class="guide-item"><span class="guide-key guide-key-b">B</span>Esc</span>
          </div>
        </div>
      </div>
    `;
      svg = shadow.querySelector("svg");
      spotlightCutout = shadow.querySelector("#spotlightCutout");
      spotlightMask = shadow.querySelector("#spotlightMask");
      dimLayer = shadow.querySelector("#dim");
      selectedMarkLayer = shadow.querySelector("#selectedMark");
      candidateNumbersLayer = shadow.querySelector("#candidateNumbers");
      cursorLayer = shadow.querySelector("#virtualCursor");
      controlGuide = shadow.querySelector("#controlGuide");
      document.documentElement.append(host);
    }
    function createSpotlightPath(origin, direction) {
      const shortSide = Math.min(window.innerWidth, window.innerHeight);
      const polygon = createSpotlightPolygon(
        origin,
        direction,
        shortSide * settings.spotlightArrivalSize / 100,
        shortSide * settings.spotlightStartSize / 100,
        window.innerWidth,
        window.innerHeight
      );
      if (!polygon.length) return "";
      return `M ${polygon[0].x} ${polygon[0].y} ${polygon.slice(1).map((point) => `L ${point.x} ${point.y}`).join(" ")} Z`;
    }
    function render() {
      const selectedLayer = selectedMarkLayer;
      const numbersLayer = candidateNumbersLayer;
      const virtualCursorLayer = cursorLayer;
      const guide = controlGuide;
      if (!enabled || !host || !svg || !spotlightCutout || !spotlightMask || !dimLayer || !selectedLayer || !numbersLayer || !virtualCursorLayer || !guide) return;
      const overlayDirection = activeDirection ?? (pinned ? pinnedDirection : null);
      const showSpotlight = overlayDirection !== null;
      const showGuide = settings.controlGuideVisibility === "show" && (showSpotlight || yModeActive);
      guide.dataset.mode = yModeActive ? "y" : "spotlight";
      guide.dataset.visible = String(showGuide);
      if (!showSpotlight && !virtualPointerVisible && !showGuide) {
        setOverlayVisibility(false);
        return;
      }
      setOverlayVisibility(true);
      svg.setAttribute("viewBox", `0 0 ${window.innerWidth} ${window.innerHeight}`);
      spotlightMask.setAttribute("width", String(window.innerWidth));
      spotlightMask.setAttribute("height", String(window.innerHeight));
      const maskBase = shadow.querySelector("#maskBase");
      maskBase.setAttribute("width", String(window.innerWidth));
      maskBase.setAttribute("height", String(window.innerHeight));
      dimLayer.setAttribute("width", String(window.innerWidth));
      dimLayer.setAttribute("height", String(window.innerHeight));
      if (overlayDirection) {
        const spotlightPath = createSpotlightPath(centerPoint(), overlayDirection);
        spotlightCutout.setAttribute("d", spotlightPath);
        dimLayer.setAttribute("visibility", spotlightPath ? "visible" : "hidden");
      } else {
        spotlightCutout.setAttribute("d", "");
        dimLayer.setAttribute("visibility", "hidden");
      }
      selectedLayer.replaceChildren();
      if (!showSpotlight) {
        numbersLayer.replaceChildren();
        candidateMarksDirty = true;
      } else if (settings.candidateNumberVisibility === "hide") {
        numbersLayer.replaceChildren();
        candidateMarksDirty = false;
      } else if (candidateMarksDirty) {
        numbersLayer.replaceChildren();
        candidates.forEach((candidate, index) => {
          const { left, top } = candidate.rect;
          const label = String(index + 1);
          const badgeWidth = Math.max(14, label.length * 6 + 5);
          if (index !== selectedIndex) {
            const background = createSvg("rect");
            background.setAttribute("x", String(left + 2));
            background.setAttribute("y", String(top + 2));
            background.setAttribute("width", String(badgeWidth));
            background.setAttribute("height", "14");
            background.setAttribute("rx", "3.5");
            background.setAttribute("class", "candidateNumberBackground");
            numbersLayer.append(background);
          }
          const number = createSvg("text");
          number.textContent = label;
          number.setAttribute("x", String(left + 2 + badgeWidth / 2));
          number.setAttribute("y", String(top + 9));
          number.setAttribute("class", index === selectedIndex ? "selectedCandidateNumber" : "candidateNumber");
          numbersLayer.append(number);
        });
        candidateMarksDirty = false;
      }
      const selectedCandidate = showSpotlight ? candidates[selectedIndex] : void 0;
      if (selectedCandidate) {
        const rect = selectedCandidate.rect;
        const mark = createSvg("rect");
        mark.setAttribute("x", String(rect.left));
        mark.setAttribute("y", String(rect.top));
        mark.setAttribute("width", String(Math.max(1, rect.right - rect.left)));
        mark.setAttribute("height", String(Math.max(1, rect.bottom - rect.top)));
        mark.setAttribute("rx", "3");
        mark.setAttribute("id", "selectedElement");
        if (selectedCandidate.id instanceof HTMLIFrameElement) mark.setAttribute("data-kind", "iframe");
        selectedLayer.append(mark);
      }
      virtualCursorLayer.setAttribute("visibility", virtualPointerVisible ? "visible" : "hidden");
      virtualCursorLayer.setAttribute("transform", `translate(${virtualPointer.x} ${virtualPointer.y})`);
    }
    function sameCandidates(left, right) {
      return left.length === right.length && left.every((candidate, index) => candidate.id === right[index]?.id);
    }
    function refreshCandidates(direction) {
      const nextCandidates = collectCandidates(direction);
      candidateMarksDirty = true;
      if (!sameCandidates(candidates, nextCandidates)) {
        const previouslySelected = candidates[selectedIndex]?.id;
        candidates = nextCandidates;
        selectedIndex = resolveSelectionIndex(
          previouslySelected,
          candidates.map((candidate) => candidate.id),
          settings.candidateStart === "preserve"
        );
      } else {
        candidates = nextCandidates;
      }
      refreshNeeded = false;
      lastRefreshAt = performance.now();
      lastDirectionAngle = Math.atan2(direction.y, direction.x);
    }
    function applySettings(value) {
      const previous = settings;
      settings = normalizeSettings(value);
      if (previous.neutralBehavior !== settings.neutralBehavior && !activeDirection && !pinned && settings.neutralBehavior === "clear") {
        candidates = [];
        selectedIndex = -1;
      }
      refreshNeeded = true;
      candidateMarksDirty = true;
      const spotlightDirection = activeDirection ?? (pinned ? pinnedDirection : null);
      if (spotlightDirection) refreshCandidates(spotlightDirection);
      render();
    }
    function resetInputEdges() {
      xWasDown = false;
      rightTriggerWasDown = false;
      leftTriggerWasDown = false;
      leftStickClickWasDown = false;
      rightStickClickWasDown = false;
      leftBumperWasDown = false;
      rightBumperWasDown = false;
      aWasDown = false;
      bWasDown = false;
      yModeActive = false;
      lastLeftStickScrollAngle = null;
      lastRightStickCycleAngle = null;
      rightStickCycleRemainder = 0;
      releaseArrowKeys();
      ignoreCurrentButtons = true;
      connectedGamepad = false;
      virtualPointerVisible = false;
      virtualPointerVisibleUntil = 0;
      lastFrameAt = 0;
    }
    function snapshotGamepad(gamepad) {
      return {
        axes: Array.from(gamepad.axes),
        buttons: Array.from(gamepad.buttons, (button) => ({ pressed: button.pressed, value: button.value }))
      };
    }
    function gamepadFrame(timestamp) {
      frameId = null;
      if (!enabled || !isTopFrame || !activeTabOwned || document.visibilityState !== "visible" || document.hasFocus?.() === false) return;
      let gamepads = [];
      try {
        gamepads = [...navigator.getGamepads()];
      } catch {
        gamepads = [];
      }
      const gamepad = gamepads.find((item) => item?.connected && item.mapping === "standard" && item.axes.length >= 4 && item.buttons.length >= 16) ?? null;
      connectedGamepad = Boolean(gamepad);
      if (activeFramePath.length) {
        void chrome.runtime.sendMessage({
          type: "joy-nav:send-frame-input",
          route: [frameToken, ...activeFramePath],
          timestamp,
          sequence: ++frameInputSequence,
          sample: gamepad ? snapshotGamepad(gamepad) : null
        }).catch(() => void 0);
      } else {
        processGamepadFrame(timestamp, gamepad ? snapshotGamepad(gamepad) : null);
      }
      render();
      frameId = requestAnimationFrame(gamepadFrame);
    }
    function processGamepadFrame(timestamp, gamepad) {
      if (!enabled) return;
      if (!isTopFrame) ensureOverlay();
      const elapsedSeconds = lastFrameAt ? Math.min((timestamp - lastFrameAt) / 1e3, 0.05) : 0;
      lastFrameAt = timestamp;
      if (virtualPointerVisible && performance.now() >= virtualPointerVisibleUntil) virtualPointerVisible = false;
      connectedGamepad = Boolean(gamepad);
      if (!gamepad) {
        if (activeDirection && !pinned && settings.neutralBehavior === "clear") {
          candidates = [];
          selectedIndex = -1;
        }
        activeDirection = null;
        smoothedLeftStick = { x: 0, y: 0 };
        lastDirectionAngle = null;
        overlayDismissedUntilNeutral = false;
        yModeActive = false;
        resetInputEdges();
        render();
        return;
      }
      if (!pointerInitialized) {
        virtualPointer = centerPoint();
        pointerInitialized = true;
      }
      const yDown = gamepad.buttons[3].pressed;
      if (!isTopFrame && ignoreCurrentButtons) yModeActive = yDown;
      if (yDown && !yModeActive) {
        if (!isTopFrame) {
          returnToParentFrame();
          return;
        }
        cancelCone();
        lastActiveDirection = null;
      }
      const smoothing = elapsedSeconds > 0 ? elapsedSeconds / (SPOTLIGHT_SMOOTHING_SECONDS + elapsedSeconds) : 1;
      smoothedLeftStick = {
        x: smoothedLeftStick.x + (gamepad.axes[0] - smoothedLeftStick.x) * smoothing,
        y: smoothedLeftStick.y + (gamepad.axes[1] - smoothedLeftStick.y) * smoothing
      };
      const direction = readDirection(smoothedLeftStick.x, smoothedLeftStick.y, settings.deadzone);
      const hadActiveDirection = activeDirection !== null;
      if (yDown) {
        if (activeDirection && (refreshNeeded || performance.now() - lastRefreshAt >= 180)) refreshCandidates(activeDirection);
      } else {
        if (!direction) {
          overlayDismissedUntilNeutral = false;
          activeDirection = null;
          if (!pinned) lastDirectionAngle = null;
        } else if (!overlayDismissedUntilNeutral) {
          const angle = Math.atan2(direction.y, direction.x);
          const angleChanged = lastDirectionAngle === null || Math.abs(Math.atan2(Math.sin(angle - lastDirectionAngle), Math.cos(angle - lastDirectionAngle))) > Math.PI / 90;
          if (refreshNeeded || angleChanged || performance.now() - lastRefreshAt >= 180) refreshCandidates(direction);
          activeDirection = direction;
          lastActiveDirection = direction;
          if (pinned) pinnedDirection = direction;
        } else {
          activeDirection = null;
        }
      }
      const xDown = gamepad.buttons[2].pressed;
      const leftBumperDown = gamepad.buttons[4].pressed;
      const rightBumperDown = gamepad.buttons[5].pressed;
      const leftTriggerDown = readTrigger(gamepad, 6);
      const rightTriggerDown = readTrigger(gamepad, 7);
      const aDown = gamepad.buttons[0].pressed;
      const bDown = gamepad.buttons[1].pressed;
      const leftStickClickDown = gamepad.buttons[10].pressed;
      const rightStickClickDown = gamepad.buttons[11].pressed;
      if (ignoreCurrentButtons) {
        xWasDown = xDown;
        rightTriggerWasDown = rightTriggerDown;
        leftTriggerWasDown = leftTriggerDown;
        leftStickClickWasDown = leftStickClickDown;
        rightStickClickWasDown = rightStickClickDown;
        leftBumperWasDown = leftBumperDown;
        rightBumperWasDown = rightBumperDown;
        aWasDown = aDown;
        bWasDown = bDown;
        yModeActive = yDown;
        if (activeDirection !== null || pinned && pinnedDirection !== null) {
          cycleCandidatesWithRightStick(gamepad.axes[2], gamepad.axes[3]);
        } else {
          resetRightStickCandidateCycle();
          moveVirtualPointer(gamepad.axes[2], gamepad.axes[3], elapsedSeconds);
        }
        ignoreCurrentButtons = false;
      } else {
        if (yDown !== yModeActive) {
          yModeActive = yDown;
          releaseArrowKeys();
        }
        if (hasRisen(leftStickClickDown, leftStickClickWasDown)) {
          if (pinned) {
            pinned = false;
            pinnedDirection = null;
          } else {
            const directionToPin = activeDirection ?? lastActiveDirection;
            if (directionToPin) {
              pinned = true;
              pinnedDirection = directionToPin;
              refreshNeeded = true;
            }
          }
        }
        const spotlightActive = activeDirection !== null || pinned && pinnedDirection !== null;
        if (spotlightActive) {
          cycleCandidatesWithRightStick(gamepad.axes[2], gamepad.axes[3]);
        } else {
          resetRightStickCandidateCycle();
          moveVirtualPointer(gamepad.axes[2], gamepad.axes[3], elapsedSeconds);
        }
        const l1Rose = hasRisen(leftBumperDown, leftBumperWasDown);
        const l2Rose = hasRisen(leftTriggerDown, leftTriggerWasDown);
        const xRose = hasRisen(xDown, xWasDown);
        if (spotlightActive) {
          if (l1Rose) cycleSelectedCandidate("previous");
          else if (l2Rose || xRose) cycleSelectedCandidate("next");
        } else if (xRose && !yDown) {
          pressKeyboardKey(" ");
        }
        if (yDown) {
          releaseArrowKeys();
          if (!spotlightActive && l1Rose) void sendBrowserCommand("previous-tab");
          if (!spotlightActive && l2Rose) void sendBrowserCommand("next-tab");
          scrollWithDpad(gamepad, elapsedSeconds);
          scrollWithLeftStick(direction, elapsedSeconds);
        } else {
          lastLeftStickScrollAngle = null;
          updateArrowKeys(gamepad, timestamp);
          if (!spotlightActive && l1Rose) void sendBrowserCommand("back");
          if (!spotlightActive && l2Rose) void sendBrowserCommand("forward");
        }
        if (hasRisen(rightBumperDown, rightBumperWasDown)) clickAtVirtualPointer("right");
        if (hasRisen(rightTriggerDown, rightTriggerWasDown)) clickAtVirtualPointer("left");
        if (hasRisen(rightStickClickDown, rightStickClickWasDown)) clickAtVirtualPointer("middle");
        const bRose = hasRisen(bDown, bWasDown);
        const aRose = hasRisen(aDown, aWasDown);
        if (bRose && spotlightActive) {
          rememberSelectedIframe(true);
          cancelCone();
        } else if (bRose && !isTopFrame) {
          returnToParentFrame();
        } else if (bRose) {
          pressKeyboardKey("Escape");
        } else if (aRose && spotlightActive) {
          const selected = candidates[selectedIndex]?.id;
          if (selected && !(selected instanceof HTMLIFrameElement) && candidateIsVisible(selected)) {
            focusSelected();
            pressEnter(selected);
            if (pinned) {
              pinned = false;
              pinnedDirection = null;
            }
          }
        } else if (aRose) {
          pressEnter();
        }
        xWasDown = xDown;
        rightTriggerWasDown = rightTriggerDown;
        leftTriggerWasDown = leftTriggerDown;
        leftStickClickWasDown = leftStickClickDown;
        rightStickClickWasDown = rightStickClickDown;
        leftBumperWasDown = leftBumperDown;
        rightBumperWasDown = rightBumperDown;
        aWasDown = aDown;
        bWasDown = bDown;
      }
      if (!activeDirection && pinned && pinnedDirection && (refreshNeeded || performance.now() - lastRefreshAt >= 180)) {
        refreshCandidates(pinnedDirection);
      }
      if (!activeDirection && !pinned && hadActiveDirection) {
        rememberSelectedIframe();
        if (settings.neutralBehavior === "clear") {
          candidates = [];
          selectedIndex = -1;
        }
      }
      render();
    }
    function readTrigger(gamepad, index) {
      const trigger = gamepad.buttons[index];
      if (!trigger) return false;
      const value = Number.isFinite(trigger.value) ? trigger.value : Number(trigger.pressed);
      return value >= settings.triggerThreshold;
    }
    function moveVirtualPointer(axisX, axisY, elapsedSeconds) {
      const direction = readDirection(axisX, axisY, settings.deadzone);
      if (!direction || elapsedSeconds <= 0) return;
      const effectiveMagnitude = Math.min(1, (direction.magnitude - settings.deadzone) / (1 - settings.deadzone));
      const speed = settings.pointerMaxSpeed * mapSpeedCurve(effectiveMagnitude, settings.pointerSpeedCurve);
      const distance = speed * elapsedSeconds;
      const nextX = Math.min(Math.max(0, window.innerWidth - 1), Math.max(0, virtualPointer.x + direction.x / direction.magnitude * distance));
      const nextY = Math.min(Math.max(0, window.innerHeight - 1), Math.max(0, virtualPointer.y + direction.y / direction.magnitude * distance));
      if (nextX === virtualPointer.x && nextY === virtualPointer.y) return;
      virtualPointer = { x: nextX, y: nextY };
      showVirtualPointer();
      dispatchMouseMove(nextX, nextY);
    }
    function moveVirtualPointerTo(element) {
      const rect = element.getBoundingClientRect();
      virtualPointer = {
        x: Math.min(Math.max(0, rect.left + rect.width / 2), Math.max(0, window.innerWidth - 1)),
        y: Math.min(Math.max(0, rect.top + rect.height / 2), Math.max(0, window.innerHeight - 1))
      };
      virtualPointerVisible = false;
      virtualPointerVisibleUntil = 0;
    }
    function showVirtualPointer() {
      virtualPointerVisible = true;
      virtualPointerVisibleUntil = performance.now() + POINTER_DISPLAY_DURATION;
    }
    function dispatchMouseMove(x, y) {
      const target = document.elementFromPoint(x, y) ?? document.documentElement;
      target.dispatchEvent(new PointerEvent("pointermove", { bubbles: true, composed: true, pointerType: "mouse", clientX: x, clientY: y, isPrimary: true }));
      target.dispatchEvent(new MouseEvent("mousemove", { bubbles: true, composed: true, view: window, clientX: x, clientY: y }));
    }
    function keyboardTarget() {
      return document.activeElement instanceof HTMLElement ? document.activeElement : document.body ?? document.documentElement;
    }
    function dispatchKeyboard(target, type, key, repeat = false) {
      const code = key === " " ? "Space" : key;
      const event = new KeyboardEvent(type, { key, code, bubbles: true, cancelable: true, composed: true, repeat });
      target.dispatchEvent(event);
      return event;
    }
    function pressKeyboardKey(key) {
      const target = keyboardTarget();
      const down = dispatchKeyboard(target, "keydown", key);
      const up = dispatchKeyboard(target, "keyup", key);
      if (key === "Escape" && !down.defaultPrevented && !up.defaultPrevented) {
        const dialog = target.closest("dialog[open]");
        if (dialog?.open) dialog.close();
      }
    }
    function pressEnter(target = keyboardTarget()) {
      const keyDown = dispatchKeyboard(target, "keydown", "Enter");
      const keyUp = dispatchKeyboard(target, "keyup", "Enter");
      if (keyDown.defaultPrevented || keyUp.defaultPrevented) return;
      if (target instanceof HTMLInputElement && target.form && ["email", "number", "password", "search", "tel", "text", "url"].includes(target.type)) {
        target.form.requestSubmit();
        return;
      }
      target.closest(CLICKABLE_SELECTOR)?.click();
    }
    function updateArrowKeys(gamepad, timestamp) {
      for (const item of ARROW_BUTTONS) {
        const isDown = Boolean(gamepad.buttons[item.button]?.pressed);
        const repeatAt = arrowKeyRepeatAt.get(item.key);
        if (isDown && repeatAt === void 0) {
          const target = keyboardTarget();
          const event = dispatchKeyboard(target, "keydown", item.key);
          if (!event.defaultPrevented) applyArrowDefault(target, item.key);
          arrowKeyRepeatAt.set(item.key, timestamp + ARROW_REPEAT_DELAY);
        } else if (isDown && repeatAt !== void 0 && timestamp >= repeatAt) {
          const target = keyboardTarget();
          const event = dispatchKeyboard(target, "keydown", item.key, true);
          if (!event.defaultPrevented) applyArrowDefault(target, item.key);
          arrowKeyRepeatAt.set(item.key, timestamp + ARROW_REPEAT_INTERVAL);
        } else if (!isDown && repeatAt !== void 0) {
          dispatchKeyboard(keyboardTarget(), "keyup", item.key);
          arrowKeyRepeatAt.delete(item.key);
        }
      }
    }
    function applyArrowDefault(target, key) {
      if (target instanceof HTMLInputElement && ["number", "range"].includes(target.type)) {
        const step = target.step === "any" ? 1 : Number(target.step || 1);
        const direction = key === "ArrowUp" || key === "ArrowRight" ? 1 : -1;
        const min = target.min === "" ? -Infinity : Number(target.min);
        const max = target.max === "" ? Infinity : Number(target.max);
        const current = Number(target.value);
        if (!Number.isFinite(current) || !Number.isFinite(step)) return;
        target.value = String(Math.min(max, Math.max(min, current + direction * step)));
        target.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
        target.dispatchEvent(new Event("change", { bubbles: true }));
        return;
      }
      if (target instanceof HTMLInputElement && ["email", "password", "search", "tel", "text", "url"].includes(target.type)) {
        if (key === "ArrowLeft" || key === "ArrowRight") {
          const start = target.selectionStart;
          const end = target.selectionEnd;
          if (start === null || end === null) return;
          const position = start !== end ? key === "ArrowLeft" ? start : end : start + (key === "ArrowRight" ? 1 : -1);
          target.setSelectionRange(Math.min(target.value.length, Math.max(0, position)), Math.min(target.value.length, Math.max(0, position)));
          target.dispatchEvent(new Event("select", { bubbles: true }));
        }
        return;
      }
      if (target instanceof HTMLTextAreaElement) {
        const start = target.selectionStart;
        const end = target.selectionEnd;
        if (start !== end && (key === "ArrowLeft" || key === "ArrowRight")) {
          const position = key === "ArrowLeft" ? start : end;
          target.setSelectionRange(position, position);
          target.dispatchEvent(new Event("select", { bubbles: true }));
          return;
        }
        const value = target.value;
        const lineStart = value.lastIndexOf("\n", Math.max(0, start - 1)) + 1;
        const column = start - lineStart;
        let nextPosition = start;
        if (key === "ArrowLeft") nextPosition = Math.max(0, start - 1);
        else if (key === "ArrowRight") nextPosition = Math.min(value.length, start + 1);
        else if (key === "ArrowUp" && lineStart > 0) {
          const previousLineEnd = lineStart - 1;
          const previousLineStart = value.lastIndexOf("\n", Math.max(0, previousLineEnd - 1)) + 1;
          nextPosition = Math.min(previousLineStart + column, previousLineEnd);
        } else if (key === "ArrowDown") {
          const nextLineStart = value.indexOf("\n", start);
          if (nextLineStart >= 0) {
            const nextLineEndIndex = value.indexOf("\n", nextLineStart + 1);
            const nextLineEnd = nextLineEndIndex < 0 ? value.length : nextLineEndIndex;
            nextPosition = Math.min(nextLineStart + 1 + column, nextLineEnd);
          }
        }
        target.setSelectionRange(nextPosition, nextPosition);
        target.dispatchEvent(new Event("select", { bubbles: true }));
        return;
      }
      if (target.isContentEditable) return;
      if (target instanceof HTMLSelectElement) {
        const direction = key === "ArrowUp" || key === "ArrowLeft" ? -1 : 1;
        target.selectedIndex = Math.min(target.options.length - 1, Math.max(0, target.selectedIndex + direction));
        target.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
        target.dispatchEvent(new Event("change", { bubbles: true }));
        return;
      }
      window.scrollBy({
        left: key === "ArrowLeft" ? -40 : key === "ArrowRight" ? 40 : 0,
        top: key === "ArrowUp" ? -40 : key === "ArrowDown" ? 40 : 0,
        behavior: "auto"
      });
    }
    function releaseArrowKeys() {
      for (const key of arrowKeyRepeatAt.keys()) dispatchKeyboard(keyboardTarget(), "keyup", key);
      arrowKeyRepeatAt.clear();
    }
    function scrollWithDpad(gamepad, elapsedSeconds) {
      const vertical = Number(Boolean(gamepad.buttons[13]?.pressed)) - Number(Boolean(gamepad.buttons[12]?.pressed));
      const horizontal = Number(Boolean(gamepad.buttons[15]?.pressed)) - Number(Boolean(gamepad.buttons[14]?.pressed));
      if (!vertical && !horizontal || elapsedSeconds <= 0) return;
      const magnitude = Math.hypot(horizontal, vertical);
      const speed = settings.scrollMaxSpeed * elapsedSeconds / Math.max(1, magnitude);
      const deltaX = horizontal * speed;
      const deltaY = vertical * speed;
      scrollAtVirtualPointer(deltaX, deltaY);
    }
    function scrollWithLeftStick(direction, elapsedSeconds) {
      if (!direction) {
        lastLeftStickScrollAngle = null;
        return;
      }
      const angle = Math.atan2(direction.y, direction.x);
      const previousAngle = lastLeftStickScrollAngle;
      lastLeftStickScrollAngle = angle;
      if (previousAngle === null || elapsedSeconds <= 0) return;
      const angleDelta = clockwiseAngleDelta(previousAngle, angle);
      const magnitude = Math.min(1, (direction.magnitude - settings.deadzone) / (1 - settings.deadzone));
      const speedFactor = mapSpeedCurve(magnitude, settings.scrollSpeedCurve);
      const turnsPerSecond = Math.min(1, Math.abs(angleDelta) / (2 * Math.PI * elapsedSeconds));
      const deltaY = Math.sign(angleDelta) * settings.scrollMaxSpeed * turnsPerSecond * speedFactor * elapsedSeconds;
      if (deltaY) scrollAtVirtualPointer(0, deltaY);
    }
    function cycleCandidatesWithRightStick(axisX, axisY) {
      const direction = readDirection(axisX, axisY, settings.deadzone);
      if (!direction) {
        lastRightStickCycleAngle = null;
        rightStickCycleRemainder = 0;
        return;
      }
      const angle = Math.atan2(direction.y, direction.x);
      const previousAngle = lastRightStickCycleAngle;
      lastRightStickCycleAngle = angle;
      if (previousAngle === null) return;
      if (candidates.length < 2) {
        rightStickCycleRemainder = 0;
        return;
      }
      const angleDelta = clockwiseAngleDelta(previousAngle, angle);
      const magnitude = Math.min(1, (direction.magnitude - settings.deadzone) / (1 - settings.deadzone));
      rightStickCycleRemainder += angleDelta * magnitude;
      const stepAngle = settings.rightStickCandidateStepDegrees * Math.PI / 180;
      const steps = Math.trunc(rightStickCycleRemainder / stepAngle);
      if (!steps) return;
      rightStickCycleRemainder -= steps * stepAngle;
      const cycleDirection = steps > 0 ? "next" : "previous";
      for (let index = 0; index < Math.abs(steps); index += 1) cycleSelectedCandidate(cycleDirection);
    }
    function resetRightStickCandidateCycle() {
      lastRightStickCycleAngle = null;
      rightStickCycleRemainder = 0;
    }
    function clockwiseAngleDelta(previousAngle, angle) {
      let delta = angle - previousAngle;
      if (delta > Math.PI) delta -= 2 * Math.PI;
      else if (delta < -Math.PI) delta += 2 * Math.PI;
      return delta;
    }
    function scrollAtVirtualPointer(deltaX, deltaY) {
      if (!deltaX && !deltaY) return;
      showVirtualPointer();
      const target = document.elementFromPoint(virtualPointer.x, virtualPointer.y) ?? document.documentElement;
      const allowed = target.dispatchEvent(new WheelEvent("wheel", { bubbles: true, cancelable: true, composed: true, view: window, clientX: virtualPointer.x, clientY: virtualPointer.y, deltaX, deltaY, deltaMode: WheelEvent.DOM_DELTA_PIXEL }));
      if (allowed) scrollAtTarget(target, deltaX, deltaY);
    }
    function scrollAtTarget(target, deltaX, deltaY) {
      const horizontalTarget = scrollableAncestor(target, "x", deltaX);
      const verticalTarget = scrollableAncestor(target, "y", deltaY);
      if (horizontalTarget) horizontalTarget.scrollBy({ left: deltaX, behavior: "auto" });
      else if (deltaX) window.scrollBy({ left: deltaX, behavior: "auto" });
      if (verticalTarget) verticalTarget.scrollBy({ top: deltaY, behavior: "auto" });
      else if (deltaY) window.scrollBy({ top: deltaY, behavior: "auto" });
    }
    function scrollableAncestor(target, axis, delta) {
      let ancestor = target instanceof HTMLElement ? target : target.parentElement;
      while (ancestor && ancestor !== document.documentElement) {
        if (canScroll(ancestor, axis, delta)) return ancestor;
        ancestor = ancestor.parentElement;
      }
      return null;
    }
    function canScroll(element, axis, delta) {
      if (!delta) return false;
      const style = getComputedStyle(element);
      const overflow = axis === "x" ? style.overflowX : style.overflowY;
      if (!/(auto|scroll|overlay)/.test(overflow)) return false;
      const current = axis === "x" ? element.scrollLeft : element.scrollTop;
      const extent = axis === "x" ? element.scrollWidth - element.clientWidth : element.scrollHeight - element.clientHeight;
      return extent > 0 && (delta > 0 ? current < extent : current > 0);
    }
    function clickAtVirtualPointer(button) {
      const target = document.elementFromPoint(virtualPointer.x, virtualPointer.y);
      if (!target || host?.contains(target)) return;
      showVirtualPointer();
      const mouseButton = button === "left" ? 0 : button === "middle" ? 1 : 2;
      const buttons = button === "left" ? 1 : button === "middle" ? 4 : 2;
      const base = { bubbles: true, cancelable: true, composed: true, view: window, clientX: virtualPointer.x, clientY: virtualPointer.y, button: mouseButton };
      target.dispatchEvent(new PointerEvent("pointerdown", { ...base, pointerId: 1, pointerType: "mouse", isPrimary: true, buttons }));
      target.dispatchEvent(new MouseEvent("mousedown", { ...base, buttons }));
      if (button === "right") {
        target.dispatchEvent(new MouseEvent("contextmenu", { ...base, buttons }));
      }
      target.dispatchEvent(new PointerEvent("pointerup", { ...base, pointerId: 1, pointerType: "mouse", isPrimary: true, buttons: 0 }));
      target.dispatchEvent(new MouseEvent("mouseup", { ...base, buttons: 0 }));
      if (button === "left") {
        const clickable = target.closest(CLICKABLE_SELECTOR) ?? (target instanceof HTMLElement ? target : null);
        clickable?.click();
        return;
      }
      const auxiliaryClick = new MouseEvent("auxclick", { ...base, buttons: 0 });
      if (button === "middle") target.dispatchEvent(auxiliaryClick);
      if (button === "middle" && !auxiliaryClick.defaultPrevented) {
        const anchor = target.closest("a[href]");
        if (anchor && /^https?:$/i.test(new URL(anchor.href, document.baseURI).protocol)) {
          void chrome.runtime.sendMessage({ type: "joy-nav:open-background-tab", url: anchor.href }).catch(() => void 0);
        }
      }
    }
    function cancelCone() {
      overlayDismissedUntilNeutral = true;
      activeDirection = null;
      pinned = false;
      pinnedDirection = null;
      candidates = [];
      selectedIndex = -1;
      lastDirectionAngle = null;
      refreshNeeded = true;
    }
    function selectedIframe() {
      const selected = candidates[selectedIndex]?.id;
      return selected instanceof HTMLIFrameElement ? selected : null;
    }
    function requestFrameRoute(route, waitForNeutral = false) {
      if (route.length === 0 || route[0] !== framePath[0]) return;
      pendingFramePath = route;
      pendingFrameWaitForNeutral = waitForNeutral;
      pendingFrameRouteAttempts = 0;
      if (frameRouteRetryTimer !== null) window.clearTimeout(frameRouteRetryTimer);
      frameRouteRetryTimer = null;
      sendPendingFrameRoute();
    }
    function sendPendingFrameRoute() {
      const route = pendingFramePath;
      if (!route || !framePathRegistered) return;
      const waitForNeutral = pendingFrameWaitForNeutral;
      void chrome.runtime.sendMessage({ type: "joy-nav:set-frame-route", route, waitForNeutral }).then((response) => {
        if (pendingFramePath !== route) return;
        if (response?.routed) {
          pendingFramePath = null;
          pendingFrameWaitForNeutral = false;
          pendingFrameRouteAttempts = 0;
          frameRouteRetryTimer = null;
        } else if (pendingFrameRouteAttempts < 20) {
          pendingFrameRouteAttempts += 1;
          frameRouteRetryTimer = window.setTimeout(sendPendingFrameRoute, 100);
        }
      }).catch(() => {
        if (pendingFramePath !== route || pendingFrameRouteAttempts >= 20) return;
        pendingFrameRouteAttempts += 1;
        frameRouteRetryTimer = window.setTimeout(sendPendingFrameRoute, 100);
      });
    }
    function rememberSelectedIframe(waitForNeutral = false) {
      const iframe = selectedIframe();
      if (!iframe) return;
      activateIframe(iframe, waitForNeutral);
    }
    function activateIframe(iframe, waitForNeutral = false) {
      pendingSelectedIframe = iframe;
      pendingFrameWaitForNeutral = waitForNeutral;
      const childToken = frameTokenByElement.get(iframe);
      if (!childToken) return;
      pendingSelectedIframe = null;
      requestFrameRoute([...framePath, childToken], waitForNeutral);
    }
    let pendingSelectedIframe = null;
    function returnToParentFrame() {
      if (isTopFrame || framePath.length < 2) return;
      requestFrameRoute(framePath.slice(0, -1));
    }
    function clearLocalNavigation() {
      activeDirection = null;
      lastActiveDirection = null;
      pinnedDirection = null;
      pinned = false;
      candidates = [];
      selectedIndex = -1;
      lastDirectionAngle = null;
      smoothedLeftStick = { x: 0, y: 0 };
      overlayDismissedUntilNeutral = true;
      refreshNeeded = true;
      resetInputEdges();
      render();
    }
    function registerFramePath() {
      if (!framePath.length || framePath[framePath.length - 1] !== frameToken) return;
      void chrome.runtime.sendMessage({ type: "joy-nav:register-frame", token: frameToken, route: framePath }).then((response) => {
        framePathRegistered = response?.registered === true;
        if (framePathRegistered && pendingFramePath) requestFrameRoute(pendingFramePath);
      }).catch(() => {
        framePathRegistered = false;
      });
    }
    function onFrameHandshake(event) {
      const message = event.data;
      if (message?.type === "joy-nav:frame-hello" && typeof message.token === "string" && event.source) {
        const iframe = [...document.querySelectorAll("iframe")].find((item) => item.contentWindow === event.source);
        if (!iframe) return;
        const previousToken = frameTokenByElement.get(iframe);
        if (previousToken && previousToken !== message.token) frameElementByToken.delete(previousToken);
        frameTokenByElement.set(iframe, message.token);
        frameElementByToken.set(message.token, iframe);
        event.source.postMessage({ type: "joy-nav:frame-parent", token: message.token, route: framePath }, "*");
        if (pendingSelectedIframe === iframe) activateIframe(iframe, pendingFrameWaitForNeutral);
        return;
      }
      if (message?.type !== "joy-nav:frame-parent" || event.source !== window.parent || message.token !== frameToken) return;
      if (!Array.isArray(message.route) || !message.route.every((part) => typeof part === "string")) return;
      framePath = [...message.route, frameToken];
      framePathRegistered = false;
      registerFramePath();
    }
    function cycleSelectedCandidate(direction) {
      if (!candidates.length) return;
      if (direction === "next") {
        selectedIndex = nextCycleIndex(selectedIndex, candidates.length);
      } else {
        selectedIndex = selectedIndex < 0 || selectedIndex >= candidates.length ? candidates.length - 1 : (selectedIndex - 1 + candidates.length) % candidates.length;
      }
      candidateMarksDirty = true;
      focusSelected();
      render();
    }
    function sendBrowserCommand(command) {
      return chrome.runtime.sendMessage({ type: "joy-nav:browser-command", command }).then(() => void 0).catch(() => void 0);
    }
    function focusSelected() {
      const element = candidates[selectedIndex]?.id;
      if (!element || !candidateIsVisible(element)) {
        refreshNeeded = true;
        return false;
      }
      moveVirtualPointerTo(element);
      if (element instanceof HTMLIFrameElement) return true;
      const focusWithoutScroll = () => {
        try {
          element.focus({ preventScroll: true });
        } catch {
          element.focus();
        }
      };
      focusWithoutScroll();
      if (document.activeElement === element) return true;
      if (element.hasAttribute("tabindex")) return false;
      element.setAttribute("tabindex", "-1");
      temporaryTabIndexTargets.add(element);
      element.addEventListener("blur", () => {
        if (!temporaryTabIndexTargets.delete(element)) return;
        if (element.getAttribute("tabindex") === "-1") element.removeAttribute("tabindex");
      }, { once: true });
      focusWithoutScroll();
      if (document.activeElement === element) return true;
      if (temporaryTabIndexTargets.delete(element)) element.removeAttribute("tabindex");
      refreshNeeded = true;
      return false;
    }
    function startLoop() {
      if (!isTopFrame || !enabled || !activeTabOwned || frameId !== null) return;
      supported = typeof navigator.getGamepads === "function";
      ensureOverlay();
      if (!supported) {
        render();
        return;
      }
      render();
      frameId = requestAnimationFrame(gamepadFrame);
    }
    function stopLoop() {
      if (isTopFrame && activeFramePath.length) {
        void chrome.runtime.sendMessage({ type: "joy-nav:deactivate-frame", route: [frameToken, ...activeFramePath] }).catch(() => void 0);
      }
      if (frameId !== null) cancelAnimationFrame(frameId);
      frameId = null;
      activeDirection = null;
      smoothedLeftStick = { x: 0, y: 0 };
      if (settings.neutralBehavior === "clear" && !pinned) {
        candidates = [];
        selectedIndex = -1;
      }
      refreshNeeded = true;
      resetInputEdges();
      setOverlayVisibility(false);
    }
    function status() {
      return { enabled, supported, gamepadConnected: connectedGamepad };
    }
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (sender.id === chrome.runtime.id && message?.type === "joy-nav:frame-input" && !isTopFrame && message.frameToken === frameToken) {
        const sample = message.sample === null ? null : isGamepadSample(message.sample) ? message.sample : void 0;
        if (sample !== void 0 && typeof message.timestamp === "number") processGamepadFrame(message.timestamp, sample);
        return false;
      }
      if (sender.id === chrome.runtime.id && message?.type === "joy-nav:deactivate-frame" && !isTopFrame && message.frameToken === frameToken) {
        clearLocalNavigation();
        return false;
      }
      if (sender.id === chrome.runtime.id && message?.type === "joy-nav:wait-for-neutral" && !isTopFrame && message.frameToken === frameToken) {
        overlayDismissedUntilNeutral = true;
        return false;
      }
      if (sender.id === chrome.runtime.id && message?.type === "joy-nav:frame-route" && isTopFrame && Array.isArray(message.route)) {
        const route = message.route;
        if (route[0] !== frameToken || !route.every((part) => typeof part === "string")) return false;
        activeFramePath = route.slice(1);
        clearLocalNavigation();
        pendingFramePath = null;
        pendingFrameWaitForNeutral = false;
        pendingFrameRouteAttempts = 0;
        if (frameRouteRetryTimer !== null) window.clearTimeout(frameRouteRetryTimer);
        frameRouteRetryTimer = null;
        return false;
      }
      if (message?.type === "joy-nav:tab-ownership" && typeof message.active === "boolean") {
        if (!isTopFrame) return false;
        const pageIsFocused = document.visibilityState === "visible" && document.hasFocus?.() !== false;
        activeTabOwned = message.active && pageIsFocused;
        if (activeTabOwned) {
          resetInputEdges();
          void chrome.storage.local.get("settings").then(({ settings: savedSettings }) => {
            if (!activeTabOwned) return;
            applySettings(savedSettings);
            startLoop();
          }).catch(() => startLoop());
        } else {
          stopLoop();
        }
        sendResponse({ active: activeTabOwned });
        return false;
      }
      if (message?.type === "joy-nav:get-status") {
        if (!isTopFrame) return false;
        sendResponse(status());
        return false;
      }
      if (message?.type === "joy-nav:set-enabled" && typeof message.enabled === "boolean") {
        if (!isTopFrame) return false;
        enabled = message.enabled;
        if (enabled) startLoop();
        else {
          pinned = false;
          pinnedDirection = null;
          lastActiveDirection = null;
          stopLoop();
        }
        sendResponse(status());
        return false;
      }
      return false;
    });
    chrome.storage.local.get("settings").then(({ settings: savedSettings }) => {
      settings = normalizeSettings(savedSettings);
      refreshNeeded = true;
      if (enabled) onVisibilityChange();
    }).catch(() => {
      settings = { ...DEFAULT_SETTINGS };
      if (enabled) onVisibilityChange();
    });
    chrome.storage.onChanged.addListener((changes, areaName) => {
      if (areaName !== "local" || !changes.settings?.newValue) return;
      applySettings(changes.settings.newValue);
    });
    function onVisibilityChange() {
      if (!isTopFrame) return;
      const sequence = ++focusChangeSequence;
      const pageIsFocused = document.visibilityState === "visible" && document.hasFocus?.() !== false;
      if (!pageIsFocused) {
        relinquishTabOwnership();
        return;
      }
      void chrome.runtime.sendMessage({ type: "joy-nav:sync-active-tab" }).then((response) => {
        if (sequence !== focusChangeSequence) return;
        activeTabOwned = response?.active === true;
        if (activeTabOwned && document.visibilityState === "visible" && document.hasFocus?.() !== false) {
          resetInputEdges();
          startLoop();
        } else {
          activeTabOwned = false;
          stopLoop();
        }
      }).catch(() => {
        if (sequence !== focusChangeSequence) return;
        activeTabOwned = false;
        stopLoop();
      });
    }
    function relinquishTabOwnership() {
      if (!isTopFrame) return;
      ++focusChangeSequence;
      activeTabOwned = false;
      stopLoop();
      void chrome.runtime.sendMessage({ type: "joy-nav:sync-active-tab" }).catch(() => void 0);
    }
    document.addEventListener("visibilitychange", onVisibilityChange);
    window.addEventListener("focus", onVisibilityChange);
    window.addEventListener("blur", relinquishTabOwnership);
    window.addEventListener("resize", () => {
      if (pointerInitialized) {
        virtualPointer.x = Math.min(Math.max(0, window.innerWidth - 1), Math.max(0, virtualPointer.x));
        virtualPointer.y = Math.min(Math.max(0, window.innerHeight - 1), Math.max(0, virtualPointer.y));
      }
      refreshNeeded = true;
      render();
    }, { passive: true });
    window.addEventListener("scroll", () => {
      refreshNeeded = true;
    }, { capture: true, passive: true });
    window.addEventListener("gamepadconnected", () => {
      refreshNeeded = true;
      startLoop();
    });
    window.addEventListener("gamepaddisconnected", () => {
      connectedGamepad = false;
      resetInputEdges();
      refreshNeeded = true;
    });
    observer = new MutationObserver((records) => {
      if (records.some((record) => !host?.contains(record.target))) refreshNeeded = true;
    });
    observer.observe(document.documentElement, {
      subtree: true,
      childList: true,
      attributes: true,
      attributeFilter: ["class", "style", "hidden", "disabled", "aria-disabled", "aria-hidden", "href", "tabindex"]
    });
    function isGamepadSample(value) {
      if (!value || typeof value !== "object") return false;
      const sample = value;
      return Array.isArray(sample.axes) && sample.axes.length >= 4 && sample.axes.every((axis) => typeof axis === "number") && Array.isArray(sample.buttons) && sample.buttons.length >= 16 && sample.buttons.every((button) => Boolean(button) && typeof button.pressed === "boolean" && typeof button.value === "number");
    }
    window.addEventListener("message", onFrameHandshake);
    if (isTopFrame) {
      registerFramePath();
    } else {
      let attempts = 0;
      const announceToParent = () => {
        if (framePath.length || attempts >= 20) return;
        attempts += 1;
        window.parent.postMessage({ type: "joy-nav:frame-hello", token: frameToken }, "*");
        window.setTimeout(announceToParent, 250);
      };
      announceToParent();
    }
    document.addEventListener("keydown", (event) => {
      if (!event.isTrusted || event.key !== "Escape" || isTopFrame || activeDirection !== null || pinned && pinnedDirection !== null) return;
      event.preventDefault();
      returnToParentFrame();
    }, true);
  }
  installContentScript();
})();
