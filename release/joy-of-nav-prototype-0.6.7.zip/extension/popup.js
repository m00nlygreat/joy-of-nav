"use strict";
(() => {
  // src/extension/popup.ts
  var toggleButton = document.querySelector("#toggleButton");
  var statusTitle = document.querySelector("#statusTitle");
  var statusDescription = document.querySelector("#statusDescription");
  var statusIcon = document.querySelector("#statusIcon");
  var pageLabel = document.querySelector("#pageLabel");
  var activeTabId;
  var currentStatus = null;
  var unavailableReason = null;
  function showUnavailable(message) {
    unavailableReason = message;
    currentStatus = null;
    statusTitle.textContent = "\uC774 \uD398\uC774\uC9C0\uC5D0\uC11C \uC0AC\uC6A9\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4";
    statusDescription.textContent = message;
    statusIcon.dataset.tone = "error";
    toggleButton.textContent = "\uC790\uB3D9 \uC2E4\uD589 \uBD88\uAC00";
    toggleButton.disabled = true;
  }
  function renderStatus(status) {
    currentStatus = status;
    toggleButton.disabled = false;
    if (!status) {
      statusTitle.textContent = "\uC774 \uD398\uC774\uC9C0\uC5D0 \uC790\uB3D9 \uC2E4\uD589\uB418\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4";
      statusDescription.textContent = "Chrome \uB0B4\uBD80 \uD398\uC774\uC9C0\uB294 \uC9C0\uC6D0\uB418\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4. file:// \uD398\uC774\uC9C0\uB294 \uD655\uC7A5 \uC138\uBD80 \uC815\uBCF4\uC5D0\uC11C \uD30C\uC77C URL \uC811\uADFC\uC744 \uD5C8\uC6A9\uD558\uC138\uC694.";
      statusIcon.dataset.tone = "error";
      toggleButton.textContent = "\uC790\uB3D9 \uC2E4\uD589 \uBD88\uAC00";
      toggleButton.disabled = true;
      return;
    }
    statusIcon.dataset.tone = status.enabled ? "active" : "ready";
    if (status.enabled) {
      statusTitle.textContent = status.gamepadConnected ? "\uD0D0\uC0C9\uC774 \uCF1C\uC838 \uC788\uC2B5\uB2C8\uB2E4" : "\uD0D0\uC0C9 \uB300\uAE30 \uC911";
      statusDescription.textContent = status.gamepadConnected ? "L\uC2A4\uD2F1\uC73C\uB85C \uBC29\uD5A5\uC744 \uC9C0\uC815\uD558\uACE0 X\uB85C \uD0D0\uC0C9 \uD6C4\uBCF4\uB97C \uC21C\uD68C\uD558\uC138\uC694." : status.supported ? "\uD398\uC774\uC9C0\uB97C \uB2E4\uC2DC \uD65C\uC131\uD654\uD55C \uB4A4 \uCEE8\uD2B8\uB864\uB7EC\uC758 \uBC84\uD2BC\uC774\uB098 \uC2A4\uD2F1\uC744 \uD55C \uBC88 \uC6C0\uC9C1\uC5EC \uBCF4\uC138\uC694." : "\uC774 \uBE0C\uB77C\uC6B0\uC800 \uD398\uC774\uC9C0\uC5D0\uC11C\uB294 Gamepad API\uB97C \uC0AC\uC6A9\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4.";
      toggleButton.textContent = "\uC774 \uD398\uC774\uC9C0\uC5D0\uC11C \uB044\uAE30";
    } else {
      statusTitle.textContent = "\uD604\uC7AC \uD398\uC774\uC9C0\uC5D0\uC11C \uBA48\uCDB0 \uC788\uC2B5\uB2C8\uB2E4";
      statusDescription.textContent = "\uC774 \uBB38\uC11C\uC5D0\uC11C\uB294 \uC77C\uC2DC \uC911\uC9C0\uB418\uC5C8\uC2B5\uB2C8\uB2E4. \uC0C8 \uBB38\uC11C\uB97C \uC5F4\uBA74 \uC790\uB3D9 \uC2E4\uD589\uB429\uB2C8\uB2E4.";
      toggleButton.textContent = "\uC774 \uD398\uC774\uC9C0\uC5D0\uC11C \uCF1C\uAE30";
    }
  }
  async function queryPageStatus(tabId) {
    try {
      return await chrome.tabs.sendMessage(tabId, { type: "joy-nav:get-status" });
    } catch {
      return null;
    }
  }
  async function initialize() {
    try {
      const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      if (!tab?.id) {
        showUnavailable("\uD65C\uC131 \uD0ED\uC744 \uCC3E\uC744 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4.");
        return;
      }
      activeTabId = tab.id;
      pageLabel.textContent = tab.title ? tab.title.slice(0, 30) : "\uD65C\uC131 \uD0ED";
      const pageStatus = await queryPageStatus(tab.id);
      if (pageStatus) renderStatus(pageStatus);
      else showUnavailable("\uC774 \uD398\uC774\uC9C0\uC5D0 \uC790\uB3D9 \uC2E4\uD589 \uC2A4\uD06C\uB9BD\uD2B8\uAC00 \uC8FC\uC785\uB418\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4. \uC0AC\uC774\uD2B8 \uC811\uADFC \uD5C8\uC6A9 \uC5EC\uBD80\uB97C \uD655\uC778\uD558\uC138\uC694.");
    } catch {
      showUnavailable("Chrome\uC5D0\uC11C \uC774 \uD0ED\uC744 \uC81C\uC5B4\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4.");
    }
  }
  toggleButton.addEventListener("click", async () => {
    if (activeTabId === void 0 || unavailableReason) return;
    toggleButton.disabled = true;
    toggleButton.textContent = "\uC0C1\uD0DC \uBCC0\uACBD \uC911\u2026";
    try {
      if (!currentStatus) throw new Error("Content script is not available on this page.");
      const nextEnabled = !currentStatus?.enabled;
      currentStatus = await chrome.tabs.sendMessage(activeTabId, {
        type: "joy-nav:set-enabled",
        enabled: nextEnabled
      });
      renderStatus(currentStatus);
    } catch {
      showUnavailable("\uC774 \uD398\uC774\uC9C0\uC5D0 \uC2A4\uD06C\uB9BD\uD2B8\uB97C \uB123\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4. chrome:// \uD398\uC774\uC9C0\uC640 Chrome \uC6F9 \uC2A4\uD1A0\uC5B4\uB294 \uC9C0\uC6D0\uD558\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4.");
    }
  });
  document.querySelector("#settingsButton").addEventListener("click", () => {
    void chrome.runtime.openOptionsPage();
  });
  void initialize();
})();
