"use strict";
(() => {
  // src/core/settings.ts
  var DEFAULT_SETTINGS = Object.freeze({
    deadzone: 0.2,
    spotlightShape: "cone",
    spotlightSize: 30,
    triggerThreshold: 0.5,
    neutralBehavior: "retain",
    candidateStart: "first",
    inclusionMode: "center",
    distanceMode: "center",
    tieBreak: "dom"
  });
  var LIMITS = {
    deadzone: { min: 0.05, max: 0.6 },
    triggerThreshold: { min: 0.1, max: 1 }
  };
  var SPOTLIGHT_SIZE_LIMITS = {
    cone: { min: 5, max: 180 },
    cylinder: { min: 5, max: 100 }
  };
  function numericValue(value, fallback, min, max) {
    const parsed = typeof value === "number" ? value : Number(value);
    if (!Number.isFinite(parsed)) return fallback;
    return Math.min(max, Math.max(min, parsed));
  }
  function normalizeSettings(value) {
    const source = value && typeof value === "object" ? value : {};
    const legacyConeAngle = value && typeof value === "object" ? value.coneAngle : void 0;
    const spotlightShape = source.spotlightShape === "cylinder" ? "cylinder" : "cone";
    const spotlightLimits = SPOTLIGHT_SIZE_LIMITS[spotlightShape];
    return {
      deadzone: numericValue(source.deadzone, DEFAULT_SETTINGS.deadzone, LIMITS.deadzone.min, LIMITS.deadzone.max),
      spotlightShape,
      // Migrate the earlier coneAngle preference to the shared spotlight-size setting.
      spotlightSize: numericValue(source.spotlightSize ?? legacyConeAngle, DEFAULT_SETTINGS.spotlightSize, spotlightLimits.min, spotlightLimits.max),
      triggerThreshold: numericValue(source.triggerThreshold, DEFAULT_SETTINGS.triggerThreshold, LIMITS.triggerThreshold.min, LIMITS.triggerThreshold.max),
      neutralBehavior: source.neutralBehavior === "clear" ? "clear" : "retain",
      candidateStart: source.candidateStart === "preserve" ? "preserve" : "first",
      inclusionMode: source.inclusionMode === "intersects" ? "intersects" : "center",
      distanceMode: source.distanceMode === "nearest" ? "nearest" : "center",
      tieBreak: source.tieBreak === "top-left" ? "top-left" : "dom"
    };
  }

  // src/extension/settings-page.ts
  var form = document.querySelector("#settingsForm");
  var saveStatus = document.querySelector("#saveStatus");
  var saveMessage = saveStatus.querySelector("span:last-child");
  var resetButton = document.querySelector("#resetButton");
  var spotlightSizeInput = form.querySelector("#spotlightSize");
  var spotlightSizeRange = form.querySelector("#spotlightSizeRange");
  var spotlightSizeLabel = form.querySelector("#spotlightSizeLabel");
  var spotlightSizeUnit = form.querySelector("#spotlightSizeUnit");
  var spotlightSizeHelper = form.querySelector("#spotlightSizeHelper");
  function paintStatus(message, tone = "idle") {
    saveMessage.textContent = message;
    saveStatus.dataset.tone = tone;
  }
  function updateSpotlightSizeControl(shape, clampValue = false) {
    const limits = SPOTLIGHT_SIZE_LIMITS[shape];
    const isCone = shape === "cone";
    const label = isCone ? "\uC6D0\uBFD4 \uC804\uCCB4 \uAC01\uB3C4" : "\uC6D0\uD1B5 \uAD75\uAE30";
    const unit = isCone ? "\uB3C4 (\xB0)" : "\uD654\uBA74 \uC9E7\uC740 \uBCC0 (%)";
    spotlightSizeLabel.textContent = label;
    spotlightSizeUnit.textContent = unit;
    spotlightSizeHelper.textContent = isCone ? "\uC2A4\uD2F1 \uBC29\uD5A5\uC758 \uC591\uCABD \uACBD\uACC4 \uC0AC\uC774 \uAC01\uB3C4\uC785\uB2C8\uB2E4." : "\uD654\uBA74\uC758 \uC9E7\uC740 \uBCC0\uC744 \uAE30\uC900\uC73C\uB85C \uC2A4\uD2F1 \uBC29\uD5A5\uC744 \uB530\uB77C \uBED7\uB294 spotlight\uC758 \uAD75\uAE30\uC785\uB2C8\uB2E4.";
    spotlightSizeInput.min = String(limits.min);
    spotlightSizeInput.max = String(limits.max);
    spotlightSizeRange.min = String(limits.min);
    spotlightSizeRange.max = String(limits.max);
    spotlightSizeRange.setAttribute("aria-label", `${label} \uC2AC\uB77C\uC774\uB354`);
    if (clampValue && spotlightSizeInput.value.trim()) {
      const current = Number(spotlightSizeInput.value);
      if (Number.isFinite(current)) {
        const next = Math.min(limits.max, Math.max(limits.min, current));
        spotlightSizeInput.value = String(next);
        spotlightSizeRange.value = String(next);
      }
    }
  }
  function render(settings) {
    for (const input of form.querySelectorAll("input[data-setting]")) {
      const key = input.dataset.setting;
      input.value = String(settings[key]);
      input.setAttribute("aria-invalid", "false");
      const range = form.querySelector(`input[data-range-for="${key}"]`);
      if (range) range.value = String(settings[key]);
    }
    for (const select of form.querySelectorAll("select[data-setting]")) {
      const key = select.dataset.setting;
      select.value = String(settings[key]);
    }
    updateSpotlightSizeControl(settings.spotlightShape);
  }
  function readForm() {
    const numericInputs = [...form.querySelectorAll("input[data-setting]")];
    let valid = true;
    for (const input of numericInputs) {
      const passes = input.value.trim() !== "" && input.validity.valid;
      input.setAttribute("aria-invalid", String(!passes));
      valid = valid && passes;
    }
    if (!valid) return null;
    const values = {};
    for (const input of numericInputs) values[input.dataset.setting] = Number(input.value);
    for (const select of form.querySelectorAll("select[data-setting]")) values[select.dataset.setting] = select.value;
    return normalizeSettings(values);
  }
  async function save() {
    const settings = readForm();
    if (!settings) {
      paintStatus("\uD5C8\uC6A9 \uBC94\uC704 \uC548\uC758 \uAC12\uC744 \uC785\uB825\uD558\uC138\uC694.", "error");
      return;
    }
    try {
      await chrome.storage.local.set({ settings });
      paintStatus("\uC800\uC7A5\uB428 \xB7 \uCF1C\uC838 \uC788\uB294 \uD398\uC774\uC9C0\uC5D0 \uBC14\uB85C \uBC18\uC601", "saved");
    } catch {
      paintStatus("\uC124\uC815\uC744 \uC800\uC7A5\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4. \uB2E4\uC2DC \uC2DC\uB3C4\uD558\uC138\uC694.", "error");
    }
  }
  function syncRange(input) {
    const setting = input.dataset.setting ?? input.dataset.rangeFor;
    if (!setting) return;
    const range = form.querySelector(`input[data-range-for="${setting}"]`);
    if (!range) return;
    if (input.type === "range") {
      const number = form.querySelector(`input[data-setting="${setting}"]`);
      if (number) {
        number.value = input.value;
        number.setAttribute("aria-invalid", "false");
      }
    } else if (input.value.trim() && input.validity.valid) {
      range.value = input.value;
      input.setAttribute("aria-invalid", "false");
    }
  }
  for (const input of form.querySelectorAll("input[data-setting], input[data-range-for]")) {
    input.addEventListener("input", () => {
      syncRange(input);
      paintStatus("\uBCC0\uACBD \uC0AC\uD56D\uC744 \uC800\uC7A5\uD558\uC138\uC694.");
    });
    input.addEventListener("change", () => void save());
  }
  for (const select of form.querySelectorAll("select[data-setting]")) {
    select.addEventListener("change", () => {
      if (select.id === "spotlightShape") {
        updateSpotlightSizeControl(select.value, true);
      }
      void save();
    });
  }
  resetButton.addEventListener("click", async () => {
    render(DEFAULT_SETTINGS);
    await save();
  });
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === "local" && changes.settings?.newValue) {
      render(normalizeSettings(changes.settings.newValue));
    }
  });
  for (const input of form.querySelectorAll("input[data-setting]")) {
    input.setAttribute("aria-describedby", `${input.id}Helper`);
  }
  void chrome.storage.local.get("settings").then(({ settings }) => {
    render(normalizeSettings(settings));
    paintStatus("\uC124\uC815\uC774 \uC774 \uAE30\uAE30\uC5D0 \uC800\uC7A5\uB429\uB2C8\uB2E4.");
  }).catch(() => {
    render(DEFAULT_SETTINGS);
    paintStatus("\uAE30\uBCF8 \uC124\uC815\uC744 \uD45C\uC2DC \uC911\uC785\uB2C8\uB2E4. \uC800\uC7A5 \uC0C1\uD0DC\uB97C \uD655\uC778\uD558\uC138\uC694.", "error");
  });
})();
