// src/core/navigation.ts
function readDirection(x, y, deadzone) {
  const magnitude = Math.hypot(x, y);
  if (!Number.isFinite(magnitude) || magnitude <= deadzone) return null;
  return { x, y, magnitude };
}
function pointInCone(point, origin, direction, fullAngle) {
  const dx = point.x - origin.x;
  const dy = point.y - origin.y;
  const pointLength = Math.hypot(dx, dy);
  const directionLength = Math.hypot(direction.x, direction.y);
  if (pointLength === 0 || directionLength === 0) return true;
  const cosine = Math.min(1, Math.max(-1, (dx * direction.x + dy * direction.y) / (pointLength * directionLength)));
  const angle = Math.acos(cosine) * 180 / Math.PI;
  return angle <= fullAngle / 2 + 1e-8;
}
function corners(rect) {
  return [
    { x: rect.left, y: rect.top },
    { x: rect.right, y: rect.top },
    { x: rect.right, y: rect.bottom },
    { x: rect.left, y: rect.bottom }
  ];
}
function segmentIntersectsRect(start, end, rect) {
  const dx = end.x - start.x;
  const dy = end.y - start.y;
  let t0 = 0;
  let t1 = 1;
  const tests = [
    [-dx, start.x - rect.left],
    [dx, rect.right - start.x],
    [-dy, start.y - rect.top],
    [dy, rect.bottom - start.y]
  ];
  for (const [p, q] of tests) {
    if (p === 0) {
      if (q < 0) return false;
      continue;
    }
    const t = q / p;
    if (p < 0) t0 = Math.max(t0, t);
    else t1 = Math.min(t1, t);
    if (t0 > t1) return false;
  }
  return true;
}
function rayIntersectsRect(origin, direction, rect) {
  const length = Math.max(...corners(rect).map((point) => Math.hypot(point.x - origin.x, point.y - origin.y))) + 1;
  const magnitude = Math.hypot(direction.x, direction.y);
  if (!magnitude) return false;
  const end = { x: origin.x + direction.x / magnitude * length, y: origin.y + direction.y / magnitude * length };
  return segmentIntersectsRect(origin, end, rect);
}
function rectIntersectsCone(rect, origin, direction, fullAngle) {
  if (corners(rect).some((corner) => pointInCone(corner, origin, direction, fullAngle))) return true;
  const nearest = {
    x: Math.min(rect.right, Math.max(rect.left, origin.x)),
    y: Math.min(rect.bottom, Math.max(rect.top, origin.y))
  };
  if (pointInCone(nearest, origin, direction, fullAngle)) return true;
  const axisAngle = Math.atan2(direction.y, direction.x);
  const halfAngle = fullAngle * Math.PI / 360;
  const start = { x: Math.cos(axisAngle - halfAngle), y: Math.sin(axisAngle - halfAngle) };
  const end = { x: Math.cos(axisAngle + halfAngle), y: Math.sin(axisAngle + halfAngle) };
  return rayIntersectsRect(origin, direction, rect) || rayIntersectsRect(origin, start, rect) || rayIntersectsRect(origin, end, rect);
}
function cylinderCoordinates(point, origin, unitDirection) {
  const dx = point.x - origin.x;
  const dy = point.y - origin.y;
  return {
    x: dx * unitDirection.x + dy * unitDirection.y,
    y: dx * -unitDirection.y + dy * unitDirection.x
  };
}
function pointInCylinder(point, origin, direction, thickness) {
  const directionLength = Math.hypot(direction.x, direction.y);
  if (!directionLength) return false;
  const coordinates = cylinderCoordinates(point, origin, { x: direction.x / directionLength, y: direction.y / directionLength });
  const halfThickness = Math.max(0, thickness) / 2;
  return coordinates.x >= -1e-8 && Math.abs(coordinates.y) <= halfThickness + 1e-8 || Math.hypot(coordinates.x, coordinates.y) <= halfThickness + 1e-8;
}
function clipPolygon(polygon, signedDistance) {
  if (!polygon.length) return [];
  const clipped = [];
  let previous = polygon[polygon.length - 1];
  let previousDistance = signedDistance(previous);
  let previousInside = previousDistance >= -1e-8;
  for (const current of polygon) {
    const currentDistance = signedDistance(current);
    const currentInside = currentDistance >= -1e-8;
    if (currentInside !== previousInside) {
      const denominator = previousDistance - currentDistance;
      const amount = Math.abs(denominator) < 1e-12 ? 0 : previousDistance / denominator;
      clipped.push({
        x: previous.x + (current.x - previous.x) * amount,
        y: previous.y + (current.y - previous.y) * amount
      });
    }
    if (currentInside) clipped.push(current);
    previous = current;
    previousDistance = currentDistance;
    previousInside = currentInside;
  }
  return clipped;
}
function rectIntersectsCylinder(rect, origin, direction, thickness) {
  const directionLength = Math.hypot(direction.x, direction.y);
  if (!directionLength) return false;
  const unitDirection = { x: direction.x / directionLength, y: direction.y / directionLength };
  const halfThickness = Math.max(0, thickness) / 2;
  const nearest = {
    x: Math.min(rect.right, Math.max(rect.left, origin.x)),
    y: Math.min(rect.bottom, Math.max(rect.top, origin.y))
  };
  if (Math.hypot(nearest.x - origin.x, nearest.y - origin.y) <= halfThickness + 1e-8) return true;
  const along = (point) => cylinderCoordinates(point, origin, unitDirection).x;
  const across = (point) => cylinderCoordinates(point, origin, unitDirection).y;
  let polygon = corners(rect);
  polygon = clipPolygon(polygon, along);
  polygon = clipPolygon(polygon, (point) => halfThickness - across(point));
  polygon = clipPolygon(polygon, (point) => halfThickness + across(point));
  return polygon.length > 0;
}
function candidateInCone(candidate, origin, direction, fullAngle, mode) {
  if (mode === "intersects") return rectIntersectsCone(candidate.rect, origin, direction, fullAngle);
  return pointInCone({
    x: (candidate.rect.left + candidate.rect.right) / 2,
    y: (candidate.rect.top + candidate.rect.bottom) / 2
  }, origin, direction, fullAngle);
}
function candidateInSpotlight(candidate, origin, direction, shape, size, viewportShortSide, mode) {
  if (shape === "cone") return candidateInCone(candidate, origin, direction, size, mode);
  const thickness = Math.max(0, viewportShortSide) * size / 100;
  if (mode === "intersects") return rectIntersectsCylinder(candidate.rect, origin, direction, thickness);
  return pointInCylinder({
    x: (candidate.rect.left + candidate.rect.right) / 2,
    y: (candidate.rect.top + candidate.rect.bottom) / 2
  }, origin, direction, thickness);
}
function candidateDistance(candidate, origin, mode) {
  const point = mode === "center" ? { x: (candidate.rect.left + candidate.rect.right) / 2, y: (candidate.rect.top + candidate.rect.bottom) / 2 } : {
    x: Math.min(candidate.rect.right, Math.max(candidate.rect.left, origin.x)),
    y: Math.min(candidate.rect.bottom, Math.max(candidate.rect.top, origin.y))
  };
  return Math.hypot(point.x - origin.x, point.y - origin.y);
}
function rankCandidates(candidates, origin, direction, fullAngle, inclusionMode, distanceMode, tieBreak) {
  return candidates.filter((candidate) => candidateInCone(candidate, origin, direction, fullAngle, inclusionMode)).slice().sort((left, right) => {
    const distanceDelta = candidateDistance(left, origin, distanceMode) - candidateDistance(right, origin, distanceMode);
    if (Math.abs(distanceDelta) > 0.01) return distanceDelta;
    if (tieBreak === "top-left") {
      const topDelta = left.rect.top - right.rect.top;
      if (Math.abs(topDelta) > 0.01) return topDelta;
      const leftDelta = left.rect.left - right.rect.left;
      if (Math.abs(leftDelta) > 0.01) return leftDelta;
    }
    return left.documentOrder - right.documentOrder;
  });
}
function rankSpotlightCandidates(candidates, origin, direction, shape, size, viewportShortSide, inclusionMode, distanceMode, tieBreak) {
  return candidates.filter((candidate) => candidateInSpotlight(candidate, origin, direction, shape, size, viewportShortSide, inclusionMode)).slice().sort((left, right) => {
    const distanceDelta = candidateDistance(left, origin, distanceMode) - candidateDistance(right, origin, distanceMode);
    if (Math.abs(distanceDelta) > 0.01) return distanceDelta;
    if (tieBreak === "top-left") {
      const topDelta = left.rect.top - right.rect.top;
      if (Math.abs(topDelta) > 0.01) return topDelta;
      const leftDelta = left.rect.left - right.rect.left;
      if (Math.abs(leftDelta) > 0.01) return leftDelta;
    }
    return left.documentOrder - right.documentOrder;
  });
}
function nextCycleIndex(currentIndex, length) {
  if (length <= 0) return -1;
  return currentIndex < 0 || currentIndex >= length ? 0 : (currentIndex + 1) % length;
}
function resolveSelectionIndex(previouslySelected, candidates, preserve) {
  if (preserve && previouslySelected !== void 0) {
    return candidates.indexOf(previouslySelected);
  }
  return -1;
}
function hasRisen(currentlyDown, wasDown) {
  return currentlyDown && !wasDown;
}

// src/core/settings.ts
var DEFAULT_SETTINGS = Object.freeze({
  deadzone: 0.2,
  spotlightShape: "cone",
  spotlightSize: 30,
  triggerThreshold: 0.5,
  neutralBehavior: "retain",
  candidateStart: "first",
  inclusionMode: "center",
  distanceMode: "center",
  tieBreak: "dom"
});
var LIMITS = {
  deadzone: { min: 0.05, max: 0.6 },
  triggerThreshold: { min: 0.1, max: 1 }
};
var SPOTLIGHT_SIZE_LIMITS = {
  cone: { min: 5, max: 180 },
  cylinder: { min: 5, max: 100 }
};
function numericValue(value, fallback, min, max) {
  const parsed = typeof value === "number" ? value : Number(value);
  if (!Number.isFinite(parsed)) return fallback;
  return Math.min(max, Math.max(min, parsed));
}
function normalizeSettings(value) {
  const source = value && typeof value === "object" ? value : {};
  const legacyConeAngle = value && typeof value === "object" ? value.coneAngle : void 0;
  const spotlightShape = source.spotlightShape === "cylinder" ? "cylinder" : "cone";
  const spotlightLimits = SPOTLIGHT_SIZE_LIMITS[spotlightShape];
  return {
    deadzone: numericValue(source.deadzone, DEFAULT_SETTINGS.deadzone, LIMITS.deadzone.min, LIMITS.deadzone.max),
    spotlightShape,
    // Migrate the earlier coneAngle preference to the shared spotlight-size setting.
    spotlightSize: numericValue(source.spotlightSize ?? legacyConeAngle, DEFAULT_SETTINGS.spotlightSize, spotlightLimits.min, spotlightLimits.max),
    triggerThreshold: numericValue(source.triggerThreshold, DEFAULT_SETTINGS.triggerThreshold, LIMITS.triggerThreshold.min, LIMITS.triggerThreshold.max),
    neutralBehavior: source.neutralBehavior === "clear" ? "clear" : "retain",
    candidateStart: source.candidateStart === "preserve" ? "preserve" : "first",
    inclusionMode: source.inclusionMode === "intersects" ? "intersects" : "center",
    distanceMode: source.distanceMode === "nearest" ? "nearest" : "center",
    tieBreak: source.tieBreak === "top-left" ? "top-left" : "dom"
  };
}
var SETTING_LIMITS = LIMITS;
export {
  DEFAULT_SETTINGS,
  SETTING_LIMITS,
  SPOTLIGHT_SIZE_LIMITS,
  candidateInCone,
  candidateInSpotlight,
  hasRisen,
  nextCycleIndex,
  normalizeSettings,
  pointInCone,
  pointInCylinder,
  rankCandidates,
  rankSpotlightCandidates,
  readDirection,
  resolveSelectionIndex
};
