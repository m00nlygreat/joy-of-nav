// src/core/navigation.ts
function readDirection(x, y, deadzone) {
  const magnitude = Math.hypot(x, y);
  if (!Number.isFinite(magnitude) || magnitude <= deadzone) return null;
  return { x, y, magnitude };
}
function pointInCone(point, origin, direction, fullAngle) {
  const dx = point.x - origin.x;
  const dy = point.y - origin.y;
  const pointLength = Math.hypot(dx, dy);
  const directionLength = Math.hypot(direction.x, direction.y);
  if (pointLength === 0 || directionLength === 0) return true;
  const cosine = Math.min(1, Math.max(-1, (dx * direction.x + dy * direction.y) / (pointLength * directionLength)));
  const angle = Math.acos(cosine) * 180 / Math.PI;
  return angle <= fullAngle / 2 + 1e-8;
}
function corners(rect) {
  return [
    { x: rect.left, y: rect.top },
    { x: rect.right, y: rect.top },
    { x: rect.right, y: rect.bottom },
    { x: rect.left, y: rect.bottom }
  ];
}
function segmentIntersectsRect(start, end, rect) {
  const dx = end.x - start.x;
  const dy = end.y - start.y;
  let t0 = 0;
  let t1 = 1;
  const tests = [
    [-dx, start.x - rect.left],
    [dx, rect.right - start.x],
    [-dy, start.y - rect.top],
    [dy, rect.bottom - start.y]
  ];
  for (const [p, q] of tests) {
    if (p === 0) {
      if (q < 0) return false;
      continue;
    }
    const t = q / p;
    if (p < 0) t0 = Math.max(t0, t);
    else t1 = Math.min(t1, t);
    if (t0 > t1) return false;
  }
  return true;
}
function rayIntersectsRect(origin, direction, rect) {
  const length = Math.max(...corners(rect).map((point) => Math.hypot(point.x - origin.x, point.y - origin.y))) + 1;
  const magnitude = Math.hypot(direction.x, direction.y);
  if (!magnitude) return false;
  const end = { x: origin.x + direction.x / magnitude * length, y: origin.y + direction.y / magnitude * length };
  return segmentIntersectsRect(origin, end, rect);
}
function rectIntersectsCone(rect, origin, direction, fullAngle) {
  if (corners(rect).some((corner) => pointInCone(corner, origin, direction, fullAngle))) return true;
  const nearest = {
    x: Math.min(rect.right, Math.max(rect.left, origin.x)),
    y: Math.min(rect.bottom, Math.max(rect.top, origin.y))
  };
  if (pointInCone(nearest, origin, direction, fullAngle)) return true;
  const axisAngle = Math.atan2(direction.y, direction.x);
  const halfAngle = fullAngle * Math.PI / 360;
  const start = { x: Math.cos(axisAngle - halfAngle), y: Math.sin(axisAngle - halfAngle) };
  const end = { x: Math.cos(axisAngle + halfAngle), y: Math.sin(axisAngle + halfAngle) };
  return rayIntersectsRect(origin, direction, rect) || rayIntersectsRect(origin, start, rect) || rayIntersectsRect(origin, end, rect);
}
function clipPolygon(polygon, signedDistance) {
  if (!polygon.length) return [];
  const clipped = [];
  let previous = polygon[polygon.length - 1];
  let previousDistance = signedDistance(previous);
  let previousInside = previousDistance >= -1e-8;
  for (const current of polygon) {
    const currentDistance = signedDistance(current);
    const currentInside = currentDistance >= -1e-8;
    if (currentInside !== previousInside) {
      const denominator = previousDistance - currentDistance;
      const amount = Math.abs(denominator) < 1e-12 ? 0 : previousDistance / denominator;
      clipped.push({
        x: previous.x + (current.x - previous.x) * amount,
        y: previous.y + (current.y - previous.y) * amount
      });
    }
    if (currentInside) clipped.push(current);
    previous = current;
    previousDistance = currentDistance;
    previousInside = currentInside;
  }
  return clipped;
}
function candidateInCone(candidate, origin, direction, fullAngle, mode) {
  if (mode === "intersects") return rectIntersectsCone(candidate.rect, origin, direction, fullAngle);
  return pointInCone({
    x: (candidate.rect.left + candidate.rect.right) / 2,
    y: (candidate.rect.top + candidate.rect.bottom) / 2
  }, origin, direction, fullAngle);
}
var SPOTLIGHT_CAP_SEGMENTS = 24;
function createSpotlightPolygon(origin, direction, arrivalWidth, startWidth, viewportWidth, viewportHeight) {
  const directionLength = Math.hypot(direction.x, direction.y);
  if (!directionLength || arrivalWidth <= 0 && startWidth <= 0) return [];
  const unitDirection = { x: direction.x / directionLength, y: direction.y / directionLength };
  const perpendicular = { x: -unitDirection.y, y: unitDirection.x };
  const viewportCorners = corners({ left: 0, top: 0, right: viewportWidth, bottom: viewportHeight });
  const endDistance = Math.max(...viewportCorners.map((point) => (point.x - origin.x) * unitDirection.x + (point.y - origin.y) * unitDirection.y));
  if (endDistance <= 0) return [];
  const startRadius = Math.max(0, startWidth) / 2;
  const arrivalRadius = Math.max(0, arrivalWidth) / 2;
  const end = {
    x: origin.x + unitDirection.x * endDistance,
    y: origin.y + unitDirection.y * endDistance
  };
  const pointAt = (along, across) => ({
    x: origin.x + unitDirection.x * along + perpendicular.x * across,
    y: origin.y + unitDirection.y * along + perpendicular.y * across
  });
  const polygon = [
    pointAt(0, startRadius),
    { x: end.x + perpendicular.x * arrivalRadius, y: end.y + perpendicular.y * arrivalRadius },
    { x: end.x - perpendicular.x * arrivalRadius, y: end.y - perpendicular.y * arrivalRadius }
  ];
  if (startRadius > 0) {
    polygon.push(pointAt(0, -startRadius));
    for (let index = 1; index < SPOTLIGHT_CAP_SEGMENTS; index += 1) {
      const angle = -Math.PI / 2 - Math.PI * index / SPOTLIGHT_CAP_SEGMENTS;
      polygon.push(pointAt(Math.cos(angle) * startRadius, Math.sin(angle) * startRadius));
    }
  }
  return polygon;
}
function pointOnSegment(point, start, end) {
  const dx = end.x - start.x;
  const dy = end.y - start.y;
  const lengthSquared = dx * dx + dy * dy;
  if (lengthSquared < 1e-14) return Math.hypot(point.x - start.x, point.y - start.y) <= 1e-7;
  const amount = Math.min(1, Math.max(0, ((point.x - start.x) * dx + (point.y - start.y) * dy) / lengthSquared));
  return Math.hypot(point.x - (start.x + amount * dx), point.y - (start.y + amount * dy)) <= 1e-7;
}
function polygonContainsPoint(polygon, point) {
  let inside = false;
  for (let index = 0, previousIndex = polygon.length - 1; index < polygon.length; previousIndex = index, index += 1) {
    const current = polygon[index];
    const previous = polygon[previousIndex];
    if (pointOnSegment(point, previous, current)) return true;
    if (current.y > point.y !== previous.y > point.y && point.x < (previous.x - current.x) * (point.y - current.y) / (previous.y - current.y) + current.x) {
      inside = !inside;
    }
  }
  return inside;
}
function polygonIntersectsRect(polygon, rect) {
  let clipped = polygon;
  clipped = clipPolygon(clipped, (point) => point.x - rect.left);
  clipped = clipPolygon(clipped, (point) => rect.right - point.x);
  clipped = clipPolygon(clipped, (point) => point.y - rect.top);
  clipped = clipPolygon(clipped, (point) => rect.bottom - point.y);
  return clipped.length > 0;
}
function candidateInSpotlightPolygon(candidate, polygon, mode) {
  if (mode === "intersects") return polygonIntersectsRect(polygon, candidate.rect);
  return polygonContainsPoint(polygon, {
    x: (candidate.rect.left + candidate.rect.right) / 2,
    y: (candidate.rect.top + candidate.rect.bottom) / 2
  });
}
function candidateInSpotlight(candidate, origin, direction, arrivalWidth, startWidth, viewportWidth, viewportHeight, mode) {
  const polygon = createSpotlightPolygon(origin, direction, arrivalWidth, startWidth, viewportWidth, viewportHeight);
  return polygon.length > 0 && candidateInSpotlightPolygon(candidate, polygon, mode);
}
function candidateDistance(candidate, origin, mode) {
  const point = mode === "center" ? { x: (candidate.rect.left + candidate.rect.right) / 2, y: (candidate.rect.top + candidate.rect.bottom) / 2 } : {
    x: Math.min(candidate.rect.right, Math.max(candidate.rect.left, origin.x)),
    y: Math.min(candidate.rect.bottom, Math.max(candidate.rect.top, origin.y))
  };
  return Math.hypot(point.x - origin.x, point.y - origin.y);
}
function rankCandidates(candidates, origin, direction, fullAngle, inclusionMode, distanceMode, tieBreak) {
  return candidates.filter((candidate) => candidateInCone(candidate, origin, direction, fullAngle, inclusionMode)).slice().sort((left, right) => {
    const distanceDelta = candidateDistance(left, origin, distanceMode) - candidateDistance(right, origin, distanceMode);
    if (Math.abs(distanceDelta) > 0.01) return distanceDelta;
    if (tieBreak === "top-left") {
      const topDelta = left.rect.top - right.rect.top;
      if (Math.abs(topDelta) > 0.01) return topDelta;
      const leftDelta = left.rect.left - right.rect.left;
      if (Math.abs(leftDelta) > 0.01) return leftDelta;
    }
    return left.documentOrder - right.documentOrder;
  });
}
function rankSpotlightCandidates(candidates, origin, direction, arrivalWidth, startWidth, viewportWidth, viewportHeight, inclusionMode, distanceMode, tieBreak) {
  const polygon = createSpotlightPolygon(origin, direction, arrivalWidth, startWidth, viewportWidth, viewportHeight);
  if (polygon.length === 0) return [];
  return candidates.filter((candidate) => candidateInSpotlightPolygon(candidate, polygon, inclusionMode)).slice().sort((left, right) => {
    const distanceDelta = candidateDistance(left, origin, distanceMode) - candidateDistance(right, origin, distanceMode);
    if (Math.abs(distanceDelta) > 0.01) return distanceDelta;
    if (tieBreak === "top-left") {
      const topDelta = left.rect.top - right.rect.top;
      if (Math.abs(topDelta) > 0.01) return topDelta;
      const leftDelta = left.rect.left - right.rect.left;
      if (Math.abs(leftDelta) > 0.01) return leftDelta;
    }
    return left.documentOrder - right.documentOrder;
  });
}
function nextCycleIndex(currentIndex, length) {
  if (length <= 0) return -1;
  return currentIndex < 0 || currentIndex >= length ? 0 : (currentIndex + 1) % length;
}
function resolveSelectionIndex(previouslySelected, candidates, preserve) {
  if (preserve && previouslySelected !== void 0) {
    return candidates.indexOf(previouslySelected);
  }
  return -1;
}
function hasRisen(currentlyDown, wasDown) {
  return currentlyDown && !wasDown;
}

// src/core/settings.ts
var DEFAULT_SCROLL_SPEED_CURVE = [0, 0.1, 0.3, 0.62, 1];
var DEFAULT_POINTER_SPEED_CURVE = [0, 0.08, 0.28, 0.62, 1];
var PREVIOUS_SCROLL_SPEED_CURVE = [0, 0.58, 0.82, 0.95, 1];
var PREVIOUS_POINTER_SPEED_CURVE = [0, 0.5, 0.76, 0.92, 1];
var DEFAULT_SETTINGS = Object.freeze({
  deadzone: 0.2,
  spotlightArrivalSize: 30,
  spotlightStartSize: 0,
  triggerThreshold: 0.5,
  neutralBehavior: "retain",
  candidateStart: "first",
  inclusionMode: "center",
  distanceMode: "center",
  tieBreak: "dom",
  scrollSpeedCurve: DEFAULT_SCROLL_SPEED_CURVE,
  pointerSpeedCurve: DEFAULT_POINTER_SPEED_CURVE,
  scrollMaxSpeed: 2200,
  pointerMaxSpeed: 1800,
  rightStickCandidateStepDegrees: 70
});
var LIMITS = {
  deadzone: { min: 0.05, max: 0.6 },
  triggerThreshold: { min: 0.1, max: 1 },
  scrollMaxSpeed: { min: 100, max: 4e3 },
  pointerMaxSpeed: { min: 100, max: 3e3 },
  rightStickCandidateStepDegrees: { min: 15, max: 180 },
  spotlightArrivalSize: { min: 0, max: 100 },
  spotlightStartSize: { min: 0, max: 100 }
};
function numericValue(value, fallback, min, max) {
  const parsed = typeof value === "number" ? value : Number(value);
  if (!Number.isFinite(parsed)) return fallback;
  return Math.min(max, Math.max(min, parsed));
}
function speedCurveBezierSegments(curve) {
  const spacing = 1 / 4;
  const slopes = curve.slice(0, 4).map((value, index) => (curve[index + 1] - value) / spacing);
  const tangents = [slopes[0]];
  for (let index = 1; index < 4; index += 1) {
    const previous = slopes[index - 1];
    const next = slopes[index];
    tangents.push(previous <= 0 || next <= 0 ? 0 : 2 * previous * next / (previous + next));
  }
  tangents.push(slopes[3]);
  return Array.from({ length: 4 }, (_, index) => {
    const startX = index * spacing;
    const endX = startX + spacing;
    return {
      startX,
      startY: curve[index],
      control1X: startX + spacing / 3,
      control1Y: curve[index] + tangents[index] * spacing / 3,
      control2X: endX - spacing / 3,
      control2Y: curve[index + 1] - tangents[index + 1] * spacing / 3,
      endX,
      endY: curve[index + 1]
    };
  });
}
function normalizeSpeedCurve(value, fallback) {
  if (!Array.isArray(value) || value.length < 5) return [...fallback];
  const previousDefaults = fallback === DEFAULT_SCROLL_SPEED_CURVE ? PREVIOUS_SCROLL_SPEED_CURVE : PREVIOUS_POINTER_SPEED_CURVE;
  if (previousDefaults.every((point, index) => Number(value[index]) === point)) return [...fallback];
  const curve = [
    0,
    numericValue(value[1], fallback[1], 0, 1),
    numericValue(value[2], fallback[2], 0, 1),
    numericValue(value[3], fallback[3], 0, 1),
    1
  ];
  for (let index = 2; index <= 3; index += 1) {
    curve[index] = Math.max(curve[index - 1], curve[index]);
  }
  return curve;
}
function mapSpeedCurve(value, curve) {
  const input = Math.min(1, Math.max(0, Number.isFinite(value) ? value : 0));
  const segment = Math.min(3, Math.floor(input * 4));
  const amount = input * 4 - segment;
  const { startY, control1Y, control2Y, endY } = speedCurveBezierSegments(curve)[segment];
  const inverse = 1 - amount;
  return inverse ** 3 * startY + 3 * inverse ** 2 * amount * control1Y + 3 * inverse * amount ** 2 * control2Y + amount ** 3 * endY;
}
function normalizeSettings(value) {
  const record = value && typeof value === "object" ? value : {};
  const source = record;
  const legacySize = record.spotlightSize ?? record.coneAngle;
  const hasNewSpotlightSizes = source.spotlightArrivalSize !== void 0 || source.spotlightStartSize !== void 0;
  const migrateLegacySpotlightSize = !hasNewSpotlightSizes && legacySize !== void 0;
  const legacySizePercent = migrateLegacySpotlightSize ? numericValue(legacySize, DEFAULT_SETTINGS.spotlightArrivalSize, LIMITS.spotlightArrivalSize.min, LIMITS.spotlightArrivalSize.max) : void 0;
  const legacyWasCylinder = record.spotlightShape === "cylinder";
  return {
    deadzone: numericValue(source.deadzone, DEFAULT_SETTINGS.deadzone, LIMITS.deadzone.min, LIMITS.deadzone.max),
    spotlightArrivalSize: numericValue(source.spotlightArrivalSize, legacySizePercent ?? DEFAULT_SETTINGS.spotlightArrivalSize, LIMITS.spotlightArrivalSize.min, LIMITS.spotlightArrivalSize.max),
    spotlightStartSize: numericValue(source.spotlightStartSize, legacyWasCylinder ? legacySizePercent ?? DEFAULT_SETTINGS.spotlightStartSize : DEFAULT_SETTINGS.spotlightStartSize, LIMITS.spotlightStartSize.min, LIMITS.spotlightStartSize.max),
    triggerThreshold: numericValue(source.triggerThreshold, DEFAULT_SETTINGS.triggerThreshold, LIMITS.triggerThreshold.min, LIMITS.triggerThreshold.max),
    neutralBehavior: source.neutralBehavior === "clear" ? "clear" : "retain",
    candidateStart: source.candidateStart === "preserve" ? "preserve" : "first",
    inclusionMode: source.inclusionMode === "intersects" ? "intersects" : "center",
    distanceMode: source.distanceMode === "nearest" ? "nearest" : "center",
    tieBreak: source.tieBreak === "top-left" ? "top-left" : "dom",
    scrollSpeedCurve: normalizeSpeedCurve(source.scrollSpeedCurve, DEFAULT_SCROLL_SPEED_CURVE),
    pointerSpeedCurve: normalizeSpeedCurve(source.pointerSpeedCurve, DEFAULT_POINTER_SPEED_CURVE),
    scrollMaxSpeed: numericValue(source.scrollMaxSpeed, DEFAULT_SETTINGS.scrollMaxSpeed, LIMITS.scrollMaxSpeed.min, LIMITS.scrollMaxSpeed.max),
    pointerMaxSpeed: numericValue(source.pointerMaxSpeed, DEFAULT_SETTINGS.pointerMaxSpeed, LIMITS.pointerMaxSpeed.min, LIMITS.pointerMaxSpeed.max),
    rightStickCandidateStepDegrees: numericValue(source.rightStickCandidateStepDegrees, DEFAULT_SETTINGS.rightStickCandidateStepDegrees, LIMITS.rightStickCandidateStepDegrees.min, LIMITS.rightStickCandidateStepDegrees.max)
  };
}
var SETTING_LIMITS = LIMITS;
export {
  DEFAULT_SETTINGS,
  SETTING_LIMITS,
  candidateInCone,
  candidateInSpotlight,
  createSpotlightPolygon,
  hasRisen,
  mapSpeedCurve,
  nextCycleIndex,
  normalizeSettings,
  pointInCone,
  rankCandidates,
  rankSpotlightCandidates,
  readDirection,
  resolveSelectionIndex,
  speedCurveBezierSegments
};
