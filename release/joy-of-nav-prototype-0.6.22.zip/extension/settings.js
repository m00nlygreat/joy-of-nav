"use strict";
(() => {
  // src/core/settings.ts
  var DEFAULT_SCROLL_SPEED_CURVE = [0, 0.1, 0.3, 0.62, 1];
  var DEFAULT_POINTER_SPEED_CURVE = [0, 0.08, 0.28, 0.62, 1];
  var PREVIOUS_SCROLL_SPEED_CURVE = [0, 0.58, 0.82, 0.95, 1];
  var PREVIOUS_POINTER_SPEED_CURVE = [0, 0.5, 0.76, 0.92, 1];
  var DEFAULT_SETTINGS = Object.freeze({
    deadzone: 0.2,
    spotlightArrivalSize: 30,
    spotlightStartSize: 0,
    triggerThreshold: 0.5,
    neutralBehavior: "retain",
    candidateStart: "first",
    inclusionMode: "center",
    distanceMode: "center",
    tieBreak: "dom",
    candidateNumberVisibility: "show",
    scrollSpeedCurve: DEFAULT_SCROLL_SPEED_CURVE,
    pointerSpeedCurve: DEFAULT_POINTER_SPEED_CURVE,
    scrollMaxSpeed: 2200,
    pointerMaxSpeed: 1800,
    rightStickCandidateStepDegrees: 70
  });
  var LIMITS = {
    deadzone: { min: 0.05, max: 0.6 },
    triggerThreshold: { min: 0.1, max: 1 },
    scrollMaxSpeed: { min: 100, max: 4e3 },
    pointerMaxSpeed: { min: 100, max: 3e3 },
    rightStickCandidateStepDegrees: { min: 15, max: 180 },
    spotlightArrivalSize: { min: 0, max: 100 },
    spotlightStartSize: { min: 0, max: 100 }
  };
  function numericValue(value, fallback, min, max) {
    const parsed = typeof value === "number" ? value : Number(value);
    if (!Number.isFinite(parsed)) return fallback;
    return Math.min(max, Math.max(min, parsed));
  }
  function speedCurveBezierSegments(curve) {
    const spacing = 1 / 4;
    const slopes = curve.slice(0, 4).map((value, index) => (curve[index + 1] - value) / spacing);
    const tangents = [slopes[0]];
    for (let index = 1; index < 4; index += 1) {
      const previous = slopes[index - 1];
      const next = slopes[index];
      tangents.push(previous <= 0 || next <= 0 ? 0 : 2 * previous * next / (previous + next));
    }
    tangents.push(slopes[3]);
    return Array.from({ length: 4 }, (_, index) => {
      const startX = index * spacing;
      const endX = startX + spacing;
      return {
        startX,
        startY: curve[index],
        control1X: startX + spacing / 3,
        control1Y: curve[index] + tangents[index] * spacing / 3,
        control2X: endX - spacing / 3,
        control2Y: curve[index + 1] - tangents[index + 1] * spacing / 3,
        endX,
        endY: curve[index + 1]
      };
    });
  }
  function normalizeSpeedCurve(value, fallback) {
    if (!Array.isArray(value) || value.length < 5) return [...fallback];
    const previousDefaults = fallback === DEFAULT_SCROLL_SPEED_CURVE ? PREVIOUS_SCROLL_SPEED_CURVE : PREVIOUS_POINTER_SPEED_CURVE;
    if (previousDefaults.every((point, index) => Number(value[index]) === point)) return [...fallback];
    const curve = [
      0,
      numericValue(value[1], fallback[1], 0, 1),
      numericValue(value[2], fallback[2], 0, 1),
      numericValue(value[3], fallback[3], 0, 1),
      1
    ];
    for (let index = 2; index <= 3; index += 1) {
      curve[index] = Math.max(curve[index - 1], curve[index]);
    }
    return curve;
  }
  function normalizeSettings(value) {
    const record = value && typeof value === "object" ? value : {};
    const source = record;
    const legacySize = record.spotlightSize ?? record.coneAngle;
    const hasNewSpotlightSizes = source.spotlightArrivalSize !== void 0 || source.spotlightStartSize !== void 0;
    const migrateLegacySpotlightSize = !hasNewSpotlightSizes && legacySize !== void 0;
    const legacySizePercent = migrateLegacySpotlightSize ? numericValue(legacySize, DEFAULT_SETTINGS.spotlightArrivalSize, LIMITS.spotlightArrivalSize.min, LIMITS.spotlightArrivalSize.max) : void 0;
    const legacyWasCylinder = record.spotlightShape === "cylinder";
    return {
      deadzone: numericValue(source.deadzone, DEFAULT_SETTINGS.deadzone, LIMITS.deadzone.min, LIMITS.deadzone.max),
      spotlightArrivalSize: numericValue(source.spotlightArrivalSize, legacySizePercent ?? DEFAULT_SETTINGS.spotlightArrivalSize, LIMITS.spotlightArrivalSize.min, LIMITS.spotlightArrivalSize.max),
      spotlightStartSize: numericValue(source.spotlightStartSize, legacyWasCylinder ? legacySizePercent ?? DEFAULT_SETTINGS.spotlightStartSize : DEFAULT_SETTINGS.spotlightStartSize, LIMITS.spotlightStartSize.min, LIMITS.spotlightStartSize.max),
      triggerThreshold: numericValue(source.triggerThreshold, DEFAULT_SETTINGS.triggerThreshold, LIMITS.triggerThreshold.min, LIMITS.triggerThreshold.max),
      neutralBehavior: source.neutralBehavior === "clear" ? "clear" : "retain",
      candidateStart: source.candidateStart === "preserve" ? "preserve" : "first",
      inclusionMode: source.inclusionMode === "intersects" ? "intersects" : "center",
      distanceMode: source.distanceMode === "nearest" ? "nearest" : "center",
      tieBreak: source.tieBreak === "top-left" ? "top-left" : "dom",
      candidateNumberVisibility: source.candidateNumberVisibility === "hide" ? "hide" : "show",
      scrollSpeedCurve: normalizeSpeedCurve(source.scrollSpeedCurve, DEFAULT_SCROLL_SPEED_CURVE),
      pointerSpeedCurve: normalizeSpeedCurve(source.pointerSpeedCurve, DEFAULT_POINTER_SPEED_CURVE),
      scrollMaxSpeed: numericValue(source.scrollMaxSpeed, DEFAULT_SETTINGS.scrollMaxSpeed, LIMITS.scrollMaxSpeed.min, LIMITS.scrollMaxSpeed.max),
      pointerMaxSpeed: numericValue(source.pointerMaxSpeed, DEFAULT_SETTINGS.pointerMaxSpeed, LIMITS.pointerMaxSpeed.min, LIMITS.pointerMaxSpeed.max),
      rightStickCandidateStepDegrees: numericValue(source.rightStickCandidateStepDegrees, DEFAULT_SETTINGS.rightStickCandidateStepDegrees, LIMITS.rightStickCandidateStepDegrees.min, LIMITS.rightStickCandidateStepDegrees.max)
    };
  }

  // src/extension/settings-page.ts
  var form = document.querySelector("#settingsForm");
  var saveStatus = document.querySelector("#saveStatus");
  var saveMessage = saveStatus.querySelector("span:last-child");
  var resetButton = document.querySelector("#resetButton");
  var SPEED_CURVE_NAMES = ["scrollSpeedCurve", "pointerSpeedCurve"];
  var CURVE_PLOT = { top: 20, bottom: 155, left: 40, right: 310, height: 200 };
  function paintStatus(message, tone = "idle") {
    saveMessage.textContent = message;
    saveStatus.dataset.tone = tone;
  }
  function speedCurveDots(name) {
    return [...form.querySelectorAll(`circle[data-speed-curve-dot="${name}"]`)].sort((first, second) => Number(first.dataset.curveIndex) - Number(second.dataset.curveIndex));
  }
  function curveFromChart(name) {
    const dots = speedCurveDots(name);
    return [0, Number(dots[1]?.dataset.value ?? 0) / 100, Number(dots[2]?.dataset.value ?? 0) / 100, Number(dots[3]?.dataset.value ?? 0) / 100, 1];
  }
  function paintSpeedCurve(name, curve) {
    const coordinates = curve.map((value, index) => ({
      x: CURVE_PLOT.left + (CURVE_PLOT.right - CURVE_PLOT.left) * index / 4,
      y: CURVE_PLOT.bottom - (CURVE_PLOT.bottom - CURVE_PLOT.top) * value
    }));
    const toX = (value) => CURVE_PLOT.left + (CURVE_PLOT.right - CURVE_PLOT.left) * value;
    const toY = (value) => CURVE_PLOT.bottom - (CURVE_PLOT.bottom - CURVE_PLOT.top) * value;
    const bezierSegments = speedCurveBezierSegments(curve);
    const curvePath = `M ${toX(bezierSegments[0].startX)} ${toY(bezierSegments[0].startY)} ${bezierSegments.map((segment) => `C ${toX(segment.control1X)} ${toY(segment.control1Y)} ${toX(segment.control2X)} ${toY(segment.control2Y)} ${toX(segment.endX)} ${toY(segment.endY)}`).join(" ")}`;
    form.querySelector(`[data-speed-curve-path="${name}"]`)?.setAttribute("d", curvePath);
    const areaPath = `${curvePath} L ${CURVE_PLOT.right} ${CURVE_PLOT.bottom} L ${CURVE_PLOT.left} ${CURVE_PLOT.bottom} Z`;
    form.querySelector(`[data-speed-curve-area="${name}"]`)?.setAttribute("d", areaPath);
    speedCurveDots(name).forEach((dot, index) => {
      const value = Math.round(curve[index] * 100);
      dot.dataset.value = String(value);
      dot.setAttribute("cx", String(coordinates[index].x));
      dot.setAttribute("cy", String(coordinates[index].y));
      if (index > 0 && index < 4) {
        const inputPercent = index * 25;
        dot.setAttribute("aria-valuenow", String(value));
        dot.setAttribute("aria-valuetext", `${inputPercent}% \uC785\uB825, \uC18D\uB3C4 ${value}%`);
        const label = form.querySelector(`text[data-speed-curve-label="${name}"][data-curve-index="${index}"]`);
        label?.setAttribute("x", String(coordinates[index].x));
        label?.setAttribute("y", String(Math.max(CURVE_PLOT.top - 5, coordinates[index].y - 12)));
        if (label) label.textContent = `${value}%`;
        const readout = form.querySelector(`output[data-speed-curve-readout="${name}"][data-curve-index="${index}"]`);
        if (readout) readout.textContent = `${value}%`;
      }
    });
  }
  function setSpeedCurvePoint(name, changedIndex, percent) {
    const curve = curveFromChart(name);
    curve[changedIndex] = Math.min(100, Math.max(0, Math.round(percent))) / 100;
    for (let index = changedIndex - 1; index >= 1; index -= 1) {
      curve[index] = Math.min(curve[index], curve[index + 1]);
    }
    for (let index = changedIndex + 1; index <= 3; index += 1) {
      curve[index] = Math.max(curve[index], curve[index - 1]);
    }
    paintSpeedCurve(name, curve);
    paintStatus("\uBCC0\uACBD \uC0AC\uD56D\uC744 \uC800\uC7A5\uD558\uC138\uC694.");
  }
  function moveSpeedCurvePoint(chart, name, index, clientY) {
    const bounds = chart.getBoundingClientRect();
    if (bounds.height <= 0) return;
    const chartY = (clientY - bounds.top) / bounds.height * CURVE_PLOT.height;
    const fraction = (CURVE_PLOT.bottom - chartY) / (CURVE_PLOT.bottom - CURVE_PLOT.top);
    setSpeedCurvePoint(name, index, fraction * 100);
  }
  function bindSpeedCurveCharts() {
    for (const chart of form.querySelectorAll("svg[data-speed-curve-chart]")) {
      const name = chart.dataset.speedCurveChart;
      let activePointer = null;
      chart.addEventListener("pointerdown", (event) => {
        const handle = event.target instanceof SVGCircleElement ? event.target : null;
        const index = Number(handle?.dataset.curveIndex);
        if (!handle || index < 1 || index > 3) return;
        activePointer = { id: event.pointerId, index };
        chart.setPointerCapture(event.pointerId);
        moveSpeedCurvePoint(chart, name, index, event.clientY);
        event.preventDefault();
      });
      chart.addEventListener("pointermove", (event) => {
        if (activePointer?.id !== event.pointerId) return;
        moveSpeedCurvePoint(chart, name, activePointer.index, event.clientY);
      });
      chart.addEventListener("pointerup", (event) => {
        if (activePointer?.id !== event.pointerId) return;
        activePointer = null;
        void save();
      });
      chart.addEventListener("pointercancel", () => {
        if (!activePointer) return;
        activePointer = null;
        void save();
      });
      for (const handle of chart.querySelectorAll("circle.curve-handle")) {
        handle.addEventListener("keydown", (event) => {
          const index = Number(handle.dataset.curveIndex);
          const current = Number(handle.getAttribute("aria-valuenow"));
          const step = event.shiftKey ? 5 : 1;
          let next = null;
          if (event.key === "ArrowUp" || event.key === "ArrowRight") next = current + step;
          else if (event.key === "ArrowDown" || event.key === "ArrowLeft") next = current - step;
          else if (event.key === "Home") next = 0;
          else if (event.key === "End") next = 100;
          if (next === null) return;
          event.preventDefault();
          setSpeedCurvePoint(name, index, next);
        });
        handle.addEventListener("keyup", (event) => {
          if (["ArrowUp", "ArrowRight", "ArrowDown", "ArrowLeft", "Home", "End"].includes(event.key)) void save();
        });
      }
    }
  }
  function render(settings) {
    for (const input of form.querySelectorAll("input[data-setting]")) {
      const key = input.dataset.setting;
      input.value = String(settings[key]);
      input.setAttribute("aria-invalid", "false");
      const range = form.querySelector(`input[data-range-for="${key}"]`);
      if (range) range.value = String(settings[key]);
    }
    for (const select of form.querySelectorAll("select[data-setting]")) {
      const key = select.dataset.setting;
      select.value = String(settings[key]);
    }
    for (const name of SPEED_CURVE_NAMES) paintSpeedCurve(name, settings[name]);
  }
  function readForm() {
    const numericInputs = [...form.querySelectorAll("input[data-setting]")];
    let valid = true;
    for (const input of numericInputs) {
      const passes = input.value.trim() !== "" && input.validity.valid;
      input.setAttribute("aria-invalid", String(!passes));
      valid = valid && passes;
    }
    if (!valid) return null;
    const values = {};
    for (const input of numericInputs) values[input.dataset.setting] = Number(input.value);
    for (const select of form.querySelectorAll("select[data-setting]")) values[select.dataset.setting] = select.value;
    for (const name of SPEED_CURVE_NAMES) values[name] = curveFromChart(name);
    return normalizeSettings(values);
  }
  async function save() {
    const settings = readForm();
    if (!settings) {
      paintStatus("\uD5C8\uC6A9 \uBC94\uC704 \uC548\uC758 \uAC12\uC744 \uC785\uB825\uD558\uC138\uC694.", "error");
      return;
    }
    try {
      await chrome.storage.local.set({ settings });
      paintStatus("\uC800\uC7A5\uB428 \xB7 \uCF1C\uC838 \uC788\uB294 \uD398\uC774\uC9C0\uC5D0 \uBC14\uB85C \uBC18\uC601", "saved");
    } catch {
      paintStatus("\uC124\uC815\uC744 \uC800\uC7A5\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4. \uB2E4\uC2DC \uC2DC\uB3C4\uD558\uC138\uC694.", "error");
    }
  }
  function syncRange(input) {
    const setting = input.dataset.setting ?? input.dataset.rangeFor;
    if (!setting) return;
    const range = form.querySelector(`input[data-range-for="${setting}"]`);
    if (!range) return;
    if (input.type === "range") {
      const number = form.querySelector(`input[data-setting="${setting}"]`);
      if (number) {
        number.value = input.value;
        number.setAttribute("aria-invalid", "false");
      }
    } else if (input.value.trim() && input.validity.valid) {
      range.value = input.value;
      input.setAttribute("aria-invalid", "false");
    }
  }
  for (const input of form.querySelectorAll("input[data-setting], input[data-range-for]")) {
    input.addEventListener("input", () => {
      syncRange(input);
      paintStatus("\uBCC0\uACBD \uC0AC\uD56D\uC744 \uC800\uC7A5\uD558\uC138\uC694.");
    });
    input.addEventListener("change", () => void save());
  }
  bindSpeedCurveCharts();
  for (const select of form.querySelectorAll("select[data-setting]")) {
    select.addEventListener("change", () => void save());
  }
  resetButton.addEventListener("click", async () => {
    render(DEFAULT_SETTINGS);
    await save();
  });
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === "local" && changes.settings?.newValue) {
      render(normalizeSettings(changes.settings.newValue));
    }
  });
  for (const input of form.querySelectorAll("input[data-setting]")) {
    input.setAttribute("aria-describedby", `${input.id}Helper`);
  }
  void chrome.storage.local.get("settings").then(({ settings }) => {
    render(normalizeSettings(settings));
    paintStatus("\uC124\uC815\uC774 \uC774 \uAE30\uAE30\uC5D0 \uC800\uC7A5\uB429\uB2C8\uB2E4.");
  }).catch(() => {
    render(DEFAULT_SETTINGS);
    paintStatus("\uAE30\uBCF8 \uC124\uC815\uC744 \uD45C\uC2DC \uC911\uC785\uB2C8\uB2E4. \uC800\uC7A5 \uC0C1\uD0DC\uB97C \uD655\uC778\uD558\uC138\uC694.", "error");
  });
})();
