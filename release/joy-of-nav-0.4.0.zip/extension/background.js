"use strict";
(() => {
  // src/core/settings.ts
  var DEFAULT_SETTINGS = Object.freeze({
    deadzone: 0.2,
    coneAngle: 30,
    triggerThreshold: 0.5,
    neutralBehavior: "retain",
    candidateStart: "first",
    inclusionMode: "center",
    distanceMode: "center",
    tieBreak: "dom"
  });

  // src/extension/background.ts
  chrome.runtime.onInstalled.addListener(() => {
    void chrome.storage.local.get("settings").then(({ settings }) => {
      if (!settings) return chrome.storage.local.set({ settings: DEFAULT_SETTINGS });
      return void 0;
    });
  });
})();
