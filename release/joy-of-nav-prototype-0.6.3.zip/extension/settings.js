"use strict";
(() => {
  // src/core/settings.ts
  var DEFAULT_SETTINGS = Object.freeze({
    deadzone: 0.2,
    coneAngle: 30,
    triggerThreshold: 0.5,
    neutralBehavior: "retain",
    candidateStart: "first",
    inclusionMode: "center",
    distanceMode: "center",
    tieBreak: "dom"
  });
  var LIMITS = {
    deadzone: { min: 0.05, max: 0.6 },
    coneAngle: { min: 5, max: 180 },
    triggerThreshold: { min: 0.1, max: 1 }
  };
  function numericValue(value, fallback, min, max) {
    const parsed = typeof value === "number" ? value : Number(value);
    if (!Number.isFinite(parsed)) return fallback;
    return Math.min(max, Math.max(min, parsed));
  }
  function normalizeSettings(value) {
    const source = value && typeof value === "object" ? value : {};
    return {
      deadzone: numericValue(source.deadzone, DEFAULT_SETTINGS.deadzone, LIMITS.deadzone.min, LIMITS.deadzone.max),
      coneAngle: numericValue(source.coneAngle, DEFAULT_SETTINGS.coneAngle, LIMITS.coneAngle.min, LIMITS.coneAngle.max),
      triggerThreshold: numericValue(source.triggerThreshold, DEFAULT_SETTINGS.triggerThreshold, LIMITS.triggerThreshold.min, LIMITS.triggerThreshold.max),
      neutralBehavior: source.neutralBehavior === "clear" ? "clear" : "retain",
      candidateStart: source.candidateStart === "preserve" ? "preserve" : "first",
      inclusionMode: source.inclusionMode === "intersects" ? "intersects" : "center",
      distanceMode: source.distanceMode === "nearest" ? "nearest" : "center",
      tieBreak: source.tieBreak === "top-left" ? "top-left" : "dom"
    };
  }

  // src/extension/settings-page.ts
  var form = document.querySelector("#settingsForm");
  var saveStatus = document.querySelector("#saveStatus");
  var saveMessage = saveStatus.querySelector("span:last-child");
  var resetButton = document.querySelector("#resetButton");
  function paintStatus(message, tone = "idle") {
    saveMessage.textContent = message;
    saveStatus.dataset.tone = tone;
  }
  function render(settings) {
    for (const input of form.querySelectorAll("input[data-setting]")) {
      const key = input.dataset.setting;
      input.value = String(settings[key]);
      input.setAttribute("aria-invalid", "false");
      const range = form.querySelector(`input[data-range-for="${key}"]`);
      if (range) range.value = String(settings[key]);
    }
    for (const select of form.querySelectorAll("select[data-setting]")) {
      const key = select.dataset.setting;
      select.value = String(settings[key]);
    }
  }
  function readForm() {
    const numericInputs = [...form.querySelectorAll("input[data-setting]")];
    let valid = true;
    for (const input of numericInputs) {
      const passes = input.value.trim() !== "" && input.validity.valid;
      input.setAttribute("aria-invalid", String(!passes));
      valid = valid && passes;
    }
    if (!valid) return null;
    const values = {};
    for (const input of numericInputs) values[input.dataset.setting] = Number(input.value);
    for (const select of form.querySelectorAll("select[data-setting]")) values[select.dataset.setting] = select.value;
    return normalizeSettings(values);
  }
  async function save() {
    const settings = readForm();
    if (!settings) {
      paintStatus("\uD5C8\uC6A9 \uBC94\uC704 \uC548\uC758 \uAC12\uC744 \uC785\uB825\uD558\uC138\uC694.", "error");
      return;
    }
    try {
      await chrome.storage.local.set({ settings });
      paintStatus("\uC800\uC7A5\uB428 \xB7 \uCF1C\uC838 \uC788\uB294 \uD398\uC774\uC9C0\uC5D0 \uBC14\uB85C \uBC18\uC601", "saved");
    } catch {
      paintStatus("\uC124\uC815\uC744 \uC800\uC7A5\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4. \uB2E4\uC2DC \uC2DC\uB3C4\uD558\uC138\uC694.", "error");
    }
  }
  function syncRange(input) {
    const setting = input.dataset.setting ?? input.dataset.rangeFor;
    if (!setting) return;
    const range = form.querySelector(`input[data-range-for="${setting}"]`);
    if (!range) return;
    if (input.type === "range") {
      const number = form.querySelector(`input[data-setting="${setting}"]`);
      if (number) {
        number.value = input.value;
        number.setAttribute("aria-invalid", "false");
      }
    } else if (input.value.trim() && input.validity.valid) {
      range.value = input.value;
      input.setAttribute("aria-invalid", "false");
    }
  }
  for (const input of form.querySelectorAll("input[data-setting], input[data-range-for]")) {
    input.addEventListener("input", () => {
      syncRange(input);
      paintStatus("\uBCC0\uACBD \uC0AC\uD56D\uC744 \uC800\uC7A5\uD558\uC138\uC694.");
    });
    input.addEventListener("change", () => void save());
  }
  for (const select of form.querySelectorAll("select[data-setting]")) {
    select.addEventListener("change", () => void save());
  }
  resetButton.addEventListener("click", async () => {
    render(DEFAULT_SETTINGS);
    await save();
  });
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === "local" && changes.settings?.newValue) {
      render(normalizeSettings(changes.settings.newValue));
    }
  });
  for (const input of form.querySelectorAll("input[data-setting]")) {
    input.setAttribute("aria-describedby", `${input.id}Helper`);
  }
  void chrome.storage.local.get("settings").then(({ settings }) => {
    render(normalizeSettings(settings));
    paintStatus("\uC124\uC815\uC774 \uC774 \uAE30\uAE30\uC5D0 \uC800\uC7A5\uB429\uB2C8\uB2E4.");
  }).catch(() => {
    render(DEFAULT_SETTINGS);
    paintStatus("\uAE30\uBCF8 \uC124\uC815\uC744 \uD45C\uC2DC \uC911\uC785\uB2C8\uB2E4. \uC800\uC7A5 \uC0C1\uD0DC\uB97C \uD655\uC778\uD558\uC138\uC694.", "error");
  });
})();
