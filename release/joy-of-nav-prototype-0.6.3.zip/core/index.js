// src/core/navigation.ts
function readDirection(x, y, deadzone) {
  const magnitude = Math.hypot(x, y);
  if (!Number.isFinite(magnitude) || magnitude <= deadzone) return null;
  return { x, y, magnitude };
}
function pointInCone(point, origin, direction, fullAngle) {
  const dx = point.x - origin.x;
  const dy = point.y - origin.y;
  const pointLength = Math.hypot(dx, dy);
  const directionLength = Math.hypot(direction.x, direction.y);
  if (pointLength === 0 || directionLength === 0) return true;
  const cosine = Math.min(1, Math.max(-1, (dx * direction.x + dy * direction.y) / (pointLength * directionLength)));
  const angle = Math.acos(cosine) * 180 / Math.PI;
  return angle <= fullAngle / 2 + 1e-8;
}
function corners(rect) {
  return [
    { x: rect.left, y: rect.top },
    { x: rect.right, y: rect.top },
    { x: rect.right, y: rect.bottom },
    { x: rect.left, y: rect.bottom }
  ];
}
function segmentIntersectsRect(start, end, rect) {
  const dx = end.x - start.x;
  const dy = end.y - start.y;
  let t0 = 0;
  let t1 = 1;
  const tests = [
    [-dx, start.x - rect.left],
    [dx, rect.right - start.x],
    [-dy, start.y - rect.top],
    [dy, rect.bottom - start.y]
  ];
  for (const [p, q] of tests) {
    if (p === 0) {
      if (q < 0) return false;
      continue;
    }
    const t = q / p;
    if (p < 0) t0 = Math.max(t0, t);
    else t1 = Math.min(t1, t);
    if (t0 > t1) return false;
  }
  return true;
}
function rayIntersectsRect(origin, direction, rect) {
  const length = Math.max(...corners(rect).map((point) => Math.hypot(point.x - origin.x, point.y - origin.y))) + 1;
  const magnitude = Math.hypot(direction.x, direction.y);
  if (!magnitude) return false;
  const end = { x: origin.x + direction.x / magnitude * length, y: origin.y + direction.y / magnitude * length };
  return segmentIntersectsRect(origin, end, rect);
}
function rectIntersectsCone(rect, origin, direction, fullAngle) {
  if (corners(rect).some((corner) => pointInCone(corner, origin, direction, fullAngle))) return true;
  const nearest = {
    x: Math.min(rect.right, Math.max(rect.left, origin.x)),
    y: Math.min(rect.bottom, Math.max(rect.top, origin.y))
  };
  if (pointInCone(nearest, origin, direction, fullAngle)) return true;
  const axisAngle = Math.atan2(direction.y, direction.x);
  const halfAngle = fullAngle * Math.PI / 360;
  const start = { x: Math.cos(axisAngle - halfAngle), y: Math.sin(axisAngle - halfAngle) };
  const end = { x: Math.cos(axisAngle + halfAngle), y: Math.sin(axisAngle + halfAngle) };
  return rayIntersectsRect(origin, direction, rect) || rayIntersectsRect(origin, start, rect) || rayIntersectsRect(origin, end, rect);
}
function candidateInCone(candidate, origin, direction, fullAngle, mode) {
  if (mode === "intersects") return rectIntersectsCone(candidate.rect, origin, direction, fullAngle);
  return pointInCone({
    x: (candidate.rect.left + candidate.rect.right) / 2,
    y: (candidate.rect.top + candidate.rect.bottom) / 2
  }, origin, direction, fullAngle);
}
function candidateDistance(candidate, origin, mode) {
  const point = mode === "center" ? { x: (candidate.rect.left + candidate.rect.right) / 2, y: (candidate.rect.top + candidate.rect.bottom) / 2 } : {
    x: Math.min(candidate.rect.right, Math.max(candidate.rect.left, origin.x)),
    y: Math.min(candidate.rect.bottom, Math.max(candidate.rect.top, origin.y))
  };
  return Math.hypot(point.x - origin.x, point.y - origin.y);
}
function rankCandidates(candidates, origin, direction, fullAngle, inclusionMode, distanceMode, tieBreak) {
  return candidates.filter((candidate) => candidateInCone(candidate, origin, direction, fullAngle, inclusionMode)).slice().sort((left, right) => {
    const distanceDelta = candidateDistance(left, origin, distanceMode) - candidateDistance(right, origin, distanceMode);
    if (Math.abs(distanceDelta) > 0.01) return distanceDelta;
    if (tieBreak === "top-left") {
      const topDelta = left.rect.top - right.rect.top;
      if (Math.abs(topDelta) > 0.01) return topDelta;
      const leftDelta = left.rect.left - right.rect.left;
      if (Math.abs(leftDelta) > 0.01) return leftDelta;
    }
    return left.documentOrder - right.documentOrder;
  });
}
function nextCycleIndex(currentIndex, length) {
  if (length <= 0) return -1;
  return currentIndex < 0 || currentIndex >= length ? 0 : (currentIndex + 1) % length;
}
function resolveSelectionIndex(previouslySelected, candidates, preserve) {
  if (preserve && previouslySelected !== void 0) {
    return candidates.indexOf(previouslySelected);
  }
  return -1;
}
function hasRisen(currentlyDown, wasDown) {
  return currentlyDown && !wasDown;
}

// src/core/settings.ts
var DEFAULT_SETTINGS = Object.freeze({
  deadzone: 0.2,
  coneAngle: 30,
  triggerThreshold: 0.5,
  neutralBehavior: "retain",
  candidateStart: "first",
  inclusionMode: "center",
  distanceMode: "center",
  tieBreak: "dom"
});
var LIMITS = {
  deadzone: { min: 0.05, max: 0.6 },
  coneAngle: { min: 5, max: 180 },
  triggerThreshold: { min: 0.1, max: 1 }
};
function numericValue(value, fallback, min, max) {
  const parsed = typeof value === "number" ? value : Number(value);
  if (!Number.isFinite(parsed)) return fallback;
  return Math.min(max, Math.max(min, parsed));
}
function normalizeSettings(value) {
  const source = value && typeof value === "object" ? value : {};
  return {
    deadzone: numericValue(source.deadzone, DEFAULT_SETTINGS.deadzone, LIMITS.deadzone.min, LIMITS.deadzone.max),
    coneAngle: numericValue(source.coneAngle, DEFAULT_SETTINGS.coneAngle, LIMITS.coneAngle.min, LIMITS.coneAngle.max),
    triggerThreshold: numericValue(source.triggerThreshold, DEFAULT_SETTINGS.triggerThreshold, LIMITS.triggerThreshold.min, LIMITS.triggerThreshold.max),
    neutralBehavior: source.neutralBehavior === "clear" ? "clear" : "retain",
    candidateStart: source.candidateStart === "preserve" ? "preserve" : "first",
    inclusionMode: source.inclusionMode === "intersects" ? "intersects" : "center",
    distanceMode: source.distanceMode === "nearest" ? "nearest" : "center",
    tieBreak: source.tieBreak === "top-left" ? "top-left" : "dom"
  };
}
var SETTING_LIMITS = LIMITS;
export {
  DEFAULT_SETTINGS,
  SETTING_LIMITS,
  candidateInCone,
  hasRisen,
  nextCycleIndex,
  normalizeSettings,
  pointInCone,
  rankCandidates,
  readDirection,
  resolveSelectionIndex
};
